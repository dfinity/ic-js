---
title: memoToNeuronSubaccount
editUrl: false
next: true
prev: true
---

> **memoToNeuronSubaccount**(`__namedParameters`): `SubAccount`

Defined in: [packages/nns/src/utils/neurons.utils.ts:101](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/utils/neurons.utils.ts#L101)

## Parameters

### \_\_namedParameters

#### controller

`Principal`

#### memo

`bigint`

## Returns

`SubAccount`
