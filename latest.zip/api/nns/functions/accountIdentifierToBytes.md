---
title: accountIdentifierToBytes
editUrl: false
next: true
prev: true
---

> **accountIdentifierToBytes**(`accountIdentifier`): `Uint8Array`

Defined in: [packages/nns/src/utils/account\_identifier.utils.ts:15](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/utils/account_identifier.utils.ts#L15)

## Parameters

### accountIdentifier

`string`

## Returns

`Uint8Array`
