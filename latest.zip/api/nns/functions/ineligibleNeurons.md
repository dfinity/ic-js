---
title: ineligibleNeurons
editUrl: false
next: true
prev: true
---

> **ineligibleNeurons**(`params`): [`NeuronInfo`](../interfaces/NeuronInfo.md)[]

Defined in: [packages/nns/src/utils/neurons.utils.ts:37](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/utils/neurons.utils.ts#L37)

Filter the neurons that are ineligible to vote to a proposal.

This feature needs the ballots of the proposal to contains accurate data.
If the proposal has settled, as the ballots of the proposal are emptied for archive purpose, the function might return a list of ineligible neurons that are actually neurons that have not voted but would have been eligible.

Long story short, check the status of the proposal before using this function.

## Parameters

### params

#### neurons

[`NeuronInfo`](../interfaces/NeuronInfo.md)[]

The neurons to filter.

#### proposal

[`ProposalInfo`](../interfaces/ProposalInfo.md)

The proposal to match against the selected neurons.

## Returns

[`NeuronInfo`](../interfaces/NeuronInfo.md)[]
