---
title: votedNeurons
editUrl: false
next: true
prev: true
---

> **votedNeurons**(`params`): [`NeuronInfo`](../interfaces/NeuronInfo.md)[]

Defined in: [packages/nns/src/utils/neurons.utils.ts:89](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/utils/neurons.utils.ts#L89)

Filter the neurons that have voted for a proposal.

## Parameters

### params

#### neurons

[`NeuronInfo`](../interfaces/NeuronInfo.md)[]

The neurons to filter.

#### proposal

[`ProposalInfo`](../interfaces/ProposalInfo.md)

The proposal for which some neurons might have already voted.

## Returns

[`NeuronInfo`](../interfaces/NeuronInfo.md)[]
