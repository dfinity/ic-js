---
title: accountIdentifierFromBytes
editUrl: false
next: true
prev: true
---

> **accountIdentifierFromBytes**(`accountIdentifier`): `string`

Defined in: [packages/nns/src/utils/account\_identifier.utils.ts:19](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/utils/account_identifier.utils.ts#L19)

## Parameters

### accountIdentifier

`Uint8Array`

## Returns

`string`
