---
title: accountIdentifierFromBytes
editUrl: false
next: true
prev: true
---

> **accountIdentifierFromBytes**(`accountIdentifier`): `string`

Defined in: [packages/nns/src/utils/account\_identifier.utils.ts:19](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/utils/account_identifier.utils.ts#L19)

## Parameters

### accountIdentifier

`Uint8Array`

## Returns

`string`
