---
title: DeveloperDistribution
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:750](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L750)

## Properties

### developerNeurons

> **developerNeurons**: [`NeuronDistribution`](NeuronDistribution.md)[]

Defined in: [packages/nns/src/types/governance\_converters.ts:751](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L751)
