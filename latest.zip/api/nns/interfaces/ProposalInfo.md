---
title: ProposalInfo
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:477](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L477)

## Properties

### ballots

> **ballots**: [`Ballot`](Ballot.md)[]

Defined in: [packages/nns/src/types/governance\_converters.ts:479](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L479)

***

### deadlineTimestampSeconds

> **deadlineTimestampSeconds**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:485](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L485)

***

### decidedTimestampSeconds

> **decidedTimestampSeconds**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:484](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L484)

***

### executedTimestampSeconds

> **executedTimestampSeconds**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:489](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L489)

***

### failedTimestampSeconds

> **failedTimestampSeconds**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:483](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L483)

***

### id

> **id**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:478](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L478)

***

### latestTally

> **latestTally**: [`Option`](../type-aliases/Option.md)\<[`Tally`](Tally.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:486](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L486)

***

### proposal

> **proposal**: [`Option`](../type-aliases/Option.md)\<[`Proposal`](Proposal.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:487](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L487)

***

### proposalTimestampSeconds

> **proposalTimestampSeconds**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:481](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L481)

***

### proposer

> **proposer**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:488](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L488)

***

### rejectCost

> **rejectCost**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:480](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L480)

***

### rewardEventRound

> **rewardEventRound**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:482](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L482)

***

### rewardStatus

> **rewardStatus**: [`ProposalRewardStatus`](../enumerations/ProposalRewardStatus.md)

Defined in: [packages/nns/src/types/governance\_converters.ts:492](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L492)

***

### status

> **status**: [`ProposalStatus`](../enumerations/ProposalStatus.md)

Defined in: [packages/nns/src/types/governance\_converters.ts:491](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L491)

***

### topic

> **topic**: [`Topic`](../enumerations/Topic.md)

Defined in: [packages/nns/src/types/governance\_converters.ts:490](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L490)

***

### totalPotentialVotingPower

> **totalPotentialVotingPower**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:493](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L493)
