---
title: OpenSnsTokenSwap
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:346](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L346)

## Properties

### communityFundInvestmentE8s

> **communityFundInvestmentE8s**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:347](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L347)

***

### params

> **params**: [`Option`](../type-aliases/Option.md)\<\{ `maxDirectParticipationIcpE8s`: [`Option`](../type-aliases/Option.md)\<`bigint`\>; `maxIcpE8s`: `bigint`; `maxParticipantIcpE8s`: `bigint`; `minDirectParticipationIcpE8s`: [`Option`](../type-aliases/Option.md)\<`bigint`\>; `minIcpE8s`: `bigint`; `minParticipantIcpE8s`: `bigint`; `minParticipants`: `number`; `neuronBasketConstructionParameters`: [`Option`](../type-aliases/Option.md)\<\{ `count`: `bigint`; `dissolve_delay_interval_seconds`: `bigint`; \}\>; `saleDelaySeconds`: [`Option`](../type-aliases/Option.md)\<`bigint`\>; `snsTokenE8s`: `bigint`; `swapDueTimestampSeconds`: `bigint`; \}\>

Defined in: [packages/nns/src/types/governance\_converters.ts:349](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L349)

***

### targetSwapCanisterId

> **targetSwapCanisterId**: [`Option`](../type-aliases/Option.md)\<`Principal`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:348](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L348)
