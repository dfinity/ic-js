---
title: MakeMotionProposalRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:620](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L620)

## Properties

### neuronId

> **neuronId**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:621](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L621)

***

### summary

> **summary**: `string`

Defined in: [packages/nns/src/types/governance\_converters.ts:625](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L625)

***

### text

> **text**: `string`

Defined in: [packages/nns/src/types/governance\_converters.ts:624](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L624)

***

### title

> **title**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:622](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L622)

***

### url

> **url**: `string`

Defined in: [packages/nns/src/types/governance\_converters.ts:623](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L623)
