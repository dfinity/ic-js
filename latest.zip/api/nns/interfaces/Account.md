---
title: Account
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:179](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L179)

## Properties

### owner

> **owner**: [`Option`](../type-aliases/Option.md)\<`Principal`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:180](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L180)

***

### subaccount

> **subaccount**: [`Option`](../type-aliases/Option.md)\<`number`[]\>

Defined in: [packages/nns/src/types/governance\_converters.ts:181](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L181)
