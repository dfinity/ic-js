---
title: DeployedSns
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/candid/sns\_wasm.d.ts:44](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/candid/sns_wasm.d.ts#L44)

## Properties

### governance\_canister\_id

> **governance\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/nns/src/candid/sns\_wasm.d.ts:46](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/candid/sns_wasm.d.ts#L46)

***

### index\_canister\_id

> **index\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/nns/src/candid/sns\_wasm.d.ts:47](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/candid/sns_wasm.d.ts#L47)

***

### ledger\_canister\_id

> **ledger\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/nns/src/candid/sns\_wasm.d.ts:49](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/candid/sns_wasm.d.ts#L49)

***

### root\_canister\_id

> **root\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/nns/src/candid/sns\_wasm.d.ts:45](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/candid/sns_wasm.d.ts#L45)

***

### swap\_canister\_id

> **swap\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/nns/src/candid/sns\_wasm.d.ts:48](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/candid/sns_wasm.d.ts#L48)
