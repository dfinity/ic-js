---
title: SwapParameters
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:721](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L721)

## Properties

### confirmationText

> **confirmationText**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:725](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L725)

***

### duration

> **duration**: [`Option`](../type-aliases/Option.md)\<[`Duration`](Duration.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:723](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L723)

***

### maxDirectParticipationIcp

> **maxDirectParticipationIcp**: [`Option`](../type-aliases/Option.md)\<[`Tokens`](Tokens.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:733](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L733)

***

### maximumIcp

> **maximumIcp**: [`Option`](../type-aliases/Option.md)\<[`Tokens`](Tokens.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:731](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L731)

***

### maximumParticipantIcp

> **maximumParticipantIcp**: [`Option`](../type-aliases/Option.md)\<[`Tokens`](Tokens.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:726](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L726)

***

### minDirectParticipationIcp

> **minDirectParticipationIcp**: [`Option`](../type-aliases/Option.md)\<[`Tokens`](Tokens.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:734](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L734)

***

### minimumIcp

> **minimumIcp**: [`Option`](../type-aliases/Option.md)\<[`Tokens`](Tokens.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:728](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L728)

***

### minimumParticipantIcp

> **minimumParticipantIcp**: [`Option`](../type-aliases/Option.md)\<[`Tokens`](Tokens.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:729](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L729)

***

### minimumParticipants

> **minimumParticipants**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:722](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L722)

***

### neuronBasketConstructionParameters

> **neuronBasketConstructionParameters**: [`Option`](../type-aliases/Option.md)\<[`NeuronBasketConstructionParameters`](NeuronBasketConstructionParameters.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:724](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L724)

***

### neuronsFundInvestmentIcp

> **neuronsFundInvestmentIcp**: [`Option`](../type-aliases/Option.md)\<[`Tokens`](Tokens.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:727](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L727)

***

### neuronsFundParticipation

> **neuronsFundParticipation**: [`Option`](../type-aliases/Option.md)\<`boolean`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:735](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L735)

***

### restrictedCountries

> **restrictedCountries**: [`Option`](../type-aliases/Option.md)\<[`Countries`](Countries.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:732](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L732)

***

### startTime

> **startTime**: [`Option`](../type-aliases/Option.md)\<[`GlobalTimeOfDay`](GlobalTimeOfDay.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:730](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L730)
