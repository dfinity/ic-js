---
title: MakeSetDefaultFolloweesProposalRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:646](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L646)

## Properties

### followees

> **followees**: [`Followees`](Followees.md)[]

Defined in: [packages/nns/src/types/governance\_converters.ts:651](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L651)

***

### neuronId

> **neuronId**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:647](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L647)

***

### summary

> **summary**: `string`

Defined in: [packages/nns/src/types/governance\_converters.ts:649](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L649)

***

### title

> **title**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:648](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L648)

***

### url

> **url**: `string`

Defined in: [packages/nns/src/types/governance\_converters.ts:650](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L650)
