---
title: GovernanceCachedMetrics
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:790](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L790)

## Properties

### communityFundTotalMaturityE8sEquivalent

> **communityFundTotalMaturityE8sEquivalent**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:802](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L802)

***

### communityFundTotalStakedE8s

> **communityFundTotalStakedE8s**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:830](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L830)

***

### decliningVotingPowerNeuronSubsetMetrics

> **decliningVotingPowerNeuronSubsetMetrics**: [`Option`](../type-aliases/Option.md)\<[`NeuronSubsetMetrics`](NeuronSubsetMetrics.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:814](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L814)

***

### dissolvedNeuronsCount

> **dissolvedNeuronsCount**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:801](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L801)

***

### dissolvedNeuronsE8s

> **dissolvedNeuronsE8s**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:817](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L817)

***

### dissolvingNeuronsCount

> **dissolvingNeuronsCount**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:827](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L827)

***

### dissolvingNeuronsCountBuckets

> **dissolvingNeuronsCountBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/nns/src/types/governance\_converters.ts:824](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L824)

***

### dissolvingNeuronsE8sBuckets

> **dissolvingNeuronsE8sBuckets**: \[`bigint`, `number`\][]

Defined in: [packages/nns/src/types/governance\_converters.ts:828](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L828)

***

### dissolvingNeuronsE8sBucketsEct

> **dissolvingNeuronsE8sBucketsEct**: \[`bigint`, `number`\][]

Defined in: [packages/nns/src/types/governance\_converters.ts:825](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L825)

***

### dissolvingNeuronsE8sBucketsSeed

> **dissolvingNeuronsE8sBucketsSeed**: \[`bigint`, `number`\][]

Defined in: [packages/nns/src/types/governance\_converters.ts:819](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L819)

***

### dissolvingNeuronsStakedMaturityE8sEquivalentBuckets

> **dissolvingNeuronsStakedMaturityE8sEquivalentBuckets**: \[`bigint`, `number`\][]

Defined in: [packages/nns/src/types/governance\_converters.ts:795](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L795)

***

### dissolvingNeuronsStakedMaturityE8sEquivalentSum

> **dissolvingNeuronsStakedMaturityE8sEquivalentSum**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:793](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L793)

***

### ectNeuronCount

> **ectNeuronCount**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:798](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L798)

***

### fullyLostVotingPowerNeuronSubsetMetrics

> **fullyLostVotingPowerNeuronSubsetMetrics**: [`Option`](../type-aliases/Option.md)\<[`NeuronSubsetMetrics`](NeuronSubsetMetrics.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:806](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L806)

***

### garbageCollectableNeuronsCount

> **garbageCollectableNeuronsCount**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:794](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L794)

***

### neuronsFundTotalActiveNeurons

> **neuronsFundTotalActiveNeurons**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:809](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L809)

***

### neuronsWithInvalidStakeCount

> **neuronsWithInvalidStakeCount**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:796](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L796)

***

### neuronsWithLessThan6MonthsDissolveDelayCount

> **neuronsWithLessThan6MonthsDissolveDelayCount**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:800](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L800)

***

### neuronsWithLessThan6MonthsDissolveDelayE8s

> **neuronsWithLessThan6MonthsDissolveDelayE8s**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:820](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L820)

***

### nonSelfAuthenticatingControllerNeuronSubsetMetrics

> **nonSelfAuthenticatingControllerNeuronSubsetMetrics**: [`Option`](../type-aliases/Option.md)\<[`NeuronSubsetMetrics`](NeuronSubsetMetrics.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:826](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L826)

***

### notDissolvingNeuronsCount

> **notDissolvingNeuronsCount**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:807](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L807)

***

### notDissolvingNeuronsCountBuckets

> **notDissolvingNeuronsCountBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/nns/src/types/governance\_converters.ts:797](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L797)

***

### notDissolvingNeuronsE8sBuckets

> **notDissolvingNeuronsE8sBuckets**: \[`bigint`, `number`\][]

Defined in: [packages/nns/src/types/governance\_converters.ts:792](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L792)

***

### notDissolvingNeuronsE8sBucketsEct

> **notDissolvingNeuronsE8sBucketsEct**: \[`bigint`, `number`\][]

Defined in: [packages/nns/src/types/governance\_converters.ts:812](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L812)

***

### notDissolvingNeuronsE8sBucketsSeed

> **notDissolvingNeuronsE8sBucketsSeed**: \[`bigint`, `number`\][]

Defined in: [packages/nns/src/types/governance\_converters.ts:831](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L831)

***

### notDissolvingNeuronsStakedMaturityE8sEquivalentBuckets

> **notDissolvingNeuronsStakedMaturityE8sEquivalentBuckets**: \[`bigint`, `number`\][]

Defined in: [packages/nns/src/types/governance\_converters.ts:821](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L821)

***

### notDissolvingNeuronsStakedMaturityE8sEquivalentSum

> **notDissolvingNeuronsStakedMaturityE8sEquivalentSum**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:816](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L816)

***

### publicNeuronSubsetMetrics

> **publicNeuronSubsetMetrics**: [`Option`](../type-aliases/Option.md)\<[`NeuronSubsetMetrics`](NeuronSubsetMetrics.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:832](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L832)

***

### seedNeuronCount

> **seedNeuronCount**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:834](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L834)

***

### spawningNeuronsCount

> **spawningNeuronsCount**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:813](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L813)

***

### timestampSeconds

> **timestampSeconds**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:833](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L833)

***

### totalLockedE8s

> **totalLockedE8s**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:808](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L808)

***

### totalMaturityE8sEquivalent

> **totalMaturityE8sEquivalent**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:791](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L791)

***

### totalStakedE8s

> **totalStakedE8s**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:805](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L805)

***

### totalStakedE8sEct

> **totalStakedE8sEct**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:815](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L815)

***

### totalStakedE8sNonSelfAuthenticatingController

> **totalStakedE8sNonSelfAuthenticatingController**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:818](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L818)

***

### totalStakedE8sSeed

> **totalStakedE8sSeed**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:803](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L803)

***

### totalStakedMaturityE8sEquivalent

> **totalStakedMaturityE8sEquivalent**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:811](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L811)

***

### totalStakedMaturityE8sEquivalentEct

> **totalStakedMaturityE8sEquivalentEct**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:804](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L804)

***

### totalStakedMaturityE8sEquivalentSeed

> **totalStakedMaturityE8sEquivalentSeed**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:829](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L829)

***

### totalSupplyIcp

> **totalSupplyIcp**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:799](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L799)

***

### totalVotingPowerNonSelfAuthenticatingController

> **totalVotingPowerNonSelfAuthenticatingController**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:810](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L810)
