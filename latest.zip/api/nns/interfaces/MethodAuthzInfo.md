---
title: MethodAuthzInfo
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:339](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L339)

## Properties

### methodName

> **methodName**: `string`

Defined in: [packages/nns/src/types/governance\_converters.ts:340](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L340)

***

### principalIds

> **principalIds**: `ArrayBuffer`[]

Defined in: [packages/nns/src/types/governance\_converters.ts:341](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L341)
