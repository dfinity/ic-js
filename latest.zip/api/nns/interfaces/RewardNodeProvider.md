---
title: RewardNodeProvider
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:523](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L523)

## Properties

### amountE8s

> **amountE8s**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:526](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L526)

***

### nodeProvider

> **nodeProvider**: [`Option`](../type-aliases/Option.md)\<[`NodeProvider`](NodeProvider.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:524](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L524)

***

### rewardMode

> **rewardMode**: [`Option`](../type-aliases/Option.md)\<[`RewardMode`](../type-aliases/RewardMode.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:525](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L525)
