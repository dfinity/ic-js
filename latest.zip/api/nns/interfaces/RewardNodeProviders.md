---
title: RewardNodeProviders
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:506](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L506)

## Properties

### rewards

> **rewards**: [`RewardNodeProvider`](RewardNodeProvider.md)[]

Defined in: [packages/nns/src/types/governance\_converters.ts:508](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L508)

***

### useRegistryDerivedRewards

> **useRegistryDerivedRewards**: `boolean` \| `undefined`

Defined in: [packages/nns/src/types/governance\_converters.ts:507](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L507)
