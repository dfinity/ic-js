---
title: Configure
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:135](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L135)

## Properties

### operation

> **operation**: [`Option`](../type-aliases/Option.md)\<[`Operation`](../type-aliases/Operation.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:136](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L136)
