---
title: Spawn
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:531](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L531)

## Properties

### newController

> **newController**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:532](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L532)

***

### percentageToSpawn

> **percentageToSpawn**: `number` \| `undefined`

Defined in: [packages/nns/src/types/governance\_converters.ts:533](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L533)
