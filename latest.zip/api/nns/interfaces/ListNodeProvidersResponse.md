---
title: ListNodeProvidersResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:663](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L663)

## Properties

### nodeProviders

> **nodeProviders**: [`NodeProvider`](NodeProvider.md)[]

Defined in: [packages/nns/src/types/governance\_converters.ts:664](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L664)
