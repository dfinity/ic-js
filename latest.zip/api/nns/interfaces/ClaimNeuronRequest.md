---
title: ClaimNeuronRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:517](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L517)

## Properties

### dissolveDelayInSecs

> **dissolveDelayInSecs**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:520](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L520)

***

### nonce

> **nonce**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:519](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L519)

***

### publicKey

> **publicKey**: `DerEncodedPublicKey`

Defined in: [packages/nns/src/types/governance\_converters.ts:518](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L518)
