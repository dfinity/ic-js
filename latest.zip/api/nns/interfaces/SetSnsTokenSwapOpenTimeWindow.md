---
title: SetSnsTokenSwapOpenTimeWindow
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:367](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L367)

## Properties

### request

> **request**: [`Option`](../type-aliases/Option.md)\<\{ `openTimeWindow`: [`Option`](../type-aliases/Option.md)\<\{ `endTimestampSeconds`: `bigint`; `startTimestampSeconds`: `bigint`; \}\>; \}\>

Defined in: [packages/nns/src/types/governance\_converters.ts:368](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L368)

***

### swapCanisterId

> **swapCanisterId**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:374](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L374)
