---
title: SetSnsTokenSwapOpenTimeWindow
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:367](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L367)

## Properties

### request

> **request**: [`Option`](../type-aliases/Option.md)\<\{ `openTimeWindow`: [`Option`](../type-aliases/Option.md)\<\{ `endTimestampSeconds`: `bigint`; `startTimestampSeconds`: `bigint`; \}\>; \}\>

Defined in: [packages/nns/src/types/governance\_converters.ts:368](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L368)

***

### swapCanisterId

> **swapCanisterId**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:374](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L374)
