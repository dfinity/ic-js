---
title: ExecuteNnsFunction
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:166](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L166)

## Properties

### nnsFunctionId

> **nnsFunctionId**: `number`

Defined in: [packages/nns/src/types/governance\_converters.ts:167](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L167)

***

### payloadBytes?

> `optional` **payloadBytes**: `ArrayBuffer`

Defined in: [packages/nns/src/types/governance\_converters.ts:168](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L168)
