---
title: MakeExecuteNnsFunctionProposalRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:654](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L654)

## Properties

### neuronId

> **neuronId**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:655](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L655)

***

### nnsFunction

> **nnsFunction**: `number`

Defined in: [packages/nns/src/types/governance\_converters.ts:659](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L659)

***

### payload

> **payload**: `ArrayBuffer`

Defined in: [packages/nns/src/types/governance\_converters.ts:660](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L660)

***

### summary

> **summary**: `string`

Defined in: [packages/nns/src/types/governance\_converters.ts:657](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L657)

***

### title

> **title**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:656](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L656)

***

### url

> **url**: `string`

Defined in: [packages/nns/src/types/governance\_converters.ts:658](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L658)
