---
title: NetworkEconomics
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:376](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L376)

## Properties

### maximumNodeProviderRewards

> **maximumNodeProviderRewards**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:384](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L384)

***

### maxProposalsToKeepPerTopic

> **maxProposalsToKeepPerTopic**: `number`

Defined in: [packages/nns/src/types/governance\_converters.ts:378](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L378)

***

### minimumIcpXdrRate

> **minimumIcpXdrRate**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:383](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L383)

***

### neuronManagementFeePerProposal

> **neuronManagementFeePerProposal**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:379](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L379)

***

### neuronMinimumStake

> **neuronMinimumStake**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:377](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L377)

***

### neuronsFundEconomics

> **neuronsFundEconomics**: [`Option`](../type-aliases/Option.md)\<[`NeuronsFundEconomics`](NeuronsFundEconomics.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:385](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L385)

***

### neuronSpawnDissolveDelaySeconds

> **neuronSpawnDissolveDelaySeconds**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:382](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L382)

***

### rejectCost

> **rejectCost**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:380](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L380)

***

### transactionFee

> **transactionFee**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:381](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L381)

***

### votingPowerEconomics

> **votingPowerEconomics**: [`Option`](../type-aliases/Option.md)\<[`VotingPowerEconomics`](VotingPowerEconomics.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:386](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L386)
