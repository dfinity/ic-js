---
title: RewardToNeuron
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:513](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L513)

## Properties

### dissolveDelaySeconds

> **dissolveDelaySeconds**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:514](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L514)
