---
title: VotingPowerEconomics
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:388](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L388)

## Properties

### clearFollowingAfterSeconds

> **clearFollowingAfterSeconds**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:391](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L391)

***

### neuronMinimumDissolveDelayToVoteSeconds

> **neuronMinimumDissolveDelayToVoteSeconds**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:390](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L390)

***

### startReducingVotingPowerAfterSeconds

> **startReducingVotingPowerAfterSeconds**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:389](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L389)
