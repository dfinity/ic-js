---
title: SpawnRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:582](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L582)

## Properties

### neuronId

> **neuronId**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:583](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L583)

***

### newController

> **newController**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:584](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L584)

***

### percentageToSpawn?

> `optional` **percentageToSpawn**: `number`

Defined in: [packages/nns/src/types/governance\_converters.ts:585](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L585)
