---
title: Neuron
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:407](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L407)

## Properties

### accountIdentifier

> **accountIdentifier**: `string`

Defined in: [packages/nns/src/types/governance\_converters.ts:423](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L423)

***

### agingSinceTimestampSeconds

> **agingSinceTimestampSeconds**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:419](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L419)

***

### autoStakeMaturity

> **autoStakeMaturity**: [`Option`](../type-aliases/Option.md)\<`boolean`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:417](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L417)

***

### cachedNeuronStake

> **cachedNeuronStake**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:415](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L415)

***

### controller

> **controller**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:411](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L411)

***

### createdTimestampSeconds

> **createdTimestampSeconds**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:416](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L416)

***

### decidingVotingPower

> **decidingVotingPower**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:431](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L431)

***

### dissolveState

> **dissolveState**: [`Option`](../type-aliases/Option.md)\<[`DissolveState`](../type-aliases/DissolveState.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:426](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L426)

***

### followees

> **followees**: [`Followees`](Followees.md)[]

Defined in: [packages/nns/src/types/governance\_converters.ts:427](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L427)

***

### hotKeys

> **hotKeys**: `string`[]

Defined in: [packages/nns/src/types/governance\_converters.ts:422](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L422)

***

### id

> **id**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:408](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L408)

***

### joinedCommunityFundTimestampSeconds

> **joinedCommunityFundTimestampSeconds**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:424](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L424)

***

### kycVerified

> **kycVerified**: `boolean`

Defined in: [packages/nns/src/types/governance\_converters.ts:413](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L413)

***

### maturityDisbursementsInProgress

> **maturityDisbursementsInProgress**: [`Option`](../type-aliases/Option.md)\<[`MaturityDisbursement`](MaturityDisbursement.md)[]\>

Defined in: [packages/nns/src/types/governance\_converters.ts:425](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L425)

***

### maturityE8sEquivalent

> **maturityE8sEquivalent**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:418](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L418)

***

### neuronFees

> **neuronFees**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:421](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L421)

***

### neuronType

> **neuronType**: [`Option`](../type-aliases/Option.md)\<[`NeuronType`](../enumerations/NeuronType.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:409](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L409)

***

### notForProfit

> **notForProfit**: `boolean`

Defined in: [packages/nns/src/types/governance\_converters.ts:414](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L414)

***

### potentialVotingPower

> **potentialVotingPower**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:430](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L430)

***

### recentBallots

> **recentBallots**: [`BallotInfo`](BallotInfo.md)[]

Defined in: [packages/nns/src/types/governance\_converters.ts:412](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L412)

***

### spawnAtTimesSeconds

> **spawnAtTimesSeconds**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:420](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L420)

***

### stakedMaturityE8sEquivalent

> **stakedMaturityE8sEquivalent**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:410](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L410)

***

### visibility

> **visibility**: [`Option`](../type-aliases/Option.md)\<[`NeuronVisibility`](../enumerations/NeuronVisibility.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:428](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L428)

***

### votingPowerRefreshedTimestampSeconds

> **votingPowerRefreshedTimestampSeconds**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:429](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L429)
