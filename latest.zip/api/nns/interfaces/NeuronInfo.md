---
title: NeuronInfo
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:436](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L436)

## Properties

### ageSeconds

> **ageSeconds**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:449](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L449)

***

### createdTimestampSeconds

> **createdTimestampSeconds**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:441](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L441)

***

### decidingVotingPower

> **decidingVotingPower**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:447](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L447)

***

### dissolveDelaySeconds

> **dissolveDelaySeconds**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:438](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L438)

***

### fullNeuron

> **fullNeuron**: [`Option`](../type-aliases/Option.md)\<[`Neuron`](Neuron.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:450](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L450)

***

### joinedCommunityFundTimestampSeconds

> **joinedCommunityFundTimestampSeconds**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:443](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L443)

***

### neuronId

> **neuronId**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:437](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L437)

***

### neuronType

> **neuronType**: [`Option`](../type-aliases/Option.md)\<[`NeuronType`](../enumerations/NeuronType.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:440](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L440)

***

### potentialVotingPower

> **potentialVotingPower**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:448](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L448)

***

### recentBallots

> **recentBallots**: [`BallotInfo`](BallotInfo.md)[]

Defined in: [packages/nns/src/types/governance\_converters.ts:439](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L439)

***

### retrievedAtTimestampSeconds

> **retrievedAtTimestampSeconds**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:444](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L444)

***

### state

> **state**: [`NeuronState`](../enumerations/NeuronState.md)

Defined in: [packages/nns/src/types/governance\_converters.ts:442](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L442)

***

### visibility

> **visibility**: [`Option`](../type-aliases/Option.md)\<[`NeuronVisibility`](../enumerations/NeuronVisibility.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:451](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L451)

***

### votingPower

> **votingPower**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:445](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L445)

***

### votingPowerRefreshedTimestampSeconds

> **votingPowerRefreshedTimestampSeconds**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:446](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L446)
