---
title: MergeMaturityResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:329](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L329)

## Properties

### mergedMaturityE8s

> **mergedMaturityE8s**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:330](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L330)

***

### newStakeE8s

> **newStakeE8s**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:331](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L331)
