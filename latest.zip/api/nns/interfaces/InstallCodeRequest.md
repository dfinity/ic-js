---
title: InstallCodeRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:283](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L283)

## Properties

### arg

> **arg**: `ArrayBuffer`

Defined in: [packages/nns/src/types/governance\_converters.ts:284](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L284)

***

### canisterId

> **canisterId**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:287](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L287)

***

### installMode

> **installMode**: [`Option`](../type-aliases/Option.md)\<[`CanisterInstallMode`](../enumerations/CanisterInstallMode.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:288](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L288)

***

### skipStoppingBeforeInstalling

> **skipStoppingBeforeInstalling**: [`Option`](../type-aliases/Option.md)\<`boolean`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:286](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L286)

***

### wasmModule

> **wasmModule**: `ArrayBuffer`

Defined in: [packages/nns/src/types/governance\_converters.ts:285](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L285)
