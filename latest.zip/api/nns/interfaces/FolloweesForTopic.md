---
title: FolloweesForTopic
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:156](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L156)

## Properties

### followees

> **followees**: `bigint`[]

Defined in: [packages/nns/src/types/governance\_converters.ts:158](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L158)

***

### topic

> **topic**: [`Topic`](../enumerations/Topic.md)

Defined in: [packages/nns/src/types/governance\_converters.ts:157](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L157)
