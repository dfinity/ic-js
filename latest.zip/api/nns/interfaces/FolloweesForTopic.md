---
title: FolloweesForTopic
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:156](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L156)

## Properties

### followees

> **followees**: `bigint`[]

Defined in: [packages/nns/src/types/governance\_converters.ts:158](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L158)

***

### topic

> **topic**: [`Topic`](../enumerations/Topic.md)

Defined in: [packages/nns/src/types/governance\_converters.ts:157](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L157)
