---
title: FolloweesForTopic
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:156](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L156)

## Properties

### followees

> **followees**: `bigint`[]

Defined in: [packages/nns/src/types/governance\_converters.ts:158](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L158)

***

### topic

> **topic**: [`Topic`](../enumerations/Topic.md)

Defined in: [packages/nns/src/types/governance\_converters.ts:157](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L157)
