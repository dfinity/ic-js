---
title: CreateServiceNervousSystem
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:760](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L760)

## Properties

### dappCanisters

> **dappCanisters**: `string`[]

Defined in: [packages/nns/src/types/governance\_converters.ts:768](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L768)

***

### description

> **description**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:767](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L767)

***

### fallbackControllerPrincipalIds

> **fallbackControllerPrincipalIds**: `string`[]

Defined in: [packages/nns/src/types/governance\_converters.ts:763](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L763)

***

### governanceParameters

> **governanceParameters**: [`Option`](../type-aliases/Option.md)\<[`GovernanceParameters`](GovernanceParameters.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:762](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L762)

***

### initialTokenDistribution

> **initialTokenDistribution**: [`Option`](../type-aliases/Option.md)\<[`InitialTokenDistribution`](InitialTokenDistribution.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:770](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L770)

***

### ledgerParameters

> **ledgerParameters**: [`Option`](../type-aliases/Option.md)\<[`LedgerParameters`](LedgerParameters.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:766](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L766)

***

### logo

> **logo**: [`Option`](../type-aliases/Option.md)\<[`Image`](Image.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:764](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L764)

***

### name

> **name**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:765](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L765)

***

### swapParameters

> **swapParameters**: [`Option`](../type-aliases/Option.md)\<[`SwapParameters`](SwapParameters.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:769](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L769)

***

### url

> **url**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:761](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L761)
