---
title: GovernanceCanisterOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance.options.ts:5](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance.options.ts#L5)

## Extends

- `CanisterOptions`\<`GovernanceService`\>

## Properties

### agent?

> `optional` **agent**: `Agent`

Defined in: packages/utils/dist/types/canister.options.d.ts:4

#### Inherited from

`CanisterOptions.agent`

***

### canisterId?

> `optional` **canisterId**: `Principal`

Defined in: packages/utils/dist/types/canister.options.d.ts:5

#### Inherited from

`CanisterOptions.canisterId`

***

### certifiedServiceOverride?

> `optional` **certifiedServiceOverride**: `ActorSubclass`\<`_SERVICE`\>

Defined in: packages/utils/dist/types/canister.options.d.ts:7

#### Inherited from

`CanisterOptions.certifiedServiceOverride`

***

### hardwareWallet?

> `optional` **hardwareWallet**: `boolean`

Defined in: [packages/nns/src/types/governance.options.ts:9](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance.options.ts#L9)

***

### oldListNeuronsServiceOverride?

> `optional` **oldListNeuronsServiceOverride**: `ActorSubclass`\<`_SERVICE`\>

Defined in: [packages/nns/src/types/governance.options.ts:10](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance.options.ts#L10)

***

### serviceOverride?

> `optional` **serviceOverride**: `ActorSubclass`\<`_SERVICE`\>

Defined in: packages/utils/dist/types/canister.options.d.ts:6

#### Inherited from

`CanisterOptions.serviceOverride`
