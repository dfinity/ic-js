---
title: DisburseMaturity
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:183](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L183)

## Properties

### percentageToDisburse

> **percentageToDisburse**: `number`

Defined in: [packages/nns/src/types/governance\_converters.ts:186](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L186)

***

### toAccount

> **toAccount**: [`Option`](../type-aliases/Option.md)\<[`Account`](Account.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:184](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L184)

***

### toAccountIdentifier

> **toAccountIdentifier**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:185](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L185)
