---
title: Follow
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:170](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L170)

## Properties

### followees

> **followees**: `bigint`[]

Defined in: [packages/nns/src/types/governance\_converters.ts:172](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L172)

***

### topic

> **topic**: [`Topic`](../enumerations/Topic.md)

Defined in: [packages/nns/src/types/governance\_converters.ts:171](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L171)
