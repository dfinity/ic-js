---
title: NeuronsFundMatchedFundingCurveCoefficients
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:399](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L399)

## Properties

### contributionThresholdXdr

> **contributionThresholdXdr**: [`Option`](../type-aliases/Option.md)\<[`Decimal`](Decimal.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:400](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L400)

***

### fullParticipationMilestoneXdr

> **fullParticipationMilestoneXdr**: [`Option`](../type-aliases/Option.md)\<[`Decimal`](Decimal.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:402](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L402)

***

### oneThirdParticipationMilestoneXdr

> **oneThirdParticipationMilestoneXdr**: [`Option`](../type-aliases/Option.md)\<[`Decimal`](Decimal.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:401](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L401)
