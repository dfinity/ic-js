---
title: NeuronsFundMatchedFundingCurveCoefficients
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:399](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L399)

## Properties

### contributionThresholdXdr

> **contributionThresholdXdr**: [`Option`](../type-aliases/Option.md)\<[`Decimal`](Decimal.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:400](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L400)

***

### fullParticipationMilestoneXdr

> **fullParticipationMilestoneXdr**: [`Option`](../type-aliases/Option.md)\<[`Decimal`](Decimal.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:402](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L402)

***

### oneThirdParticipationMilestoneXdr

> **oneThirdParticipationMilestoneXdr**: [`Option`](../type-aliases/Option.md)\<[`Decimal`](Decimal.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:401](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L401)
