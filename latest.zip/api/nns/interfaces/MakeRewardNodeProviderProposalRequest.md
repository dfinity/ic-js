---
title: MakeRewardNodeProviderProposalRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:636](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L636)

## Properties

### amount

> **amount**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:642](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L642)

***

### neuronId

> **neuronId**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:637](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L637)

***

### nodeProvider

> **nodeProvider**: `string`

Defined in: [packages/nns/src/types/governance\_converters.ts:641](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L641)

***

### rewardMode

> **rewardMode**: [`Option`](../type-aliases/Option.md)\<[`RewardMode`](../type-aliases/RewardMode.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:643](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L643)

***

### summary

> **summary**: `string`

Defined in: [packages/nns/src/types/governance\_converters.ts:639](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L639)

***

### title

> **title**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:638](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L638)

***

### url

> **url**: `string`

Defined in: [packages/nns/src/types/governance\_converters.ts:640](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L640)
