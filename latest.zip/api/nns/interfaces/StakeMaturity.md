---
title: StakeMaturity
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:319](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L319)

## Properties

### percentageToStake

> **percentageToStake**: [`Option`](../type-aliases/Option.md)\<`number`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:320](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L320)
