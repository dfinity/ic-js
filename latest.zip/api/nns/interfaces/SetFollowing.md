---
title: SetFollowing
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:160](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L160)

## Properties

### topicFollowing

> **topicFollowing**: [`FolloweesForTopic`](FolloweesForTopic.md)[]

Defined in: [packages/nns/src/types/governance\_converters.ts:161](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L161)
