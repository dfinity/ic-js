---
title: NeuronDistribution
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:742](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L742)

## Properties

### controller

> **controller**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:743](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L743)

***

### dissolveDelay

> **dissolveDelay**: [`Option`](../type-aliases/Option.md)\<[`Duration`](Duration.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:744](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L744)

***

### memo

> **memo**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:745](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L745)

***

### stake

> **stake**: [`Option`](../type-aliases/Option.md)\<[`Tokens`](Tokens.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:747](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L747)

***

### vestingPeriod

> **vestingPeriod**: [`Option`](../type-aliases/Option.md)\<[`Duration`](Duration.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:746](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L746)
