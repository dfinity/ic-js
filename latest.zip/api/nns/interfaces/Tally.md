---
title: Tally
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:540](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L540)

## Properties

### no

> **no**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:541](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L541)

***

### timestampSeconds

> **timestampSeconds**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:544](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L544)

***

### total

> **total**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:543](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L543)

***

### yes

> **yes**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:542](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L542)
