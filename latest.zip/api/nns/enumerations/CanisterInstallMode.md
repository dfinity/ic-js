---
title: CanisterInstallMode
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/enums/governance.enums.ts:189](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L189)

## Enumeration Members

### Install

> **Install**: `1`

Defined in: [packages/nns/src/enums/governance.enums.ts:191](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L191)

***

### Reinstall

> **Reinstall**: `2`

Defined in: [packages/nns/src/enums/governance.enums.ts:192](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L192)

***

### Unspecified

> **Unspecified**: `0`

Defined in: [packages/nns/src/enums/governance.enums.ts:190](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L190)

***

### Upgrade

> **Upgrade**: `3`

Defined in: [packages/nns/src/enums/governance.enums.ts:193](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L193)
