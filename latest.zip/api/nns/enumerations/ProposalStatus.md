---
title: ProposalStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/enums/governance.enums.ts:62](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/enums/governance.enums.ts#L62)

## Enumeration Members

### Accepted

> **Accepted**: `3`

Defined in: [packages/nns/src/enums/governance.enums.ts:73](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/enums/governance.enums.ts#L73)

***

### Executed

> **Executed**: `4`

Defined in: [packages/nns/src/enums/governance.enums.ts:76](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/enums/governance.enums.ts#L76)

***

### Failed

> **Failed**: `5`

Defined in: [packages/nns/src/enums/governance.enums.ts:79](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/enums/governance.enums.ts#L79)

***

### Open

> **Open**: `1`

Defined in: [packages/nns/src/enums/governance.enums.ts:66](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/enums/governance.enums.ts#L66)

***

### Rejected

> **Rejected**: `2`

Defined in: [packages/nns/src/enums/governance.enums.ts:69](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/enums/governance.enums.ts#L69)

***

### Unknown

> **Unknown**: `0`

Defined in: [packages/nns/src/enums/governance.enums.ts:63](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/enums/governance.enums.ts#L63)
