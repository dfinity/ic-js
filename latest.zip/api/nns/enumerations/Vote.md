---
title: Vote
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/enums/governance.enums.ts:82](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/enums/governance.enums.ts#L82)

## Enumeration Members

### No

> **No**: `2`

Defined in: [packages/nns/src/enums/governance.enums.ts:85](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/enums/governance.enums.ts#L85)

***

### Unspecified

> **Unspecified**: `0`

Defined in: [packages/nns/src/enums/governance.enums.ts:83](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/enums/governance.enums.ts#L83)

***

### Yes

> **Yes**: `1`

Defined in: [packages/nns/src/enums/governance.enums.ts:84](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/enums/governance.enums.ts#L84)
