---
title: Topic
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/enums/governance.enums.ts:15](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L15)

## Enumeration Members

### ApiBoundaryNodeManagement

> **ApiBoundaryNodeManagement**: `15`

Defined in: [packages/nns/src/enums/governance.enums.ts:34](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L34)

***

### ExchangeRate

> **ExchangeRate**: `2`

Defined in: [packages/nns/src/enums/governance.enums.ts:18](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L18)

***

### Governance

> **Governance**: `4`

Defined in: [packages/nns/src/enums/governance.enums.ts:20](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L20)

***

### IcOsVersionDeployment

> **IcOsVersionDeployment**: `12`

Defined in: [packages/nns/src/enums/governance.enums.ts:31](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L31)

***

### IcOsVersionElection

> **IcOsVersionElection**: `13`

Defined in: [packages/nns/src/enums/governance.enums.ts:32](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L32)

***

### Kyc

> **Kyc**: `9`

Defined in: [packages/nns/src/enums/governance.enums.ts:25](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L25)

***

### NetworkCanisterManagement

> **NetworkCanisterManagement**: `8`

Defined in: [packages/nns/src/enums/governance.enums.ts:24](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L24)

***

### NetworkEconomics

> **NetworkEconomics**: `3`

Defined in: [packages/nns/src/enums/governance.enums.ts:19](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L19)

***

### NeuronManagement

> **NeuronManagement**: `1`

Defined in: [packages/nns/src/enums/governance.enums.ts:17](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L17)

***

### NodeAdmin

> **NodeAdmin**: `5`

Defined in: [packages/nns/src/enums/governance.enums.ts:21](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L21)

***

### NodeProviderRewards

> **NodeProviderRewards**: `10`

Defined in: [packages/nns/src/enums/governance.enums.ts:26](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L26)

***

### ParticipantManagement

> **ParticipantManagement**: `6`

Defined in: [packages/nns/src/enums/governance.enums.ts:22](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L22)

***

### ProtocolCanisterManagement

> **ProtocolCanisterManagement**: `17`

Defined in: [packages/nns/src/enums/governance.enums.ts:36](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L36)

***

### ServiceNervousSystemManagement

> **ServiceNervousSystemManagement**: `18`

Defined in: [packages/nns/src/enums/governance.enums.ts:37](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L37)

***

### SnsAndCommunityFund

> **SnsAndCommunityFund**: `14`

Defined in: [packages/nns/src/enums/governance.enums.ts:33](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L33)

***

### ~~SnsDecentralizationSale~~

> **SnsDecentralizationSale**: `11`

Defined in: [packages/nns/src/enums/governance.enums.ts:30](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L30)

#### Deprecated

***

### SubnetManagement

> **SubnetManagement**: `7`

Defined in: [packages/nns/src/enums/governance.enums.ts:23](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L23)

***

### SubnetRental

> **SubnetRental**: `16`

Defined in: [packages/nns/src/enums/governance.enums.ts:35](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L35)

***

### Unspecified

> **Unspecified**: `0`

Defined in: [packages/nns/src/enums/governance.enums.ts:16](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L16)
