---
title: NnsFunction
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/enums/governance.enums.ts:88](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L88)

## Enumeration Members

### AddApiBoundaryNodes

> **AddApiBoundaryNodes**: `43`

Defined in: [packages/nns/src/enums/governance.enums.ts:132](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L132)

***

### AddFirewallRules

> **AddFirewallRules**: `25`

Defined in: [packages/nns/src/enums/governance.enums.ts:114](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L114)

***

### AddNodeToSubnet

> **AddNodeToSubnet**: `2`

Defined in: [packages/nns/src/enums/governance.enums.ts:91](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L91)

***

### AddOrRemoveDataCenters

> **AddOrRemoveDataCenters**: `21`

Defined in: [packages/nns/src/enums/governance.enums.ts:110](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L110)

***

### AddSnsWasm

> **AddSnsWasm**: `30`

Defined in: [packages/nns/src/enums/governance.enums.ts:119](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L119)

***

### AssignNoid

> **AssignNoid**: `8`

Defined in: [packages/nns/src/enums/governance.enums.ts:97](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L97)

***

### BitcoinSetConfig

> **BitcoinSetConfig**: `39`

Defined in: [packages/nns/src/enums/governance.enums.ts:128](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L128)

***

### BlessReplicaVersion

> **BlessReplicaVersion**: `5`

Defined in: [packages/nns/src/enums/governance.enums.ts:94](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L94)

***

### ChangeSubnetMembership

> **ChangeSubnetMembership**: `31`

Defined in: [packages/nns/src/enums/governance.enums.ts:120](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L120)

***

### ChangeSubnetTypeAssignment

> **ChangeSubnetTypeAssignment**: `33`

Defined in: [packages/nns/src/enums/governance.enums.ts:122](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L122)

***

### ClearProvisionalWhitelist

> **ClearProvisionalWhitelist**: `12`

Defined in: [packages/nns/src/enums/governance.enums.ts:101](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L101)

***

### CompleteCanisterMigration

> **CompleteCanisterMigration**: `29`

Defined in: [packages/nns/src/enums/governance.enums.ts:118](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L118)

***

### CreateSubnet

> **CreateSubnet**: `1`

Defined in: [packages/nns/src/enums/governance.enums.ts:90](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L90)

***

### DeployGuestosToAllSubnetNodes

> **DeployGuestosToAllSubnetNodes**: `11`

Defined in: [packages/nns/src/enums/governance.enums.ts:100](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L100)

***

### DeployGuestosToAllUnassignedNodes

> **DeployGuestosToAllUnassignedNodes**: `48`

Defined in: [packages/nns/src/enums/governance.enums.ts:140](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L140)

***

### DeployGuestosToSomeApiBoundaryNodes

> **DeployGuestosToSomeApiBoundaryNodes**: `47`

Defined in: [packages/nns/src/enums/governance.enums.ts:139](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L139)

***

### DeployHostosToSomeNodes

> **DeployHostosToSomeNodes**: `51`

Defined in: [packages/nns/src/enums/governance.enums.ts:143](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L143)

***

### HardResetNnsRootToVersion

> **HardResetNnsRootToVersion**: `42`

Defined in: [packages/nns/src/enums/governance.enums.ts:131](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L131)

***

### IcpXdrConversionRate

> **IcpXdrConversionRate**: `10`

Defined in: [packages/nns/src/enums/governance.enums.ts:99](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L99)

***

### InsertSnsWasmUpgradePathEntries

> **InsertSnsWasmUpgradePathEntries**: `37`

Defined in: [packages/nns/src/enums/governance.enums.ts:126](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L126)

***

### NnsCanisterInstall

> **NnsCanisterInstall**: `3`

Defined in: [packages/nns/src/enums/governance.enums.ts:92](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L92)

***

### NnsCanisterUpgrade

> **NnsCanisterUpgrade**: `4`

Defined in: [packages/nns/src/enums/governance.enums.ts:93](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L93)

***

### NnsRootUpgrade

> **NnsRootUpgrade**: `9`

Defined in: [packages/nns/src/enums/governance.enums.ts:98](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L98)

***

### PauseCanisterMigrations

> **PauseCanisterMigrations**: `53`

Defined in: [packages/nns/src/enums/governance.enums.ts:145](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L145)

***

### PrepareCanisterMigration

> **PrepareCanisterMigration**: `28`

Defined in: [packages/nns/src/enums/governance.enums.ts:117](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L117)

***

### RecoverSubnet

> **RecoverSubnet**: `6`

Defined in: [packages/nns/src/enums/governance.enums.ts:95](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L95)

***

### RemoveApiBoundaryNodes

> **RemoveApiBoundaryNodes**: `44`

Defined in: [packages/nns/src/enums/governance.enums.ts:133](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L133)

***

### RemoveFirewallRules

> **RemoveFirewallRules**: `26`

Defined in: [packages/nns/src/enums/governance.enums.ts:115](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L115)

***

### RemoveNodeOperators

> **RemoveNodeOperators**: `23`

Defined in: [packages/nns/src/enums/governance.enums.ts:112](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L112)

***

### RemoveNodes

> **RemoveNodes**: `18`

Defined in: [packages/nns/src/enums/governance.enums.ts:107](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L107)

***

### RemoveNodesFromSubnet

> **RemoveNodesFromSubnet**: `13`

Defined in: [packages/nns/src/enums/governance.enums.ts:102](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L102)

***

### RerouteCanisterRanges

> **RerouteCanisterRanges**: `24`

Defined in: [packages/nns/src/enums/governance.enums.ts:113](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L113)

***

### RetireReplicaVersion

> **RetireReplicaVersion**: `36`

Defined in: [packages/nns/src/enums/governance.enums.ts:125](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L125)

***

### ReviseElectedGuestosVersions

> **ReviseElectedGuestosVersions**: `38`

Defined in: [packages/nns/src/enums/governance.enums.ts:127](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L127)

***

### ReviseElectedHostosVersions

> **ReviseElectedHostosVersions**: `50`

Defined in: [packages/nns/src/enums/governance.enums.ts:142](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L142)

***

### SetAuthorizedSubnetworks

> **SetAuthorizedSubnetworks**: `14`

Defined in: [packages/nns/src/enums/governance.enums.ts:103](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L103)

***

### SetFirewallConfig

> **SetFirewallConfig**: `15`

Defined in: [packages/nns/src/enums/governance.enums.ts:104](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L104)

***

### SetSubnetOperationalLevel

> **SetSubnetOperationalLevel**: `55`

Defined in: [packages/nns/src/enums/governance.enums.ts:147](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L147)

***

### StopOrStartNnsCanister

> **StopOrStartNnsCanister**: `17`

Defined in: [packages/nns/src/enums/governance.enums.ts:106](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L106)

***

### SubnetRentalRequest

> **SubnetRentalRequest**: `52`

Defined in: [packages/nns/src/enums/governance.enums.ts:144](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L144)

***

### UninstallCode

> **UninstallCode**: `19`

Defined in: [packages/nns/src/enums/governance.enums.ts:108](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L108)

***

### UnpauseCanisterMigrations

> **UnpauseCanisterMigrations**: `54`

Defined in: [packages/nns/src/enums/governance.enums.ts:146](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L146)

***

### Unspecified

> **Unspecified**: `0`

Defined in: [packages/nns/src/enums/governance.enums.ts:89](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L89)

***

### UpdateAllowedPrincipals

> **UpdateAllowedPrincipals**: `35`

Defined in: [packages/nns/src/enums/governance.enums.ts:124](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L124)

***

### ~~UpdateApiBoundaryNodeDomain~~

> **UpdateApiBoundaryNodeDomain**: `45`

Defined in: [packages/nns/src/enums/governance.enums.ts:137](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L137)

#### Deprecated

***

### UpdateApiBoundaryNodesVersion

> **UpdateApiBoundaryNodesVersion**: `46`

Defined in: [packages/nns/src/enums/governance.enums.ts:138](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L138)

***

### UpdateConfigOfSubnet

> **UpdateConfigOfSubnet**: `7`

Defined in: [packages/nns/src/enums/governance.enums.ts:96](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L96)

***

### UpdateElectedHostosVersions

> **UpdateElectedHostosVersions**: `40`

Defined in: [packages/nns/src/enums/governance.enums.ts:129](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L129)

***

### UpdateFirewallRules

> **UpdateFirewallRules**: `27`

Defined in: [packages/nns/src/enums/governance.enums.ts:116](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L116)

***

### UpdateNodeOperatorConfig

> **UpdateNodeOperatorConfig**: `16`

Defined in: [packages/nns/src/enums/governance.enums.ts:105](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L105)

***

### UpdateNodeRewardsTable

> **UpdateNodeRewardsTable**: `20`

Defined in: [packages/nns/src/enums/governance.enums.ts:109](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L109)

***

### UpdateNodesHostosVersion

> **UpdateNodesHostosVersion**: `41`

Defined in: [packages/nns/src/enums/governance.enums.ts:130](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L130)

***

### UpdateSnsWasmSnsSubnetIds

> **UpdateSnsWasmSnsSubnetIds**: `34`

Defined in: [packages/nns/src/enums/governance.enums.ts:123](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L123)

***

### UpdateSshReadOnlyAccessForAllUnassignedNodes

> **UpdateSshReadOnlyAccessForAllUnassignedNodes**: `49`

Defined in: [packages/nns/src/enums/governance.enums.ts:141](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L141)

***

### UpdateSubnetType

> **UpdateSubnetType**: `32`

Defined in: [packages/nns/src/enums/governance.enums.ts:121](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L121)

***

### UpdateUnassignedNodesConfig

> **UpdateUnassignedNodesConfig**: `22`

Defined in: [packages/nns/src/enums/governance.enums.ts:111](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L111)
