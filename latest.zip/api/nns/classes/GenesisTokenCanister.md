---
title: GenesisTokenCanister
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/genesis\_token.canister.ts:9](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/genesis_token.canister.ts#L9)

## Methods

### claimNeurons()

> **claimNeurons**(`__namedParameters`): `Promise`\<`bigint`[]\>

Defined in: [packages/nns/src/genesis\_token.canister.ts:27](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/genesis_token.canister.ts#L27)

#### Parameters

##### \_\_namedParameters

###### hexPubKey

`string`

#### Returns

`Promise`\<`bigint`[]\>

***

### create()

> `static` **create**(`options`): `GenesisTokenCanister`

Defined in: [packages/nns/src/genesis\_token.canister.ts:14](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/genesis_token.canister.ts#L14)

#### Parameters

##### options

`CanisterOptions`\<`_SERVICE`\> = `{}`

#### Returns

`GenesisTokenCanister`
