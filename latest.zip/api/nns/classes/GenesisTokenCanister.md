---
title: GenesisTokenCanister
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/genesis\_token.canister.ts:9](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/genesis_token.canister.ts#L9)

## Methods

### claimNeurons()

> **claimNeurons**(`__namedParameters`): `Promise`\<`bigint`[]\>

Defined in: [packages/nns/src/genesis\_token.canister.ts:27](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/genesis_token.canister.ts#L27)

#### Parameters

##### \_\_namedParameters

###### hexPubKey

`string`

#### Returns

`Promise`\<`bigint`[]\>

***

### create()

> `static` **create**(`options`): `GenesisTokenCanister`

Defined in: [packages/nns/src/genesis\_token.canister.ts:14](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/genesis_token.canister.ts#L14)

#### Parameters

##### options

`CanisterOptions`\<`_SERVICE`\> = `{}`

#### Returns

`GenesisTokenCanister`
