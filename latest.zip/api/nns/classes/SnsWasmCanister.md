---
title: SnsWasmCanister
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/sns\_wasm.canister.ts:10](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/sns_wasm.canister.ts#L10)

## Methods

### listSnses()

> **listSnses**(`__namedParameters`): `Promise`\<[`DeployedSns`](../interfaces/DeployedSns.md)[]\>

Defined in: [packages/nns/src/sns\_wasm.canister.ts:29](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/sns_wasm.canister.ts#L29)

#### Parameters

##### \_\_namedParameters

###### certified?

`boolean` = `true`

#### Returns

`Promise`\<[`DeployedSns`](../interfaces/DeployedSns.md)[]\>

***

### create()

> `static` **create**(`options`): `SnsWasmCanister`

Defined in: [packages/nns/src/sns\_wasm.canister.ts:16](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/sns_wasm.canister.ts#L16)

#### Parameters

##### options

`CanisterOptions`\<`_SERVICE`\> = `{}`

#### Returns

`SnsWasmCanister`
