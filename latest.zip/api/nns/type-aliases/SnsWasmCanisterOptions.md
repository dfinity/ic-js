---
title: SnsWasmCanisterOptions
editUrl: false
next: true
prev: true
---

> **SnsWasmCanisterOptions** = `CanisterOptions`\<`SnsWasmService`\>

Defined in: [packages/nns/src/types/sns\_wasm.options.ts:4](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/sns_wasm.options.ts#L4)
