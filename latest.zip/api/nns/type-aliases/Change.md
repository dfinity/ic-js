---
title: Change
editUrl: false
next: true
prev: true
---

> **Change** = \{ `ToRemove`: [`NodeProvider`](../interfaces/NodeProvider.md); \} \| \{ `ToAdd`: [`NodeProvider`](../interfaces/NodeProvider.md); \}

Defined in: [packages/nns/src/types/governance\_converters.ts:91](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L91)
