---
title: Option
editUrl: false
next: true
prev: true
---

> **Option**\<`T`\> = `T` \| `undefined`

Defined in: [packages/nns/src/types/common.ts:7](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/common.ts#L7)

## Type Parameters

### T

`T`
