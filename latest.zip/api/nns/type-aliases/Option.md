---
title: Option
editUrl: false
next: true
prev: true
---

> **Option**\<`T`\> = `T` \| `undefined`

Defined in: [packages/nns/src/types/common.ts:7](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/common.ts#L7)

## Type Parameters

### T

`T`
