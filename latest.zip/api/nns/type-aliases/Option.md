---
title: Option
editUrl: false
next: true
prev: true
---

> **Option**\<`T`\> = `T` \| `undefined`

Defined in: [packages/nns/src/types/common.ts:7](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/common.ts#L7)

## Type Parameters

### T

`T`
