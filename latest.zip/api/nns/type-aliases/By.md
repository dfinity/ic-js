---
title: By
editUrl: false
next: true
prev: true
---

> **By** = \{ `NeuronIdOrSubaccount`: `Record`\<`string`, `never`\>; \} \| \{ `MemoAndController`: [`ClaimOrRefreshNeuronFromAccount`](../interfaces/ClaimOrRefreshNeuronFromAccount.md); \} \| \{ `Memo`: `bigint`; \}

Defined in: [packages/nns/src/types/governance\_converters.ts:84](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L84)
