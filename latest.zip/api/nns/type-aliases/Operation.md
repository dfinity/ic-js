---
title: Operation
editUrl: false
next: true
prev: true
---

> **Operation** = \{ `RemoveHotKey`: [`RemoveHotKey`](../interfaces/RemoveHotKey.md); \} \| \{ `AddHotKey`: [`AddHotKey`](../interfaces/AddHotKey.md); \} \| \{ `StopDissolving`: `Record`\<`string`, `never`\>; \} \| \{ `StartDissolving`: `Record`\<`string`, `never`\>; \} \| \{ `IncreaseDissolveDelay`: [`IncreaseDissolveDelay`](../interfaces/IncreaseDissolveDelay.md); \} \| \{ `JoinCommunityFund`: `Record`\<`string`, `never`\>; \} \| \{ `LeaveCommunityFund`: `Record`\<`string`, `never`\>; \} \| \{ `SetDissolveTimestamp`: [`SetDissolveTimestamp`](../interfaces/SetDissolveTimestamp.md); \} \| \{ `ChangeAutoStakeMaturity`: [`ChangeAutoStakeMaturity`](../interfaces/ChangeAutoStakeMaturity.md); \} \| \{ `SetVisibility`: [`SetVisibility`](../interfaces/SetVisibility.md); \}

Defined in: [packages/nns/src/types/governance\_converters.ts:458](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L458)
