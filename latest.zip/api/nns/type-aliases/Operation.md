---
title: Operation
editUrl: false
next: true
prev: true
---

> **Operation** = \{ `RemoveHotKey`: [`RemoveHotKey`](../interfaces/RemoveHotKey.md); \} \| \{ `AddHotKey`: [`AddHotKey`](../interfaces/AddHotKey.md); \} \| \{ `StopDissolving`: `Record`\<`string`, `never`\>; \} \| \{ `StartDissolving`: `Record`\<`string`, `never`\>; \} \| \{ `IncreaseDissolveDelay`: [`IncreaseDissolveDelay`](../interfaces/IncreaseDissolveDelay.md); \} \| \{ `JoinCommunityFund`: `Record`\<`string`, `never`\>; \} \| \{ `LeaveCommunityFund`: `Record`\<`string`, `never`\>; \} \| \{ `SetDissolveTimestamp`: [`SetDissolveTimestamp`](../interfaces/SetDissolveTimestamp.md); \} \| \{ `ChangeAutoStakeMaturity`: [`ChangeAutoStakeMaturity`](../interfaces/ChangeAutoStakeMaturity.md); \} \| \{ `SetVisibility`: [`SetVisibility`](../interfaces/SetVisibility.md); \}

Defined in: [packages/nns/src/types/governance\_converters.ts:458](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L458)
