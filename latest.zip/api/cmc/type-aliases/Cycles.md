---
title: Cycles
editUrl: false
next: true
prev: true
---

> **Cycles** = `bigint`

Defined in: [packages/cmc/src/candid/cmc.d.ts:74](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cmc/src/candid/cmc.d.ts#L74)
