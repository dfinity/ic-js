---
title: CMCCanister
editUrl: false
next: true
prev: true
---

Defined in: [packages/cmc/src/cmc.canister.ts:15](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cmc/src/cmc.canister.ts#L15)

## Extends

- `Canister`\<`CMCCanisterService`\>

## Constructors

### Constructor

> `protected` **new CMCCanister**(`id`, `service`, `certifiedService`): `CMCCanister`

Defined in: packages/utils/dist/services/canister.d.ts:7

#### Parameters

##### id

`Principal`

##### service

`_SERVICE`

##### certifiedService

`_SERVICE`

#### Returns

`CMCCanister`

#### Inherited from

`Canister<CMCCanisterService>.constructor`

## Properties

### caller()

> `protected` **caller**: (`__namedParameters`) => `_SERVICE`

Defined in: packages/utils/dist/services/canister.d.ts:9

#### Parameters

##### \_\_namedParameters

`QueryParams`

#### Returns

`_SERVICE`

#### Inherited from

`Canister.caller`

***

### certifiedService

> `protected` `readonly` **certifiedService**: `_SERVICE`

Defined in: packages/utils/dist/services/canister.d.ts:6

#### Inherited from

`Canister.certifiedService`

***

### service

> `protected` `readonly` **service**: `_SERVICE`

Defined in: packages/utils/dist/services/canister.d.ts:5

#### Inherited from

`Canister.service`

## Accessors

### canisterId

#### Get Signature

> **get** **canisterId**(): `Principal`

Defined in: packages/utils/dist/services/canister.d.ts:8

##### Returns

`Principal`

#### Inherited from

`Canister.canisterId`

## Methods

### getDefaultSubnets()

> **getDefaultSubnets**(`params?`): `Promise`\<`Principal`[]\>

Defined in: [packages/cmc/src/cmc.canister.ts:110](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cmc/src/cmc.canister.ts#L110)

This function calls the `get_default_subnets` method of the CMC canister, which returns a list of
default subnets as `Principal` objects. It can be called as query or update.

#### Parameters

##### params?

`QueryParams` = `{}`

The query parameters for the call.

#### Returns

`Promise`\<`Principal`[]\>

- A promise that resolves to an array of `Principal` objects
representing the default subnets.

***

### getIcpToCyclesConversionRate()

> **getIcpToCyclesConversionRate**(`params?`): `Promise`\<`bigint`\>

Defined in: [packages/cmc/src/cmc.canister.ts:35](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cmc/src/cmc.canister.ts#L35)

Returns conversion rate of ICP to Cycles. It can be called as query or update.

#### Parameters

##### params?

`QueryParams` = `{}`

The parameters for the call.

#### Returns

`Promise`\<`bigint`\>

Promise<BigInt>

***

### getSubnetTypesToSubnets()

> **getSubnetTypesToSubnets**(`params?`): `Promise`\<[`SubnetTypesToSubnetsResponse`](../interfaces/SubnetTypesToSubnetsResponse.md)\>

Defined in: [packages/cmc/src/cmc.canister.ts:129](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cmc/src/cmc.canister.ts#L129)

This function calls the `get_subnet_types_to_subnets` method of the CMC canister, which returns a list of subnets where canisters can be created.
These subnets are excluded from the random subnet selection process used by the CMC when no explicit subnet ID is provided
during canister creation and therefore, not provided in the results of the similar function `get_default_subnets`.

#### Parameters

##### params?

`QueryParams` = `{}`

The optional query parameters for the call.

#### Returns

`Promise`\<[`SubnetTypesToSubnetsResponse`](../interfaces/SubnetTypesToSubnetsResponse.md)\>

- A promise that resolves to an object representing
the mapping of subnet types to subnets.

***

### notifyCreateCanister()

> **notifyCreateCanister**(`request`): `Promise`\<`Principal`\>

Defined in: [packages/cmc/src/cmc.canister.ts:57](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cmc/src/cmc.canister.ts#L57)

Notifies Cycles Minting Canister of the creation of a new canister.
It returns the new canister principal.

#### Parameters

##### request

[`NotifyCreateCanisterArg`](../interfaces/NotifyCreateCanisterArg.md)

#### Returns

`Promise`\<`Principal`\>

Promise<Principal>

#### Throws

RefundedError, InvalidaTransactionError, ProcessingError, TransactionTooOldError, CMCError

***

### notifyTopUp()

> **notifyTopUp**(`request`): `Promise`\<`bigint`\>

Defined in: [packages/cmc/src/cmc.canister.ts:85](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cmc/src/cmc.canister.ts#L85)

Notifies Cycles Minting Canister of new cycles being added to canister.
It returns the new Cycles of the canister.

#### Parameters

##### request

[`NotifyTopUpArg`](../interfaces/NotifyTopUpArg.md)

#### Returns

`Promise`\<`bigint`\>

Promise<Cycles>

#### Throws

RefundedError, InvalidaTransactionError, ProcessingError, TransactionTooOldError, CMCError

***

### create()

> `static` **create**(`options`): `CMCCanister`

Defined in: [packages/cmc/src/cmc.canister.ts:16](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cmc/src/cmc.canister.ts#L16)

#### Parameters

##### options

`CMCCanisterOptions`

#### Returns

`CMCCanister`
