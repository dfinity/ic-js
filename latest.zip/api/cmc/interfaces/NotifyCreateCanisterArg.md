---
title: NotifyCreateCanisterArg
editUrl: false
next: true
prev: true
---

Defined in: [packages/cmc/src/candid/cmc.d.ts:136](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cmc/src/candid/cmc.d.ts#L136)

The argument of the [notify_create_canister] method.

## Properties

### block\_index

> **block\_index**: `bigint`

Defined in: [packages/cmc/src/candid/cmc.d.ts:144](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cmc/src/candid/cmc.d.ts#L144)

Index of the block on the ICP ledger that contains the payment.

***

### controller

> **controller**: `Principal`

Defined in: [packages/cmc/src/candid/cmc.d.ts:140](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cmc/src/candid/cmc.d.ts#L140)

The controller of canister to create.

***

### settings

> **settings**: \[\] \| \[`CanisterSettings`\]

Defined in: [packages/cmc/src/candid/cmc.d.ts:154](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cmc/src/candid/cmc.d.ts#L154)

Optional canister settings that, if set, are applied to the newly created canister.
If not specified, the caller is the controller of the canister and the other settings are set to default values.

***

### subnet\_selection

> **subnet\_selection**: \[\] \| \[`SubnetSelection`\]

Defined in: [packages/cmc/src/candid/cmc.d.ts:149](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cmc/src/candid/cmc.d.ts#L149)

Optional instructions to select on which subnet the new canister will be created on.
vec may contain no more than one element.

***

### subnet\_type

> **subnet\_type**: \[\] \| \[`string`\]

Defined in: [packages/cmc/src/candid/cmc.d.ts:160](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cmc/src/candid/cmc.d.ts#L160)

An optional subnet type that, if set, determines what type of subnet
the new canister will be created on.
Deprecated. Use subnet_selection instead.
