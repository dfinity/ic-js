---
title: NotifyTopUpArg
editUrl: false
next: true
prev: true
---

Defined in: [packages/cmc/src/candid/cmc.d.ts:241](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/cmc/src/candid/cmc.d.ts#L241)

The argument of the [notify_top_up] method.

## Properties

### block\_index

> **block\_index**: `bigint`

Defined in: [packages/cmc/src/candid/cmc.d.ts:245](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/cmc/src/candid/cmc.d.ts#L245)

Index of the block on the ICP ledger that contains the payment.

***

### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/cmc/src/candid/cmc.d.ts:249](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/cmc/src/candid/cmc.d.ts#L249)

The canister to top up.
