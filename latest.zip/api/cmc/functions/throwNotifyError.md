---
title: throwNotifyError
editUrl: false
next: true
prev: true
---

> **throwNotifyError**(`__namedParameters`): `void`

Defined in: [packages/cmc/src/cmc.errors.ts:11](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/cmc/src/cmc.errors.ts#L11)

## Parameters

### \_\_namedParameters

#### Err

`NotifyError`

## Returns

`void`
