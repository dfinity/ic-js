---
title: Subaccount
editUrl: false
next: true
prev: true
---

> **Subaccount** = `Uint8Array`

Defined in: [packages/cketh/src/candid/minter.d.ts:534](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/cketh/src/candid/minter.d.ts#L534)
