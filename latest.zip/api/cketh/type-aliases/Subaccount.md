---
title: Subaccount
editUrl: false
next: true
prev: true
---

> **Subaccount** = `Uint8Array`

Defined in: [packages/cketh/src/candid/minter.d.ts:534](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/cketh/src/candid/minter.d.ts#L534)
