---
title: Eip1559TransactionPriceParams
editUrl: false
next: true
prev: true
---

> **Eip1559TransactionPriceParams** = `object` & `QueryParams`

Defined in: [packages/cketh/src/types/minter.params.ts:5](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/cketh/src/types/minter.params.ts#L5)

## Type Declaration

### ckErc20LedgerId?

> `optional` **ckErc20LedgerId**: `Principal`
