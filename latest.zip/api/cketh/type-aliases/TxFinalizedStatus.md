---
title: TxFinalizedStatus
editUrl: false
next: true
prev: true
---

> **TxFinalizedStatus** = \{ `Success`: \{ `effective_transaction_fee`: \[\] \| \[`bigint`\]; `transaction_hash`: `string`; \}; \} \| \{ `Reimbursed`: \{ `reimbursed_amount`: `bigint`; `reimbursed_in_block`: `bigint`; `transaction_hash`: `string`; \}; \} \| \{ `PendingReimbursement`: [`EthTransaction`](../interfaces/EthTransaction.md); \}

Defined in: [packages/cketh/src/candid/minter.d.ts:546](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/cketh/src/candid/minter.d.ts#L546)

Status of a finalized transaction.

## Type Declaration

\{ `Success`: \{ `effective_transaction_fee`: \[\] \| \[`bigint`\]; `transaction_hash`: `string`; \}; \}

### Success

> **Success**: `object`

Transaction was successful.

#### Success.effective\_transaction\_fee

> **effective\_transaction\_fee**: \[\] \| \[`bigint`\]

#### Success.transaction\_hash

> **transaction\_hash**: `string`

\{ `Reimbursed`: \{ `reimbursed_amount`: `bigint`; `reimbursed_in_block`: `bigint`; `transaction_hash`: `string`; \}; \}

### Reimbursed

> **Reimbursed**: `object`

Transaction failed, user got reimbursed.

#### Reimbursed.reimbursed\_amount

> **reimbursed\_amount**: `bigint`

#### Reimbursed.reimbursed\_in\_block

> **reimbursed\_in\_block**: `bigint`

#### Reimbursed.transaction\_hash

> **transaction\_hash**: `string`

\{ `PendingReimbursement`: [`EthTransaction`](../interfaces/EthTransaction.md); \}

### PendingReimbursement

> **PendingReimbursement**: [`EthTransaction`](../interfaces/EthTransaction.md)

Transaction failed and will be reimbursed,
