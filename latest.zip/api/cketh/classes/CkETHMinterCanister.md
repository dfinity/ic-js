---
title: CkETHMinterCanister
editUrl: false
next: true
prev: true
---

Defined in: [packages/cketh/src/minter.canister.ts:29](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/minter.canister.ts#L29)

## Extends

- `Canister`\<`CkETHMinterService`\>

## Constructors

### Constructor

> `protected` **new CkETHMinterCanister**(`id`, `service`, `certifiedService`): `CkETHMinterCanister`

Defined in: packages/utils/dist/services/canister.d.ts:7

#### Parameters

##### id

`Principal`

##### service

`_SERVICE`

##### certifiedService

`_SERVICE`

#### Returns

`CkETHMinterCanister`

#### Inherited from

`Canister<CkETHMinterService>.constructor`

## Properties

### caller()

> `protected` **caller**: (`__namedParameters`) => `_SERVICE`

Defined in: packages/utils/dist/services/canister.d.ts:9

#### Parameters

##### \_\_namedParameters

`QueryParams`

#### Returns

`_SERVICE`

#### Inherited from

`Canister.caller`

***

### certifiedService

> `protected` `readonly` **certifiedService**: `_SERVICE`

Defined in: packages/utils/dist/services/canister.d.ts:6

#### Inherited from

`Canister.certifiedService`

***

### service

> `protected` `readonly` **service**: `_SERVICE`

Defined in: packages/utils/dist/services/canister.d.ts:5

#### Inherited from

`Canister.service`

## Accessors

### canisterId

#### Get Signature

> **get** **canisterId**(): `Principal`

Defined in: packages/utils/dist/services/canister.d.ts:8

##### Returns

`Principal`

#### Inherited from

`Canister.canisterId`

## Methods

### eip1559TransactionPrice()

> **eip1559TransactionPrice**(`params`): `Promise`\<[`Eip1559TransactionPrice`](../interfaces/Eip1559TransactionPrice.md)\>

Defined in: [packages/cketh/src/minter.canister.ts:151](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/minter.canister.ts#L151)

Estimate the price of a transaction issued by the minter when converting ckETH to ETH and ckER20 to ERC20.

#### Parameters

##### params

[`Eip1559TransactionPriceParams`](../type-aliases/Eip1559TransactionPriceParams.md)

The parameters to get the minter info.

#### Returns

`Promise`\<[`Eip1559TransactionPrice`](../interfaces/Eip1559TransactionPrice.md)\>

- The estimated gas fee and limit.

***

### getMinterInfo()

> **getMinterInfo**(`params`): `Promise`\<[`MinterInfo`](../interfaces/MinterInfo.md)\>

Defined in: [packages/cketh/src/minter.canister.ts:179](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/minter.canister.ts#L179)

Returns internal minter parameters such as the minimal withdrawal amount, the last observed block number, etc.

#### Parameters

##### params

`QueryParams`

The parameters to get the minter info.

#### Returns

`Promise`\<[`MinterInfo`](../interfaces/MinterInfo.md)\>

***

### getSmartContractAddress()

> **getSmartContractAddress**(`params`): `Promise`\<`string`\>

Defined in: [packages/cketh/src/minter.canister.ts:48](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/minter.canister.ts#L48)

The address of the helper smart contract may change in the future when the minter is upgraded. Please verify the address of the helper contract before any important transfer by querying the minter as follows.

#### Parameters

##### params

`QueryParams` = `{}`

The parameters to resolve the ckETH smart contract address.

#### Returns

`Promise`\<`string`\>

Address of the helper smart contract.

***

### retrieveEthStatus()

> **retrieveEthStatus**(`blockIndex`): `Promise`\<[`RetrieveEthStatus`](../type-aliases/RetrieveEthStatus.md)\>

Defined in: [packages/cketh/src/minter.canister.ts:166](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/minter.canister.ts#L166)

Retrieve the status of a withdrawal request.

#### Parameters

##### blockIndex

`bigint`

#### Returns

`Promise`\<[`RetrieveEthStatus`](../type-aliases/RetrieveEthStatus.md)\>

The current status of an Ethereum transaction for a block index resulting from a withdrawal.

***

### withdrawErc20()

> **withdrawErc20**(`params`): `Promise`\<[`RetrieveErc20Request`](../interfaces/RetrieveErc20Request.md)\>

Defined in: [packages/cketh/src/minter.canister.ts:110](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/minter.canister.ts#L110)

Submits a request to convert ckErc20 to Erc20 - e.g. ckUSDC to USDC - after making ICRC-2 approvals for the ckETH and related ckErc20 ledgers.

Preconditions:

The caller allowed the minter's principal to spend its funds using
[icrc2_approve] on the ckErc20 ledger and to burn some of the user’s ckETH tokens to pay for the transaction fees on the CkETH ledger.

#### Parameters

##### params

The parameters to withdrawal ckErc20 to Erc20.

###### address

`string`

The destination ETH address.

###### amount

`bigint`

The ETH amount in wei.

###### fromCkErc20Subaccount?

[`Subaccount`](../type-aliases/Subaccount.md)

###### fromCkEthSubaccount?

[`Subaccount`](../type-aliases/Subaccount.md)

The optional subaccount to burn ckETH from to pay for the transaction fee.

###### ledgerCanisterId

`Principal`

#### Returns

`Promise`\<[`RetrieveErc20Request`](../interfaces/RetrieveErc20Request.md)\>

The successful result or the operation.

***

### withdrawEth()

> **withdrawEth**(`params`): `Promise`\<[`RetrieveEthRequest`](../interfaces/RetrieveEthRequest.md)\>

Defined in: [packages/cketh/src/minter.canister.ts:69](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/minter.canister.ts#L69)

Submits a request to convert ckETH to ETH after making an ICRC-2 approval.

Preconditions:

The caller allowed the minter's principal to spend its funds using
[icrc2_approve] on the ckETH ledger.

#### Parameters

##### params

The parameters to withdrawal ckETH to ETH.

###### address

`string`

The destination ETH address.

###### amount

`bigint`

The ETH amount in wei.

###### fromSubaccount?

[`Subaccount`](../type-aliases/Subaccount.md)

The optional subaccount to burn ckETH from.

#### Returns

`Promise`\<[`RetrieveEthRequest`](../interfaces/RetrieveEthRequest.md)\>

The successful result or the operation.

***

### create()

> `static` **create**(`options`): `CkETHMinterCanister`

Defined in: [packages/cketh/src/minter.canister.ts:30](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/minter.canister.ts#L30)

#### Parameters

##### options

`CkETHMinterCanisterOptions`\<`_SERVICE`\>

#### Returns

`CkETHMinterCanister`
