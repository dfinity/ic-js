---
title: CkETHOrchestratorCanister
editUrl: false
next: true
prev: true
---

Defined in: [packages/cketh/src/orchestrator.canister.ts:15](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/orchestrator.canister.ts#L15)

Class representing the CkETH Orchestrator Canister, which manages the Ledger and Index canisters of ckERC20 tokens.

## See

[Code](https://github.com/dfinity/ic/tree/master/rs/ethereum/ledger-suite-orchestrator|Source)

## Extends

- `Canister`\<`CkETHOrchestratorService`\>

## Constructors

### Constructor

> `protected` **new CkETHOrchestratorCanister**(`id`, `service`, `certifiedService`): `CkETHOrchestratorCanister`

Defined in: packages/utils/dist/services/canister.d.ts:7

#### Parameters

##### id

`Principal`

##### service

`_SERVICE`

##### certifiedService

`_SERVICE`

#### Returns

`CkETHOrchestratorCanister`

#### Inherited from

`Canister<CkETHOrchestratorService>.constructor`

## Properties

### caller()

> `protected` **caller**: (`__namedParameters`) => `_SERVICE`

Defined in: packages/utils/dist/services/canister.d.ts:9

#### Parameters

##### \_\_namedParameters

`QueryParams`

#### Returns

`_SERVICE`

#### Inherited from

`Canister.caller`

***

### certifiedService

> `protected` `readonly` **certifiedService**: `_SERVICE`

Defined in: packages/utils/dist/services/canister.d.ts:6

#### Inherited from

`Canister.certifiedService`

***

### service

> `protected` `readonly` **service**: `_SERVICE`

Defined in: packages/utils/dist/services/canister.d.ts:5

#### Inherited from

`Canister.service`

## Accessors

### canisterId

#### Get Signature

> **get** **canisterId**(): `Principal`

Defined in: packages/utils/dist/services/canister.d.ts:8

##### Returns

`Principal`

#### Inherited from

`Canister.canisterId`

## Methods

### getOrchestratorInfo()

> **getOrchestratorInfo**(`params?`): `Promise`\<[`OrchestratorInfo`](../interfaces/OrchestratorInfo.md)\>

Defined in: [packages/cketh/src/orchestrator.canister.ts:40](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/orchestrator.canister.ts#L40)

Retrieves orchestrator information, which contains the list of existing ckERC20 Ledger and Index canisters.

#### Parameters

##### params?

`QueryParams` = `{}`

The query parameters.

#### Returns

`Promise`\<[`OrchestratorInfo`](../interfaces/OrchestratorInfo.md)\>

A promise that resolves to the orchestrator information.

***

### create()

> `static` **create**(`options`): `CkETHOrchestratorCanister`

Defined in: [packages/cketh/src/orchestrator.canister.ts:21](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/orchestrator.canister.ts#L21)

Creates an instance of CkETHOrchestratorCanister.

#### Parameters

##### options

`CkETHOrchestratorCanisterOptions`\<`_SERVICE`\>

Options for creating the canister.

#### Returns

`CkETHOrchestratorCanister`

A new instance of CkETHOrchestratorCanister.
