---
title: createWithdrawErc20Error
editUrl: false
next: true
prev: true
---

> **createWithdrawErc20Error**(`Err`): [`MinterGenericError`](../classes/MinterGenericError.md)

Defined in: [packages/cketh/src/errors/minter.errors.ts:75](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/cketh/src/errors/minter.errors.ts#L75)

## Parameters

### Err

`WithdrawErc20Error`

## Returns

[`MinterGenericError`](../classes/MinterGenericError.md)
