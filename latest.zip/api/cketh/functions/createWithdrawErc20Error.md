---
title: createWithdrawErc20Error
editUrl: false
next: true
prev: true
---

> **createWithdrawErc20Error**(`Err`): [`MinterGenericError`](../classes/MinterGenericError.md)

Defined in: [packages/cketh/src/errors/minter.errors.ts:75](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/cketh/src/errors/minter.errors.ts#L75)

## Parameters

### Err

`WithdrawErc20Error`

## Returns

[`MinterGenericError`](../classes/MinterGenericError.md)
