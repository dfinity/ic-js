---
title: createWithdrawEthError
editUrl: false
next: true
prev: true
---

> **createWithdrawEthError**(`Err`): [`MinterGenericError`](../classes/MinterGenericError.md)

Defined in: [packages/cketh/src/errors/minter.errors.ts:37](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/errors/minter.errors.ts#L37)

## Parameters

### Err

`WithdrawalError`

## Returns

[`MinterGenericError`](../classes/MinterGenericError.md)
