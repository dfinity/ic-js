---
title: RetrieveErc20Request
editUrl: false
next: true
prev: true
---

Defined in: [packages/cketh/src/candid/minter.d.ts:485](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/cketh/src/candid/minter.d.ts#L485)

## Properties

### ckerc20\_block\_index

> **ckerc20\_block\_index**: `bigint`

Defined in: [packages/cketh/src/candid/minter.d.ts:489](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/cketh/src/candid/minter.d.ts#L489)

Burn index on the ledger handling the withdrawn ckERC20 token.

***

### cketh\_block\_index

> **cketh\_block\_index**: `bigint`

Defined in: [packages/cketh/src/candid/minter.d.ts:494](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/cketh/src/candid/minter.d.ts#L494)

Burn index on the ckETH ledger.
ckETH is needed to pay for the transaction fees.
