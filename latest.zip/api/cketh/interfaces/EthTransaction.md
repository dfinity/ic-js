---
title: EthTransaction
editUrl: false
next: true
prev: true
---

Defined in: [packages/cketh/src/candid/minter.d.ts:127](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/cketh/src/candid/minter.d.ts#L127)

## Properties

### transaction\_hash

> **transaction\_hash**: `string`

Defined in: [packages/cketh/src/candid/minter.d.ts:128](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/cketh/src/candid/minter.d.ts#L128)
