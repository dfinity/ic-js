---
title: EthTransaction
editUrl: false
next: true
prev: true
---

Defined in: [packages/cketh/src/candid/minter.d.ts:127](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/cketh/src/candid/minter.d.ts#L127)

## Properties

### transaction\_hash

> **transaction\_hash**: `string`

Defined in: [packages/cketh/src/candid/minter.d.ts:128](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/cketh/src/candid/minter.d.ts#L128)
