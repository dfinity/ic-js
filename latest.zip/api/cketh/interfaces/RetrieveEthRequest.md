---
title: RetrieveEthRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/cketh/src/candid/minter.d.ts:496](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/candid/minter.d.ts#L496)

## Properties

### block\_index

> **block\_index**: `bigint`

Defined in: [packages/cketh/src/candid/minter.d.ts:497](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/candid/minter.d.ts#L497)
