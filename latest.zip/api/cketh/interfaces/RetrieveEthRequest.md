---
title: RetrieveEthRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/cketh/src/candid/minter.d.ts:496](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/cketh/src/candid/minter.d.ts#L496)

## Properties

### block\_index

> **block\_index**: `bigint`

Defined in: [packages/cketh/src/candid/minter.d.ts:497](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/cketh/src/candid/minter.d.ts#L497)
