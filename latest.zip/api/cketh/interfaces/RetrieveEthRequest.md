---
title: RetrieveEthRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/cketh/src/candid/minter.d.ts:496](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/cketh/src/candid/minter.d.ts#L496)

## Properties

### block\_index

> **block\_index**: `bigint`

Defined in: [packages/cketh/src/candid/minter.d.ts:497](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/cketh/src/candid/minter.d.ts#L497)
