---
title: SnsGovernanceCanister
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/governance.canister.ts:66](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/governance.canister.ts#L66)

## Extends

- `Canister`\<`SnsGovernanceService`\>

## Constructors

### Constructor

> `protected` **new SnsGovernanceCanister**(`id`, `service`, `certifiedService`): `SnsGovernanceCanister`

Defined in: packages/utils/dist/services/canister.d.ts:7

#### Parameters

##### id

`Principal`

##### service

`_SERVICE`

##### certifiedService

`_SERVICE`

#### Returns

`SnsGovernanceCanister`

#### Inherited from

`Canister<SnsGovernanceService>.constructor`

## Properties

### caller()

> `protected` **caller**: (`__namedParameters`) => `_SERVICE`

Defined in: packages/utils/dist/services/canister.d.ts:9

#### Parameters

##### \_\_namedParameters

`QueryParams`

#### Returns

`_SERVICE`

#### Inherited from

`Canister.caller`

***

### certifiedService

> `protected` `readonly` **certifiedService**: `_SERVICE`

Defined in: packages/utils/dist/services/canister.d.ts:6

#### Inherited from

`Canister.certifiedService`

***

### service

> `protected` `readonly` **service**: `_SERVICE`

Defined in: packages/utils/dist/services/canister.d.ts:5

#### Inherited from

`Canister.service`

## Accessors

### canisterId

#### Get Signature

> **get** **canisterId**(): `Principal`

Defined in: packages/utils/dist/services/canister.d.ts:8

##### Returns

`Principal`

#### Inherited from

`Canister.canisterId`

## Methods

### addNeuronPermissions()

> **addNeuronPermissions**(`params`): `Promise`\<`void`\>

Defined in: [packages/sns/src/governance.canister.ts:218](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/governance.canister.ts#L218)

Add permissions to a neuron for a specific principal

#### Parameters

##### params

[`SnsNeuronPermissionsParams`](../interfaces/SnsNeuronPermissionsParams.md)

#### Returns

`Promise`\<`void`\>

***

### autoStakeMaturity()

> **autoStakeMaturity**(`params`): `Promise`\<`void`\>

Defined in: [packages/sns/src/governance.canister.ts:334](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/governance.canister.ts#L334)

Changes auto-stake maturity for a Neuron.

#### Parameters

##### params

[`SnsNeuronAutoStakeMaturityParams`](../interfaces/SnsNeuronAutoStakeMaturityParams.md)

#### Returns

`Promise`\<`void`\>

***

### claimNeuron()

> **claimNeuron**(`__namedParameters`): `Promise`\<[`SnsNeuronId`](../interfaces/SnsNeuronId.md)\>

Defined in: [packages/sns/src/governance.canister.ts:399](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/governance.canister.ts#L399)

Claim neuron

#### Parameters

##### \_\_namedParameters

[`SnsClaimNeuronParams`](../interfaces/SnsClaimNeuronParams.md)

#### Returns

`Promise`\<[`SnsNeuronId`](../interfaces/SnsNeuronId.md)\>

***

### disburse()

> **disburse**(`params`): `Promise`\<`void`\>

Defined in: [packages/sns/src/governance.canister.ts:269](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/governance.canister.ts#L269)

Disburse neuron on Account

#### Parameters

##### params

[`SnsDisburseNeuronParams`](../interfaces/SnsDisburseNeuronParams.md)

#### Returns

`Promise`\<`void`\>

***

### disburseMaturity()

> **disburseMaturity**(`params`): `Promise`\<`void`\>

Defined in: [packages/sns/src/governance.canister.ts:318](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/governance.canister.ts#L318)

Disburse the maturity of a neuron.

#### Parameters

##### params

[`SnsNeuronDisburseMaturityParams`](../interfaces/SnsNeuronDisburseMaturityParams.md)

#### Returns

`Promise`\<`void`\>

***

### getNeuron()

> **getNeuron**(`params`): `Promise`\<[`SnsNeuron`](../interfaces/SnsNeuron.md)\>

Defined in: [packages/sns/src/governance.canister.ts:167](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/governance.canister.ts#L167)

Get the neuron of the Sns

#### Parameters

##### params

[`SnsGetNeuronParams`](../interfaces/SnsGetNeuronParams.md)

#### Returns

`Promise`\<[`SnsNeuron`](../interfaces/SnsNeuron.md)\>

***

### getProposal()

> **getProposal**(`params`): `Promise`\<[`SnsProposalData`](../interfaces/SnsProposalData.md)\>

Defined in: [packages/sns/src/governance.canister.ts:126](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/governance.canister.ts#L126)

Get the proposal of the Sns

#### Parameters

##### params

[`SnsGetProposalParams`](../interfaces/SnsGetProposalParams.md)

#### Returns

`Promise`\<[`SnsProposalData`](../interfaces/SnsProposalData.md)\>

***

### increaseDissolveDelay()

> **increaseDissolveDelay**(`params`): `Promise`\<`void`\>

Defined in: [packages/sns/src/governance.canister.ts:354](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/governance.canister.ts#L354)

Increase dissolve delay of a neuron

#### Parameters

##### params

[`SnsIncreaseDissolveDelayParams`](../interfaces/SnsIncreaseDissolveDelayParams.md)

#### Returns

`Promise`\<`void`\>

***

### listNervousSystemFunctions()

> **listNervousSystemFunctions**(`params`): `Promise`\<[`SnsListNervousSystemFunctionsResponse`](../interfaces/SnsListNervousSystemFunctionsResponse.md)\>

Defined in: [packages/sns/src/governance.canister.ts:145](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/governance.canister.ts#L145)

List Nervous System Functions
Neurons can follow other neurons in specific Nervous System Functions.

#### Parameters

##### params

`QueryParams`

#### Returns

`Promise`\<[`SnsListNervousSystemFunctionsResponse`](../interfaces/SnsListNervousSystemFunctionsResponse.md)\>

***

### listNeurons()

> **listNeurons**(`params`): `Promise`\<[`SnsNeuron`](../interfaces/SnsNeuron.md)[]\>

Defined in: [packages/sns/src/governance.canister.ts:86](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/governance.canister.ts#L86)

List the neurons of the Sns

#### Parameters

##### params

[`SnsListNeuronsParams`](../interfaces/SnsListNeuronsParams.md)

#### Returns

`Promise`\<[`SnsNeuron`](../interfaces/SnsNeuron.md)[]\>

***

### listProposals()

> **listProposals**(`params`): `Promise`\<[`SnsListProposalsResponse`](../interfaces/SnsListProposalsResponse.md)\>

Defined in: [packages/sns/src/governance.canister.ts:100](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/governance.canister.ts#L100)

List the proposals of the Sns

#### Parameters

##### params

[`SnsListProposalsParams`](../interfaces/SnsListProposalsParams.md)

#### Returns

`Promise`\<[`SnsListProposalsResponse`](../interfaces/SnsListProposalsResponse.md)\>

***

### listTopics()

> **listTopics**(`params`): `Promise`\<[`SnsListTopicsResponse`](../interfaces/SnsListTopicsResponse.md)\>

Defined in: [packages/sns/src/governance.canister.ts:115](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/governance.canister.ts#L115)

List the topics of the Sns

#### Parameters

##### params

`QueryParams`

#### Returns

`Promise`\<[`SnsListTopicsResponse`](../interfaces/SnsListTopicsResponse.md)\>

***

### manageNeuron()

> **manageNeuron**(`request`): `Promise`\<[`SnsManageNeuronResponse`](../interfaces/SnsManageNeuronResponse.md)\>

Defined in: [packages/sns/src/governance.canister.ts:205](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/governance.canister.ts#L205)

Manage neuron. For advanced users.

#### Parameters

##### request

[`SnsManageNeuron`](../interfaces/SnsManageNeuron.md)

#### Returns

`Promise`\<[`SnsManageNeuronResponse`](../interfaces/SnsManageNeuronResponse.md)\>

***

### metadata()

> **metadata**(`params`): `Promise`\<[`SnsGetMetadataResponse`](../interfaces/SnsGetMetadataResponse.md)\>

Defined in: [packages/sns/src/governance.canister.ts:153](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/governance.canister.ts#L153)

Get the Sns metadata (title, description, etc.)

#### Parameters

##### params

`QueryParams`

#### Returns

`Promise`\<[`SnsGetMetadataResponse`](../interfaces/SnsGetMetadataResponse.md)\>

***

### nervousSystemParameters()

> **nervousSystemParameters**(`params`): `Promise`\<[`SnsNervousSystemParameters`](../interfaces/SnsNervousSystemParameters.md)\>

Defined in: [packages/sns/src/governance.canister.ts:159](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/governance.canister.ts#L159)

Get the Sns nervous system parameters (default followees, max dissolve delay, max number of neurons, etc.)

#### Parameters

##### params

`QueryParams`

#### Returns

`Promise`\<[`SnsNervousSystemParameters`](../interfaces/SnsNervousSystemParameters.md)\>

***

### queryNeuron()

> **queryNeuron**(`params`): `Promise`\<[`SnsNeuron`](../interfaces/SnsNeuron.md) \| `undefined`\>

Defined in: [packages/sns/src/governance.canister.ts:185](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/governance.canister.ts#L185)

Same as `getNeuron` but returns undefined instead of raising error when not found.

#### Parameters

##### params

[`SnsGetNeuronParams`](../interfaces/SnsGetNeuronParams.md)

#### Returns

`Promise`\<[`SnsNeuron`](../interfaces/SnsNeuron.md) \| `undefined`\>

***

### refreshNeuron()

> **refreshNeuron**(`neuronId`): `Promise`\<`void`\>

Defined in: [packages/sns/src/governance.canister.ts:389](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/governance.canister.ts#L389)

Refresh neuron

#### Parameters

##### neuronId

[`SnsNeuronId`](../interfaces/SnsNeuronId.md)

#### Returns

`Promise`\<`void`\>

***

### registerVote()

> **registerVote**(`params`): `Promise`\<`void`\>

Defined in: [packages/sns/src/governance.canister.ts:381](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/governance.canister.ts#L381)

Registers vote for a proposal from the neuron passed.

#### Parameters

##### params

[`SnsRegisterVoteParams`](../interfaces/SnsRegisterVoteParams.md)

#### Returns

`Promise`\<`void`\>

***

### removeNeuronPermissions()

> **removeNeuronPermissions**(`params`): `Promise`\<`void`\>

Defined in: [packages/sns/src/governance.canister.ts:228](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/governance.canister.ts#L228)

Remove permissions to a neuron for a specific principal

#### Parameters

##### params

[`SnsNeuronPermissionsParams`](../interfaces/SnsNeuronPermissionsParams.md)

#### Returns

`Promise`\<`void`\>

***

### setDissolveTimestamp()

> **setDissolveTimestamp**(`params`): `Promise`\<`void`\>

Defined in: [packages/sns/src/governance.canister.ts:344](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/governance.canister.ts#L344)

Increase dissolve delay of a neuron

#### Parameters

##### params

[`SnsSetDissolveTimestampParams`](../interfaces/SnsSetDissolveTimestampParams.md)

#### Returns

`Promise`\<`void`\>

***

### setFollowing()

> **setFollowing**(`params`): `Promise`\<`void`\>

Defined in: [packages/sns/src/governance.canister.ts:373](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/governance.canister.ts#L373)

Sets followees of a neuron for topics

#### Parameters

##### params

[`SnsSetFollowingParams`](../interfaces/SnsSetFollowingParams.md)

#### Returns

`Promise`\<`void`\>

***

### ~~setTopicFollowees()~~

> **setTopicFollowees**(`params`): `Promise`\<`void`\>

Defined in: [packages/sns/src/governance.canister.ts:365](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/governance.canister.ts#L365)

Sets followees of a neuron for a specific Nervous System Function

#### Parameters

##### params

[`SnsSetTopicFollowees`](../interfaces/SnsSetTopicFollowees.md)

#### Returns

`Promise`\<`void`\>

#### Deprecated

will be replaced by `setFollowing` in the future.

***

### splitNeuron()

> **splitNeuron**(`params`): `Promise`\<[`SnsNeuronId`](../interfaces/SnsNeuronId.md) \| `undefined`\>

Defined in: [packages/sns/src/governance.canister.ts:238](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/governance.canister.ts#L238)

Split neuron

#### Parameters

##### params

[`SnsSplitNeuronParams`](../interfaces/SnsSplitNeuronParams.md)

#### Returns

`Promise`\<[`SnsNeuronId`](../interfaces/SnsNeuronId.md) \| `undefined`\>

***

### stakeMaturity()

> **stakeMaturity**(`params`): `Promise`\<`void`\>

Defined in: [packages/sns/src/governance.canister.ts:297](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/governance.canister.ts#L297)

Stake the maturity of a neuron.

#### Parameters

##### params

[`SnsNeuronStakeMaturityParams`](../interfaces/SnsNeuronStakeMaturityParams.md)

#### Returns

`Promise`\<`void`\>

***

### startDissolving()

> **startDissolving**(`neuronId`): `Promise`\<`void`\>

Defined in: [packages/sns/src/governance.canister.ts:277](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/governance.canister.ts#L277)

Start dissolving process of a neuron

#### Parameters

##### neuronId

[`SnsNeuronId`](../interfaces/SnsNeuronId.md)

#### Returns

`Promise`\<`void`\>

***

### stopDissolving()

> **stopDissolving**(`neuronId`): `Promise`\<`void`\>

Defined in: [packages/sns/src/governance.canister.ts:285](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/governance.canister.ts#L285)

Stop dissolving process of a neuron

#### Parameters

##### neuronId

[`SnsNeuronId`](../interfaces/SnsNeuronId.md)

#### Returns

`Promise`\<`void`\>

***

### create()

> `static` **create**(`options`): `SnsGovernanceCanister`

Defined in: [packages/sns/src/governance.canister.ts:72](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/governance.canister.ts#L72)

Instantiate a canister to interact with the governance of a Sns project.

#### Parameters

##### options

[`SnsCanisterOptions`](../interfaces/SnsCanisterOptions.md)\<`_SERVICE`\>

Miscellaneous options to initialize the canister. Its ID being the only mandatory parammeter.

#### Returns

`SnsGovernanceCanister`
