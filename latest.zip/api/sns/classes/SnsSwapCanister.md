---
title: SnsSwapCanister
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/swap.canister.ts:33](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/swap.canister.ts#L33)

## Extends

- `Canister`\<`SnsSwapService`\>

## Constructors

### Constructor

> `protected` **new SnsSwapCanister**(`id`, `service`, `certifiedService`): `SnsSwapCanister`

Defined in: packages/utils/dist/services/canister.d.ts:7

#### Parameters

##### id

`Principal`

##### service

`_SERVICE`

##### certifiedService

`_SERVICE`

#### Returns

`SnsSwapCanister`

#### Inherited from

`Canister<SnsSwapService>.constructor`

## Properties

### caller()

> `protected` **caller**: (`__namedParameters`) => `_SERVICE`

Defined in: packages/utils/dist/services/canister.d.ts:9

#### Parameters

##### \_\_namedParameters

`QueryParams`

#### Returns

`_SERVICE`

#### Inherited from

`Canister.caller`

***

### certifiedService

> `protected` `readonly` **certifiedService**: `_SERVICE`

Defined in: packages/utils/dist/services/canister.d.ts:6

#### Inherited from

`Canister.certifiedService`

***

### service

> `protected` `readonly` **service**: `_SERVICE`

Defined in: packages/utils/dist/services/canister.d.ts:5

#### Inherited from

`Canister.service`

## Accessors

### canisterId

#### Get Signature

> **get** **canisterId**(): `Principal`

Defined in: packages/utils/dist/services/canister.d.ts:8

##### Returns

`Principal`

#### Inherited from

`Canister.canisterId`

## Methods

### getDerivedState()

> **getDerivedState**(`__namedParameters`): `Promise`\<[`SnsGetDerivedStateResponse`](../interfaces/SnsGetDerivedStateResponse.md)\>

Defined in: [packages/sns/src/swap.canister.ts:84](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/swap.canister.ts#L84)

Get sale buyers state

#### Parameters

##### \_\_namedParameters

`QueryParams`

#### Returns

`Promise`\<[`SnsGetDerivedStateResponse`](../interfaces/SnsGetDerivedStateResponse.md)\>

***

### getFinalizationStatus()

> **getFinalizationStatus**(`params`): `Promise`\<[`SnsGetAutoFinalizationStatusResponse`](../interfaces/SnsGetAutoFinalizationStatusResponse.md)\>

Defined in: [packages/sns/src/swap.canister.ts:148](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/swap.canister.ts#L148)

Get sale lifecycle state

#### Parameters

##### params

`QueryParams`

#### Returns

`Promise`\<[`SnsGetAutoFinalizationStatusResponse`](../interfaces/SnsGetAutoFinalizationStatusResponse.md)\>

***

### getLifecycle()

> **getLifecycle**(`params`): `Promise`\<[`SnsGetLifecycleResponse`](../interfaces/SnsGetLifecycleResponse.md)\>

Defined in: [packages/sns/src/swap.canister.ts:142](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/swap.canister.ts#L142)

Get sale lifecycle state

#### Parameters

##### params

`QueryParams`

#### Returns

`Promise`\<[`SnsGetLifecycleResponse`](../interfaces/SnsGetLifecycleResponse.md)\>

***

### getOpenTicket()

> **getOpenTicket**(`params`): `Promise`\<[`SnsSwapTicket`](../interfaces/SnsSwapTicket.md) \| `undefined`\>

Defined in: [packages/sns/src/swap.canister.ts:100](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/swap.canister.ts#L100)

Return a sale ticket if created and not yet removed (payment flow)

#### Parameters

##### params

`QueryParams`

#### Returns

`Promise`\<[`SnsSwapTicket`](../interfaces/SnsSwapTicket.md) \| `undefined`\>

***

### getSaleParameters()

> **getSaleParameters**(`__namedParameters`): `Promise`\<[`SnsGetSaleParametersResponse`](../interfaces/SnsGetSaleParametersResponse.md)\>

Defined in: [packages/sns/src/swap.canister.ts:92](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/swap.canister.ts#L92)

Get sale parameters

#### Parameters

##### \_\_namedParameters

`QueryParams`

#### Returns

`Promise`\<[`SnsGetSaleParametersResponse`](../interfaces/SnsGetSaleParametersResponse.md)\>

***

### getUserCommitment()

> **getUserCommitment**(`params`): `Promise`\<[`SnsSwapBuyerState`](../interfaces/SnsSwapBuyerState.md) \| `undefined`\>

Defined in: [packages/sns/src/swap.canister.ts:72](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/swap.canister.ts#L72)

Get user commitment

#### Parameters

##### params

[`SnsGetBuyerStateRequest`](../interfaces/SnsGetBuyerStateRequest.md) & `QueryParams`

#### Returns

`Promise`\<[`SnsSwapBuyerState`](../interfaces/SnsSwapBuyerState.md) \| `undefined`\>

***

### newSaleTicket()

> **newSaleTicket**(`params`): `Promise`\<[`SnsSwapTicket`](../interfaces/SnsSwapTicket.md)\>

Defined in: [packages/sns/src/swap.canister.ts:117](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/swap.canister.ts#L117)

Create a sale ticket (payment flow)

#### Parameters

##### params

`NewSaleTicketParams`

#### Returns

`Promise`\<[`SnsSwapTicket`](../interfaces/SnsSwapTicket.md)\>

***

### notifyParticipation()

> **notifyParticipation**(`params`): `Promise`\<[`SnsRefreshBuyerTokensResponse`](../interfaces/SnsRefreshBuyerTokensResponse.md)\>

Defined in: [packages/sns/src/swap.canister.ts:64](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/swap.canister.ts#L64)

Notify of the user participating in the swap

#### Parameters

##### params

`RefreshBuyerTokensRequest`

#### Returns

`Promise`\<[`SnsRefreshBuyerTokensResponse`](../interfaces/SnsRefreshBuyerTokensResponse.md)\>

***

### notifyPaymentFailure()

> **notifyPaymentFailure**(): `Promise`\<[`SnsSwapTicket`](../interfaces/SnsSwapTicket.md) \| `undefined`\>

Defined in: [packages/sns/src/swap.canister.ts:54](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/swap.canister.ts#L54)

Notify of the payment failure to remove the ticket

#### Returns

`Promise`\<[`SnsSwapTicket`](../interfaces/SnsSwapTicket.md) \| `undefined`\>

***

### state()

> **state**(`params`): `Promise`\<`GetStateResponse`\>

Defined in: [packages/sns/src/swap.canister.ts:48](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/swap.canister.ts#L48)

Get the state of the swap

#### Parameters

##### params

`QueryParams`

#### Returns

`Promise`\<`GetStateResponse`\>

***

### create()

> `static` **create**(`options`): `SnsSwapCanister`

Defined in: [packages/sns/src/swap.canister.ts:34](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/swap.canister.ts#L34)

#### Parameters

##### options

[`SnsCanisterOptions`](../interfaces/SnsCanisterOptions.md)\<`_SERVICE`\>

#### Returns

`SnsSwapCanister`
