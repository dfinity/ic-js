---
title: SnsListTopicsParams
editUrl: false
next: true
prev: true
---

> **SnsListTopicsParams** = `QueryParams`

Defined in: [packages/sns/src/types/governance.params.ts:63](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/types/governance.params.ts#L63)
