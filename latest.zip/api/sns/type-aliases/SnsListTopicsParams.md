---
title: SnsListTopicsParams
editUrl: false
next: true
prev: true
---

> **SnsListTopicsParams** = `QueryParams`

Defined in: [packages/sns/src/types/governance.params.ts:63](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/types/governance.params.ts#L63)
