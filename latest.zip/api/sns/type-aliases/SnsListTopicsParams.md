---
title: SnsListTopicsParams
editUrl: false
next: true
prev: true
---

> **SnsListTopicsParams** = `QueryParams`

Defined in: [packages/sns/src/types/governance.params.ts:63](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/governance.params.ts#L63)
