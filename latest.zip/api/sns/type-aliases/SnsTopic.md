---
title: SnsTopic
editUrl: false
next: true
prev: true
---

> **SnsTopic** = \{ `DappCanisterManagement`: `null`; \} \| \{ `DaoCommunitySettings`: `null`; \} \| \{ `ApplicationBusinessLogic`: `null`; \} \| \{ `CriticalDappOperations`: `null`; \} \| \{ `TreasuryAssetManagement`: `null`; \} \| \{ `Governance`: `null`; \} \| \{ `SnsFrameworkManagement`: `null`; \}

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:739](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L739)
