---
title: NewSaleTicketResponseErrorType
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/enums/swap.enums.ts:19](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/swap.enums.ts#L19)

## Enumeration Members

### TYPE\_INVALID\_PRINCIPAL

> **TYPE\_INVALID\_PRINCIPAL**: `6`

Defined in: [packages/sns/src/enums/swap.enums.ts:36](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/swap.enums.ts#L36)

***

### TYPE\_INVALID\_SUBACCOUNT

> **TYPE\_INVALID\_SUBACCOUNT**: `5`

Defined in: [packages/sns/src/enums/swap.enums.ts:34](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/swap.enums.ts#L34)

***

### TYPE\_INVALID\_USER\_AMOUNT

> **TYPE\_INVALID\_USER\_AMOUNT**: `4`

Defined in: [packages/sns/src/enums/swap.enums.ts:32](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/swap.enums.ts#L32)

***

### TYPE\_SALE\_CLOSED

> **TYPE\_SALE\_CLOSED**: `2`

Defined in: [packages/sns/src/enums/swap.enums.ts:22](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/swap.enums.ts#L22)

***

### TYPE\_SALE\_NOT\_OPEN

> **TYPE\_SALE\_NOT\_OPEN**: `1`

Defined in: [packages/sns/src/enums/swap.enums.ts:21](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/swap.enums.ts#L21)

***

### TYPE\_TICKET\_EXISTS

> **TYPE\_TICKET\_EXISTS**: `3`

Defined in: [packages/sns/src/enums/swap.enums.ts:27](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/swap.enums.ts#L27)

***

### TYPE\_UNSPECIFIED

> **TYPE\_UNSPECIFIED**: `0`

Defined in: [packages/sns/src/enums/swap.enums.ts:20](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/swap.enums.ts#L20)
