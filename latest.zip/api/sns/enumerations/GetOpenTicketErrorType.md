---
title: GetOpenTicketErrorType
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/enums/swap.enums.ts:12](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/enums/swap.enums.ts#L12)

## Enumeration Members

### TYPE\_SALE\_CLOSED

> **TYPE\_SALE\_CLOSED**: `2`

Defined in: [packages/sns/src/enums/swap.enums.ts:15](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/enums/swap.enums.ts#L15)

***

### TYPE\_SALE\_NOT\_OPEN

> **TYPE\_SALE\_NOT\_OPEN**: `1`

Defined in: [packages/sns/src/enums/swap.enums.ts:14](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/enums/swap.enums.ts#L14)

***

### TYPE\_UNSPECIFIED

> **TYPE\_UNSPECIFIED**: `0`

Defined in: [packages/sns/src/enums/swap.enums.ts:13](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/enums/swap.enums.ts#L13)
