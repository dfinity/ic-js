---
title: SnsSwapLifecycle
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/enums/swap.enums.ts:2](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/swap.enums.ts#L2)

## Enumeration Members

### Aborted

> **Aborted**: `4`

Defined in: [packages/sns/src/enums/swap.enums.ts:7](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/swap.enums.ts#L7)

***

### Adopted

> **Adopted**: `5`

Defined in: [packages/sns/src/enums/swap.enums.ts:8](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/swap.enums.ts#L8)

***

### Committed

> **Committed**: `3`

Defined in: [packages/sns/src/enums/swap.enums.ts:6](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/swap.enums.ts#L6)

***

### Open

> **Open**: `2`

Defined in: [packages/sns/src/enums/swap.enums.ts:5](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/swap.enums.ts#L5)

***

### Pending

> **Pending**: `1`

Defined in: [packages/sns/src/enums/swap.enums.ts:4](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/swap.enums.ts#L4)

***

### Unspecified

> **Unspecified**: `0`

Defined in: [packages/sns/src/enums/swap.enums.ts:3](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/swap.enums.ts#L3)
