---
title: SnsProposalRewardStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/enums/governance.enums.ts:48](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/enums/governance.enums.ts#L48)

## Enumeration Members

### PROPOSAL\_REWARD\_STATUS\_ACCEPT\_VOTES

> **PROPOSAL\_REWARD\_STATUS\_ACCEPT\_VOTES**: `1`

Defined in: [packages/sns/src/enums/governance.enums.ts:56](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/enums/governance.enums.ts#L56)

***

### PROPOSAL\_REWARD\_STATUS\_READY\_TO\_SETTLE

> **PROPOSAL\_REWARD\_STATUS\_READY\_TO\_SETTLE**: `2`

Defined in: [packages/sns/src/enums/governance.enums.ts:60](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/enums/governance.enums.ts#L60)

***

### PROPOSAL\_REWARD\_STATUS\_SETTLED

> **PROPOSAL\_REWARD\_STATUS\_SETTLED**: `3`

Defined in: [packages/sns/src/enums/governance.enums.ts:64](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/enums/governance.enums.ts#L64)

***

### PROPOSAL\_REWARD\_STATUS\_UNSPECIFIED

> **PROPOSAL\_REWARD\_STATUS\_UNSPECIFIED**: `0`

Defined in: [packages/sns/src/enums/governance.enums.ts:49](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/enums/governance.enums.ts#L49)
