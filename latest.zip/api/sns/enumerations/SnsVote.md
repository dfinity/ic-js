---
title: SnsVote
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/enums/governance.enums.ts:87](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/enums/governance.enums.ts#L87)

## Enumeration Members

### No

> **No**: `2`

Defined in: [packages/sns/src/enums/governance.enums.ts:90](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/enums/governance.enums.ts#L90)

***

### Unspecified

> **Unspecified**: `0`

Defined in: [packages/sns/src/enums/governance.enums.ts:88](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/enums/governance.enums.ts#L88)

***

### Yes

> **Yes**: `1`

Defined in: [packages/sns/src/enums/governance.enums.ts:89](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/enums/governance.enums.ts#L89)
