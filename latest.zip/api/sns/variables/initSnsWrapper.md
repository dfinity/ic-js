---
title: initSnsWrapper
editUrl: false
next: true
prev: true
---

> `const` **initSnsWrapper**: [`InitSnsWrapper`](../interfaces/InitSnsWrapper.md)

Defined in: [packages/sns/src/sns.ts:36](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/sns.ts#L36)

Lookup for the canister ids of a Sns and initialize the wrapper to access its features.
