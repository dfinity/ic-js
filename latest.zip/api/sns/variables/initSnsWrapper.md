---
title: initSnsWrapper
editUrl: false
next: true
prev: true
---

> `const` **initSnsWrapper**: [`InitSnsWrapper`](../interfaces/InitSnsWrapper.md)

Defined in: [packages/sns/src/sns.ts:36](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/sns.ts#L36)

Lookup for the canister ids of a Sns and initialize the wrapper to access its features.
