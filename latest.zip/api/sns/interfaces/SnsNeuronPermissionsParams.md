---
title: SnsNeuronPermissionsParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/types/governance.params.ts:112](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/governance.params.ts#L112)

The parameters to add permissions to a neuron

## Extends

- `SnsNeuronManagementParams`

## Properties

### neuronId

> **neuronId**: [`SnsNeuronId`](SnsNeuronId.md)

Defined in: [packages/sns/src/types/governance.params.ts:106](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/governance.params.ts#L106)

#### Inherited from

`SnsNeuronManagementParams.neuronId`

***

### permissions

> **permissions**: [`SnsNeuronPermissionType`](../enumerations/SnsNeuronPermissionType.md)[]

Defined in: [packages/sns/src/types/governance.params.ts:114](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/governance.params.ts#L114)

***

### principal

> **principal**: `Principal`

Defined in: [packages/sns/src/types/governance.params.ts:113](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/governance.params.ts#L113)
