---
title: SnsNeuronAutoStakeMaturityParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/types/governance.params.ts:207](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/types/governance.params.ts#L207)

The parameters to toggle auto stake maturity of a neuron

## Extends

- `SnsNeuronManagementParams`

## Properties

### autoStake

> **autoStake**: `boolean`

Defined in: [packages/sns/src/types/governance.params.ts:209](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/types/governance.params.ts#L209)

***

### neuronId

> **neuronId**: [`SnsNeuronId`](SnsNeuronId.md)

Defined in: [packages/sns/src/types/governance.params.ts:106](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/types/governance.params.ts#L106)

#### Inherited from

`SnsNeuronManagementParams.neuronId`
