---
title: SnsParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:283](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_swap.d.ts#L283)

## Properties

### max\_direct\_participation\_icp\_e8s

> **max\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:296](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_swap.d.ts#L296)

***

### max\_icp\_e8s

> **max\_icp\_e8s**: `bigint`

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:288](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_swap.d.ts#L288)

***

### max\_participant\_icp\_e8s

> **max\_participant\_icp\_e8s**: `bigint`

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:293](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_swap.d.ts#L293)

***

### min\_direct\_participation\_icp\_e8s

> **min\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:294](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_swap.d.ts#L294)

***

### min\_icp\_e8s

> **min\_icp\_e8s**: `bigint`

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:295](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_swap.d.ts#L295)

***

### min\_participant\_icp\_e8s

> **min\_participant\_icp\_e8s**: `bigint`

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:284](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_swap.d.ts#L284)

***

### min\_participants

> **min\_participants**: `number`

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:290](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_swap.d.ts#L290)

***

### neuron\_basket\_construction\_parameters

> **neuron\_basket\_construction\_parameters**: \[\] \| \[`NeuronBasketConstructionParameters`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:285](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_swap.d.ts#L285)

***

### sale\_delay\_seconds

> **sale\_delay\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:292](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_swap.d.ts#L292)

***

### sns\_token\_e8s

> **sns\_token\_e8s**: `bigint`

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:291](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_swap.d.ts#L291)

***

### swap\_due\_timestamp\_seconds

> **swap\_due\_timestamp\_seconds**: `bigint`

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:289](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_swap.d.ts#L289)
