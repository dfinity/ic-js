---
title: InitSnsCanistersOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/sns.ts:22](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/sns.ts#L22)

Options to discover and initialize all canisters of a Sns.

## Extends

- `QueryParams`

## Properties

### agent?

> `optional` **agent**: `Agent`

Defined in: [packages/sns/src/sns.ts:24](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/sns.ts#L24)

An agent that can be used to override the default agent. Useful to target another environment that mainnet.

***

### certified?

> `optional` **certified**: `boolean`

Defined in: packages/utils/dist/types/query.params.d.ts:6

Perform update calls (certified) or query calls (not certified).

#### Inherited from

`QueryParams.certified`

***

### rootOptions

> **rootOptions**: `Omit`\<[`SnsCanisterOptions`](SnsCanisterOptions.md)\<`SnsRootService`\>, `"agent"`\>

Defined in: [packages/sns/src/sns.ts:26](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/sns.ts#L26)

The options that will be used to instantiate the actors of the root canister of the particular Sns.
