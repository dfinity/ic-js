---
title: SnsListTopicsResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:396](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L396)

## Properties

### topics

> **topics**: \[\] \| \[[`SnsTopicInfo`](SnsTopicInfo.md)[]\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:398](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L398)

***

### uncategorized\_functions

> **uncategorized\_functions**: \[\] \| \[[`SnsNervousSystemFunction`](SnsNervousSystemFunction.md)[]\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:397](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L397)
