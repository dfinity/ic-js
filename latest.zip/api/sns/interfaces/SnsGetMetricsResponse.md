---
title: SnsGetMetricsResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:270](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L270)

## Properties

### get\_metrics\_result

> **get\_metrics\_result**: \[\] \| \[`GetMetricsResult`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:271](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L271)
