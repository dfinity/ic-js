---
title: SnsDisburseNeuronParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/types/governance.params.ts:128](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/governance.params.ts#L128)

The parameters to disburse a neuron

## Extends

- `SnsNeuronManagementParams`

## Properties

### amount?

> `optional` **amount**: `bigint`

Defined in: [packages/sns/src/types/governance.params.ts:129](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/governance.params.ts#L129)

***

### neuronId

> **neuronId**: [`SnsNeuronId`](SnsNeuronId.md)

Defined in: [packages/sns/src/types/governance.params.ts:106](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/governance.params.ts#L106)

#### Inherited from

`SnsNeuronManagementParams.neuronId`

***

### toAccount?

> `optional` **toAccount**: `IcrcAccount`

Defined in: [packages/sns/src/types/governance.params.ts:130](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/governance.params.ts#L130)
