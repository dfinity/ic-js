---
title: SnsListProposalsResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:390](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L390)

## Properties

### include\_ballots\_by\_caller

> **include\_ballots\_by\_caller**: \[\] \| \[`boolean`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:391](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L391)

***

### include\_topic\_filtering

> **include\_topic\_filtering**: \[\] \| \[`boolean`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:393](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L393)

***

### proposals

> **proposals**: [`SnsProposalData`](SnsProposalData.md)[]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:392](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L392)
