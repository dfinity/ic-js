---
title: SnsRefreshBuyerTokensResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:321](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L321)

## Properties

### icp\_accepted\_participation\_e8s

> **icp\_accepted\_participation\_e8s**: `bigint`

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:322](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L322)

***

### icp\_ledger\_account\_balance\_e8s

> **icp\_ledger\_account\_balance\_e8s**: `bigint`

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:323](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L323)
