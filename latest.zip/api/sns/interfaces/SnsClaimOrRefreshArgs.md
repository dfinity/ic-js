---
title: SnsClaimOrRefreshArgs
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/types/governance.params.ts:96](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/governance.params.ts#L96)

## Extends

- `Omit`\<`QueryParams`, `"certified"`\>

## Properties

### controller?

> `optional` **controller**: `Principal`

Defined in: [packages/sns/src/types/governance.params.ts:99](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/governance.params.ts#L99)

***

### memo?

> `optional` **memo**: `bigint`

Defined in: [packages/sns/src/types/governance.params.ts:98](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/governance.params.ts#L98)

***

### subaccount

> **subaccount**: `Uint8Array`

Defined in: [packages/sns/src/types/governance.params.ts:97](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/governance.params.ts#L97)
