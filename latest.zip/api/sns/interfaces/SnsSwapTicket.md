---
title: SnsSwapTicket
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:379](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L379)

## Properties

### account

> **account**: \[\] \| \[`Icrc1Account`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:382](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L382)

***

### amount\_icp\_e8s

> **amount\_icp\_e8s**: `bigint`

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:383](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L383)

***

### creation\_time

> **creation\_time**: `bigint`

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:380](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L380)

***

### ticket\_id

> **ticket\_id**: `bigint`

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:381](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L381)
