---
title: SnsNervousSystemParameters
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:483](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L483)

## Properties

### automatically\_advance\_target\_version

> **automatically\_advance\_target\_version**: \[\] \| \[`boolean`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:488](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L488)

***

### default\_followees

> **default\_followees**: \[\] \| \[[`SnsDefaultFollowees`](SnsDefaultFollowees.md)\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:484](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L484)

***

### initial\_voting\_period\_seconds

> **initial\_voting\_period\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:492](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L492)

***

### maturity\_modulation\_disabled

> **maturity\_modulation\_disabled**: \[\] \| \[`boolean`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:503](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L503)

***

### max\_age\_bonus\_percentage

> **max\_age\_bonus\_percentage**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:500](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L500)

***

### max\_dissolve\_delay\_bonus\_percentage

> **max\_dissolve\_delay\_bonus\_percentage**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:486](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L486)

***

### max\_dissolve\_delay\_seconds

> **max\_dissolve\_delay\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:485](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L485)

***

### max\_followees\_per\_function

> **max\_followees\_per\_function**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:487](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L487)

***

### max\_neuron\_age\_for\_age\_bonus

> **max\_neuron\_age\_for\_age\_bonus**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:491](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L491)

***

### max\_number\_of\_neurons

> **max\_number\_of\_neurons**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:497](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L497)

***

### max\_number\_of\_principals\_per\_neuron

> **max\_number\_of\_principals\_per\_neuron**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:504](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L504)

***

### max\_number\_of\_proposals\_with\_ballots

> **max\_number\_of\_proposals\_with\_ballots**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:499](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L499)

***

### max\_proposals\_to\_keep\_per\_action

> **max\_proposals\_to\_keep\_per\_action**: \[\] \| \[`number`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:495](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L495)

***

### neuron\_claimer\_permissions

> **neuron\_claimer\_permissions**: \[\] \| \[[`SnsNeuronPermissionList`](SnsNeuronPermissionList.md)\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:489](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L489)

***

### neuron\_grantable\_permissions

> **neuron\_grantable\_permissions**: \[\] \| \[[`SnsNeuronPermissionList`](SnsNeuronPermissionList.md)\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:501](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L501)

***

### neuron\_minimum\_dissolve\_delay\_to\_vote\_seconds

> **neuron\_minimum\_dissolve\_delay\_to\_vote\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:493](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L493)

***

### neuron\_minimum\_stake\_e8s

> **neuron\_minimum\_stake\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:490](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L490)

***

### reject\_cost\_e8s

> **reject\_cost\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:494](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L494)

***

### transaction\_fee\_e8s

> **transaction\_fee\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:498](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L498)

***

### voting\_rewards\_parameters

> **voting\_rewards\_parameters**: \[\] \| \[[`SnsVotingRewardsParameters`](SnsVotingRewardsParameters.md)\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:502](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L502)

***

### wait\_for\_quiet\_deadline\_increase\_seconds

> **wait\_for\_quiet\_deadline\_increase\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:496](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L496)
