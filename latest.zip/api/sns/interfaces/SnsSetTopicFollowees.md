---
title: SnsSetTopicFollowees
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/types/governance.params.ts:152](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/types/governance.params.ts#L152)

The parameters to follow by ns-function

## Extends

- `SnsNeuronManagementParams`

## Properties

### followees

> **followees**: [`SnsNeuronId`](SnsNeuronId.md)[]

Defined in: [packages/sns/src/types/governance.params.ts:154](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/types/governance.params.ts#L154)

***

### functionId

> **functionId**: `bigint`

Defined in: [packages/sns/src/types/governance.params.ts:153](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/types/governance.params.ts#L153)

***

### neuronId

> **neuronId**: [`SnsNeuronId`](SnsNeuronId.md)

Defined in: [packages/sns/src/types/governance.params.ts:106](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/types/governance.params.ts#L106)

#### Inherited from

`SnsNeuronManagementParams.neuronId`
