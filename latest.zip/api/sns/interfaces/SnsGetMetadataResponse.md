---
title: SnsGetMetadataResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:261](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L261)

## Properties

### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:265](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L265)

***

### logo

> **logo**: \[\] \| \[`string`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:263](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L263)

***

### name

> **name**: \[\] \| \[`string`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:264](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L264)

***

### url

> **url**: \[\] \| \[`string`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:262](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L262)
