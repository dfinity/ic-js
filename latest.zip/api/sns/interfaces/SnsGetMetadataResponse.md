---
title: SnsGetMetadataResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:261](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L261)

## Properties

### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:265](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L265)

***

### logo

> **logo**: \[\] \| \[`string`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:263](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L263)

***

### name

> **name**: \[\] \| \[`string`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:264](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L264)

***

### url

> **url**: \[\] \| \[`string`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:262](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L262)
