---
title: SnsGetDerivedStateResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:129](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L129)

## Properties

### buyer\_total\_icp\_e8s

> **buyer\_total\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:131](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L131)

***

### cf\_neuron\_count

> **cf\_neuron\_count**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:136](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L136)

***

### cf\_participant\_count

> **cf\_participant\_count**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:132](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L132)

***

### direct\_participant\_count

> **direct\_participant\_count**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:135](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L135)

***

### direct\_participation\_icp\_e8s

> **direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:134](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L134)

***

### neurons\_fund\_participation\_icp\_e8s

> **neurons\_fund\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:133](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L133)

***

### sns\_tokens\_per\_icp

> **sns\_tokens\_per\_icp**: \[\] \| \[`number`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:130](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L130)
