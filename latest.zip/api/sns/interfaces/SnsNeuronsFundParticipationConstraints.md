---
title: SnsNeuronsFundParticipationConstraints
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:258](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L258)

## Properties

### coefficient\_intervals

> **coefficient\_intervals**: `LinearScalingCoefficient`[]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:259](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L259)

***

### ideal\_matched\_participation\_function

> **ideal\_matched\_participation\_function**: \[\] \| \[`IdealMatchedParticipationFunction`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:262](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L262)

***

### max\_neurons\_fund\_participation\_icp\_e8s

> **max\_neurons\_fund\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:260](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L260)

***

### min\_direct\_participation\_threshold\_icp\_e8s

> **min\_direct\_participation\_threshold\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:261](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L261)
