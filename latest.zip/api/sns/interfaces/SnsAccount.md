---
title: SnsAccount
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_governance.d.ts#L13)

## Properties

### owner

> **owner**: \[\] \| \[`Principal`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_governance.d.ts#L14)

***

### subaccount

> **subaccount**: \[\] \| \[`Subaccount`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_governance.d.ts#L15)
