---
title: SnsNervousSystemFunction
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:477](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_governance.d.ts#L477)

## Properties

### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:480](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_governance.d.ts#L480)

***

### function\_type

> **function\_type**: \[\] \| \[[`SnsFunctionType`](../type-aliases/SnsFunctionType.md)\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:481](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_governance.d.ts#L481)

***

### id

> **id**: `bigint`

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:478](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_governance.d.ts#L478)

***

### name

> **name**: `string`

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:479](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_governance.d.ts#L479)
