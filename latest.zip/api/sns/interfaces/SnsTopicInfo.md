---
title: SnsTopicInfo
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:747](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_governance.d.ts#L747)

## Properties

### custom\_functions

> **custom\_functions**: \[\] \| \[[`SnsNervousSystemFunction`](SnsNervousSystemFunction.md)[]\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:754](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_governance.d.ts#L754)

***

### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:753](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_governance.d.ts#L753)

***

### extension\_operations

> **extension\_operations**: \[\] \| \[`RegisteredExtensionOperationSpec`[]\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:748](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_governance.d.ts#L748)

***

### is\_critical

> **is\_critical**: \[\] \| \[`boolean`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:751](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_governance.d.ts#L751)

***

### name

> **name**: \[\] \| \[`string`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:752](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_governance.d.ts#L752)

***

### native\_functions

> **native\_functions**: \[\] \| \[[`SnsNervousSystemFunction`](SnsNervousSystemFunction.md)[]\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:749](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_governance.d.ts#L749)

***

### topic

> **topic**: \[\] \| \[[`SnsTopic`](../type-aliases/SnsTopic.md)\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:750](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_governance.d.ts#L750)
