---
title: SnsNeuronRecipe
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:346](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_swap.d.ts#L346)

## Properties

### claimed\_status

> **claimed\_status**: \[\] \| \[`number`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:348](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_swap.d.ts#L348)

***

### investor

> **investor**: \[\] \| \[`Investor`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:350](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_swap.d.ts#L350)

***

### neuron\_attributes

> **neuron\_attributes**: \[\] \| \[`NeuronAttributes`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:349](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_swap.d.ts#L349)

***

### sns

> **sns**: \[\] \| \[[`SnsTransferableAmount`](SnsTransferableAmount.md)\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:347](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_swap.d.ts#L347)
