---
title: SnsInvalidUserAmount
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:201](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_swap.d.ts#L201)

## Properties

### max\_amount\_icp\_e8s\_included

> **max\_amount\_icp\_e8s\_included**: `bigint`

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:203](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_swap.d.ts#L203)

***

### min\_amount\_icp\_e8s\_included

> **min\_amount\_icp\_e8s\_included**: `bigint`

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:202](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_swap.d.ts#L202)
