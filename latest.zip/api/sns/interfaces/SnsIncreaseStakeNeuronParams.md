---
title: SnsIncreaseStakeNeuronParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/types/governance.params.ts:88](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/types/governance.params.ts#L88)

## Extends

- `Omit`\<`QueryParams`, `"certified"`\>

## Properties

### neuronId

> **neuronId**: [`SnsNeuronId`](SnsNeuronId.md)

Defined in: [packages/sns/src/types/governance.params.ts:92](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/types/governance.params.ts#L92)

***

### source

> **source**: `IcrcAccount`

Defined in: [packages/sns/src/types/governance.params.ts:91](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/types/governance.params.ts#L91)

***

### stakeE8s

> **stakeE8s**: `bigint`

Defined in: [packages/sns/src/types/governance.params.ts:90](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/types/governance.params.ts#L90)
