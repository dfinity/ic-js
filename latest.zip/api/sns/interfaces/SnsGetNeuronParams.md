---
title: SnsGetNeuronParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/types/governance.params.ts:75](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/types/governance.params.ts#L75)

The parameters to get a Sns neuron

## Extends

- `QueryParams`

## Properties

### certified?

> `optional` **certified**: `boolean`

Defined in: packages/utils/dist/types/query.params.d.ts:6

Perform update calls (certified) or query calls (not certified).

#### Inherited from

`QueryParams.certified`

***

### neuronId

> **neuronId**: [`SnsNeuronId`](SnsNeuronId.md)

Defined in: [packages/sns/src/types/governance.params.ts:76](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/types/governance.params.ts#L76)
