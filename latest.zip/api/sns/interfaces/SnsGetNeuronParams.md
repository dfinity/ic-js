---
title: SnsGetNeuronParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/types/governance.params.ts:75](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/governance.params.ts#L75)

The parameters to get a Sns neuron

## Extends

- `QueryParams`

## Properties

### certified?

> `optional` **certified**: `boolean`

Defined in: packages/utils/dist/types/query.params.d.ts:6

Perform update calls (certified) or query calls (not certified).

#### Inherited from

`QueryParams.certified`

***

### neuronId

> **neuronId**: [`SnsNeuronId`](SnsNeuronId.md)

Defined in: [packages/sns/src/types/governance.params.ts:76](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/governance.params.ts#L76)
