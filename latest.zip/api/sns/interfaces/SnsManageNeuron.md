---
title: SnsManageNeuron
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:416](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L416)

## Properties

### command

> **command**: \[\] \| \[`Command`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:418](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L418)

***

### subaccount

> **subaccount**: `Uint8Array`

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:417](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L417)
