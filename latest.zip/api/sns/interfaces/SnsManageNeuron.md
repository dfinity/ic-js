---
title: SnsManageNeuron
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:416](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_governance.d.ts#L416)

## Properties

### command

> **command**: \[\] \| \[`Command`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:418](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_governance.d.ts#L418)

***

### subaccount

> **subaccount**: `Uint8Array`

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:417](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_governance.d.ts#L417)
