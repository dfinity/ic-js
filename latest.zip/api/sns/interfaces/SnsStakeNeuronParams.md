---
title: SnsStakeNeuronParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/types/governance.params.ts:79](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/governance.params.ts#L79)

## Extends

- `Omit`\<`QueryParams`, `"certified"`\>

## Properties

### controller

> **controller**: `Principal`

Defined in: [packages/sns/src/types/governance.params.ts:82](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/governance.params.ts#L82)

***

### createdAt?

> `optional` **createdAt**: `bigint`

Defined in: [packages/sns/src/types/governance.params.ts:84](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/governance.params.ts#L84)

***

### fee?

> `optional` **fee**: `bigint`

Defined in: [packages/sns/src/types/governance.params.ts:85](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/governance.params.ts#L85)

***

### source

> **source**: `IcrcAccount`

Defined in: [packages/sns/src/types/governance.params.ts:81](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/governance.params.ts#L81)

***

### stakeE8s

> **stakeE8s**: `bigint`

Defined in: [packages/sns/src/types/governance.params.ts:80](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/governance.params.ts#L80)
