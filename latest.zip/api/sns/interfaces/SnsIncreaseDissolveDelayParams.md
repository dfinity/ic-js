---
title: SnsIncreaseDissolveDelayParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/types/governance.params.ts:144](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/types/governance.params.ts#L144)

The parameters to increase dissolve delay

## Extends

- `SnsNeuronManagementParams`

## Properties

### additionalDissolveDelaySeconds

> **additionalDissolveDelaySeconds**: `number`

Defined in: [packages/sns/src/types/governance.params.ts:146](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/types/governance.params.ts#L146)

***

### neuronId

> **neuronId**: [`SnsNeuronId`](SnsNeuronId.md)

Defined in: [packages/sns/src/types/governance.params.ts:106](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/types/governance.params.ts#L106)

#### Inherited from

`SnsNeuronManagementParams.neuronId`
