---
title: SnsRewardEvent
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:665](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L665)

## Properties

### actual\_timestamp\_seconds

> **actual\_timestamp\_seconds**: `bigint`

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:667](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L667)

***

### distributed\_e8s\_equivalent

> **distributed\_e8s\_equivalent**: `bigint`

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:670](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L670)

***

### end\_timestamp\_seconds

> **end\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:668](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L668)

***

### round

> **round**: `bigint`

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:671](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L671)

***

### rounds\_since\_last\_distribution

> **rounds\_since\_last\_distribution**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:666](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L666)

***

### settled\_proposals

> **settled\_proposals**: [`SnsProposalId`](SnsProposalId.md)[]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:672](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L672)

***

### total\_available\_e8s\_equivalent

> **total\_available\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:669](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L669)
