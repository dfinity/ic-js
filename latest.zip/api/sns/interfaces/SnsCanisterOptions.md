---
title: SnsCanisterOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/types/canister.options.ts:4](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/canister.options.ts#L4)

## Extends

- `Omit`\<`CanisterOptions`\<`T`\>, `"canisterId"`\>

## Type Parameters

### T

`T`

## Properties

### agent?

> `optional` **agent**: `Agent`

Defined in: packages/utils/dist/types/canister.options.d.ts:4

#### Inherited from

[`GovernanceCanisterOptions`](../../nns/interfaces/GovernanceCanisterOptions.md).[`agent`](../../nns/interfaces/GovernanceCanisterOptions.md#agent)

***

### canisterId

> **canisterId**: `Principal`

Defined in: [packages/sns/src/types/canister.options.ts:7](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/canister.options.ts#L7)

***

### certifiedServiceOverride?

> `optional` **certifiedServiceOverride**: `ActorSubclass`\<`T`\>

Defined in: packages/utils/dist/types/canister.options.d.ts:7

#### Inherited from

`Omit.certifiedServiceOverride`

***

### serviceOverride?

> `optional` **serviceOverride**: `ActorSubclass`\<`T`\>

Defined in: packages/utils/dist/types/canister.options.d.ts:6

#### Inherited from

`Omit.serviceOverride`
