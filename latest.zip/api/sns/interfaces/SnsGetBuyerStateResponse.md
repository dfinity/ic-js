---
title: SnsGetBuyerStateResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:123](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L123)

## Properties

### buyer\_state

> **buyer\_state**: \[\] \| \[[`SnsSwapBuyerState`](SnsSwapBuyerState.md)\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:124](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L124)
