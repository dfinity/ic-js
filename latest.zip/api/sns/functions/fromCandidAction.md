---
title: fromCandidAction
editUrl: false
next: true
prev: true
---

> **fromCandidAction**(`action`): `Action`

Defined in: [packages/sns/src/converters/governance.converters.ts:364](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/converters/governance.converters.ts#L364)

## Parameters

### action

[`SnsAction`](../type-aliases/SnsAction.md)

## Returns

`Action`
