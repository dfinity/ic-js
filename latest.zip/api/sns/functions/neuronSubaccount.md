---
title: neuronSubaccount
editUrl: false
next: true
prev: true
---

> **neuronSubaccount**(`params`): `Subaccount`

Defined in: [packages/sns/src/utils/governance.utils.ts:18](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/utils/governance.utils.ts#L18)

Neuron subaccount is calculated as "sha256(0x0c . “neuron-stake” . controller . i)"

## Parameters

### params

#### controller

`Principal`

#### index

`number`

## Returns

`Subaccount`
