---
title: neuronSubaccount
editUrl: false
next: true
prev: true
---

> **neuronSubaccount**(`params`): `Subaccount`

Defined in: [packages/sns/src/utils/governance.utils.ts:18](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/utils/governance.utils.ts#L18)

Neuron subaccount is calculated as "sha256(0x0c . “neuron-stake” . controller . i)"

## Parameters

### params

#### controller

`Principal`

#### index

`number`

## Returns

`Subaccount`
