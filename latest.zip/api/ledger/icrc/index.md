---
title: Overview
editUrl: false
next: true
prev: true
---

## Enumerations

- [IcrcMetadataResponseEntries](enumerations/IcrcMetadataResponseEntries.md)

## Classes

- [ConsentMessageError](classes/ConsentMessageError.md)
- [ConsentMessageUnavailableError](classes/ConsentMessageUnavailableError.md)
- [GenericError](classes/GenericError.md)
- [IcrcIndexCanister](classes/IcrcIndexCanister.md)
- [IcrcIndexNgCanister](classes/IcrcIndexNgCanister.md)
- [IcrcLedgerCanister](classes/IcrcLedgerCanister.md)
- [IcrcTransferError](classes/IcrcTransferError.md)
- [IndexError](classes/IndexError.md)
- [IndexPrincipalNotSetError](classes/IndexPrincipalNotSetError.md)
- [InsufficientPaymentError](classes/InsufficientPaymentError.md)
- [UnsupportedCanisterCallError](classes/UnsupportedCanisterCallError.md)

## Interfaces

- [GetAccountTransactionsParams](interfaces/GetAccountTransactionsParams.md)
- [Icrc21ConsentMessageMetadata](interfaces/Icrc21ConsentMessageMetadata.md)
- [Icrc21ConsentMessageSpec](interfaces/Icrc21ConsentMessageSpec.md)
- [IcrcAccount](interfaces/IcrcAccount.md)
- [IcrcAllowance](interfaces/IcrcAllowance.md)
- [IcrcCandidAccount](interfaces/IcrcCandidAccount.md)
- [IcrcGetBlocksArgs](interfaces/IcrcGetBlocksArgs.md)
- [IcrcGetBlocksResult](interfaces/IcrcGetBlocksResult.md)
- [IcrcGetTransactions](interfaces/IcrcGetTransactions.md)
- [IcrcIndexNgGetTransactions](interfaces/IcrcIndexNgGetTransactions.md)
- [IcrcIndexNgTransaction](interfaces/IcrcIndexNgTransaction.md)
- [IcrcIndexNgTransactionWithId](interfaces/IcrcIndexNgTransactionWithId.md)
- [IcrcNgStatus](interfaces/IcrcNgStatus.md)
- [IcrcStandardRecord](interfaces/IcrcStandardRecord.md)
- [IcrcTokenMetadata](interfaces/IcrcTokenMetadata.md)
- [IcrcTransaction](interfaces/IcrcTransaction.md)
- [IcrcTransactionWithId](interfaces/IcrcTransactionWithId.md)
- [IcrcTransferArg](interfaces/IcrcTransferArg.md)
- [TransferParams](interfaces/TransferParams.md)

## Type Aliases

- [AllowanceParams](type-aliases/AllowanceParams.md)
- [ApproveParams](type-aliases/ApproveParams.md)
- [BalanceParams](type-aliases/BalanceParams.md)
- [GetBlocksParams](type-aliases/GetBlocksParams.md)
- [GetIndexNgAccountTransactionsParams](type-aliases/GetIndexNgAccountTransactionsParams.md)
- [Icrc21ConsentMessageDeviceSpec](type-aliases/Icrc21ConsentMessageDeviceSpec.md)
- [Icrc21ConsentMessageParams](type-aliases/Icrc21ConsentMessageParams.md)
- [Icrc3Value](type-aliases/Icrc3Value.md)
- [IcrcApproveError](type-aliases/IcrcApproveError.md)
- [IcrcBlockIndex](type-aliases/IcrcBlockIndex.md)
- [IcrcNgTxId](type-aliases/IcrcNgTxId.md)
- [IcrcSubaccount](type-aliases/IcrcSubaccount.md)
- [IcrcTimestamp](type-aliases/IcrcTimestamp.md)
- [IcrcTokenMetadataResponse](type-aliases/IcrcTokenMetadataResponse.md)
- [IcrcTokens](type-aliases/IcrcTokens.md)
- [IcrcTransferFromError](type-aliases/IcrcTransferFromError.md)
- [IcrcTransferVariantError](type-aliases/IcrcTransferVariantError.md)
- [IcrcTxId](type-aliases/IcrcTxId.md)
- [IcrcValue](type-aliases/IcrcValue.md)
- [ListSubaccountsParams](type-aliases/ListSubaccountsParams.md)
- [TransferFromParams](type-aliases/TransferFromParams.md)

## Functions

- [decodeIcrcAccount](functions/decodeIcrcAccount.md)
- [decodePayment](functions/decodePayment.md)
- [encodeIcrcAccount](functions/encodeIcrcAccount.md)
- [fromCandidAccount](functions/fromCandidAccount.md)
- [mapIcrc106GetIndexPrincipalError](functions/mapIcrc106GetIndexPrincipalError.md)
- [mapIcrc21ConsentMessageError](functions/mapIcrc21ConsentMessageError.md)
- [mapTokenMetadata](functions/mapTokenMetadata.md)
- [toApproveArgs](functions/toApproveArgs.md)
- [toCandidAccount](functions/toCandidAccount.md)
- [toIcrc21ConsentMessageArgs](functions/toIcrc21ConsentMessageArgs.md)
- [toTransferArg](functions/toTransferArg.md)
- [toTransferFromArgs](functions/toTransferFromArgs.md)
