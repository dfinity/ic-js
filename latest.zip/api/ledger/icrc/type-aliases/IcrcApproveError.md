---
title: IcrcApproveError
editUrl: false
next: true
prev: true
---

> **IcrcApproveError** = \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `null`; \} \| \{ `Duplicate`: \{ `duplicate_of`: [`IcrcBlockIndex`](IcrcBlockIndex.md); \}; \} \| \{ `BadFee`: \{ `expected_fee`: `bigint`; \}; \} \| \{ `AllowanceChanged`: \{ `current_allowance`: `bigint`; \}; \} \| \{ `CreatedInFuture`: \{ `ledger_time`: [`IcrcTimestamp`](IcrcTimestamp.md); \}; \} \| \{ `TooOld`: `null`; \} \| \{ `Expired`: \{ `ledger_time`: [`IcrcTimestamp`](IcrcTimestamp.md); \}; \} \| \{ `InsufficientFunds`: \{ `balance`: `bigint`; \}; \}

Defined in: [packages/ledger-icrc/src/candid/icrc\_ledger.d.ts:51](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icrc/src/candid/icrc_ledger.d.ts#L51)
