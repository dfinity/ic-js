---
title: IcrcApproveError
editUrl: false
next: true
prev: true
---

> **IcrcApproveError** = \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `null`; \} \| \{ `Duplicate`: \{ `duplicate_of`: [`IcrcBlockIndex`](IcrcBlockIndex.md); \}; \} \| \{ `BadFee`: \{ `expected_fee`: `bigint`; \}; \} \| \{ `AllowanceChanged`: \{ `current_allowance`: `bigint`; \}; \} \| \{ `CreatedInFuture`: \{ `ledger_time`: [`IcrcTimestamp`](IcrcTimestamp.md); \}; \} \| \{ `TooOld`: `null`; \} \| \{ `Expired`: \{ `ledger_time`: [`IcrcTimestamp`](IcrcTimestamp.md); \}; \} \| \{ `InsufficientFunds`: \{ `balance`: `bigint`; \}; \}

Defined in: [packages/ledger-icrc/src/candid/icrc\_ledger.d.ts:51](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/candid/icrc_ledger.d.ts#L51)
