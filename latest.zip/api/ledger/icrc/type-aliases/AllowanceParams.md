---
title: AllowanceParams
editUrl: false
next: true
prev: true
---

> **AllowanceParams** = `AllowanceArgs` & `QueryParams`

Defined in: [packages/ledger-icrc/src/types/ledger.params.ts:81](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/types/ledger.params.ts#L81)

Params to get the token allowance that the spender account can transfer from the specified account
