---
title: AllowanceParams
editUrl: false
next: true
prev: true
---

> **AllowanceParams** = `AllowanceArgs` & `QueryParams`

Defined in: [packages/ledger-icrc/src/types/ledger.params.ts:81](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icrc/src/types/ledger.params.ts#L81)

Params to get the token allowance that the spender account can transfer from the specified account
