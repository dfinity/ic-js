---
title: Icrc21ConsentMessageParams
editUrl: false
next: true
prev: true
---

> **Icrc21ConsentMessageParams** = `Omit`\<`ConsentMessageArgs`, `"user_preferences"`\> & `object`

Defined in: [packages/ledger-icrc/src/types/ledger.params.ts:123](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/types/ledger.params.ts#L123)

Parameters for the consent message request.

## Type Declaration

### userPreferences

> **userPreferences**: [`Icrc21ConsentMessageSpec`](../interfaces/Icrc21ConsentMessageSpec.md)

## Param

Method name of the canister call.

## Param

Argument of the canister call.

## Param

User preferences with regards to the consent message presented to the end-user.
