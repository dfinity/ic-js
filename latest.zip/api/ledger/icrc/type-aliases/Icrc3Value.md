---
title: Icrc3Value
editUrl: false
next: true
prev: true
---

> **Icrc3Value** = \{ `Int`: `bigint`; \} \| \{ `Map`: \[`string`, `ICRC3Value`\][]; \} \| \{ `Nat`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Text`: `string`; \} \| \{ `Array`: `ICRC3Value`[]; \}

Defined in: [packages/ledger-icrc/src/candid/icrc\_ledger.d.ts:319](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/candid/icrc_ledger.d.ts#L319)
