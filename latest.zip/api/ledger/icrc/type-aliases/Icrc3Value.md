---
title: Icrc3Value
editUrl: false
next: true
prev: true
---

> **Icrc3Value** = \{ `Int`: `bigint`; \} \| \{ `Map`: \[`string`, `ICRC3Value`\][]; \} \| \{ `Nat`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Text`: `string`; \} \| \{ `Array`: `ICRC3Value`[]; \}

Defined in: [packages/ledger-icrc/src/candid/icrc\_ledger.d.ts:319](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icrc/src/candid/icrc_ledger.d.ts#L319)
