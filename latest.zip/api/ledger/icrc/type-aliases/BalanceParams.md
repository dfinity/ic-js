---
title: BalanceParams
editUrl: false
next: true
prev: true
---

> **BalanceParams** = [`IcrcAccount`](../interfaces/IcrcAccount.md) & `QueryParams`

Defined in: [packages/ledger-icrc/src/types/ledger.params.ts:16](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icrc/src/types/ledger.params.ts#L16)

Params to get the balance of an ICRC-1 account.
