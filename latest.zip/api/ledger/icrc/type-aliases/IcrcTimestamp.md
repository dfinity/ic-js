---
title: IcrcTimestamp
editUrl: false
next: true
prev: true
---

> **IcrcTimestamp** = `bigint`

Defined in: [packages/ledger-icrc/src/candid/icrc\_ledger.d.ts:399](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icrc/src/candid/icrc_ledger.d.ts#L399)

Number of nanoseconds since the UNIX epoch in UTC timezone.
