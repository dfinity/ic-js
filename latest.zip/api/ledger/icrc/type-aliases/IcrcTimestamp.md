---
title: IcrcTimestamp
editUrl: false
next: true
prev: true
---

> **IcrcTimestamp** = `bigint`

Defined in: [packages/ledger-icrc/src/candid/icrc\_ledger.d.ts:399](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/candid/icrc_ledger.d.ts#L399)

Number of nanoseconds since the UNIX epoch in UTC timezone.
