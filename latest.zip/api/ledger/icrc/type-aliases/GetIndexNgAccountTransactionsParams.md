---
title: GetIndexNgAccountTransactionsParams
editUrl: false
next: true
prev: true
---

> **GetIndexNgAccountTransactionsParams** = `object` & `QueryParams`

Defined in: [packages/ledger-icrc/src/types/index-ng.params.ts:6](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icrc/src/types/index-ng.params.ts#L6)

## Type Declaration

### account

> **account**: [`IcrcAccount`](../interfaces/IcrcAccount.md)

### max\_results

> **max\_results**: `bigint`

### start?

> `optional` **start**: [`IcrcNgTxId`](IcrcNgTxId.md)
