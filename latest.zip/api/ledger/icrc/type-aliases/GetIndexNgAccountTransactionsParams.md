---
title: GetIndexNgAccountTransactionsParams
editUrl: false
next: true
prev: true
---

> **GetIndexNgAccountTransactionsParams** = `object` & `QueryParams`

Defined in: [packages/ledger-icrc/src/types/index-ng.params.ts:6](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/types/index-ng.params.ts#L6)

## Type Declaration

### account

> **account**: [`IcrcAccount`](../interfaces/IcrcAccount.md)

### max\_results

> **max\_results**: `bigint`

### start?

> `optional` **start**: [`IcrcNgTxId`](IcrcNgTxId.md)
