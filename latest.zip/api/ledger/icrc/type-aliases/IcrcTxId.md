---
title: IcrcTxId
editUrl: false
next: true
prev: true
---

> **IcrcTxId** = `bigint`

Defined in: [packages/ledger-icrc/src/candid/icrc\_index.d.ts:98](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_index.d.ts#L98)
