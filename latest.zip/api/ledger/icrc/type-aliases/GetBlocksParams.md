---
title: GetBlocksParams
editUrl: false
next: true
prev: true
---

> **GetBlocksParams** = `QueryParams` & `object`

Defined in: [packages/ledger-icrc/src/types/ledger.params.ts:133](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icrc/src/types/ledger.params.ts#L133)

Parameters to get the canister blocks.

## Type Declaration

### args

> **args**: [`IcrcGetBlocksArgs`](../interfaces/IcrcGetBlocksArgs.md)[]
