---
title: GetBlocksParams
editUrl: false
next: true
prev: true
---

> **GetBlocksParams** = `QueryParams` & `object`

Defined in: [packages/ledger-icrc/src/types/ledger.params.ts:133](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/types/ledger.params.ts#L133)

Parameters to get the canister blocks.

## Type Declaration

### args

> **args**: [`IcrcGetBlocksArgs`](../interfaces/IcrcGetBlocksArgs.md)[]
