---
title: ListSubaccountsParams
editUrl: false
next: true
prev: true
---

> **ListSubaccountsParams** = `object` & `Pick`\<[`IcrcAccount`](../interfaces/IcrcAccount.md), `"owner"`\> & `QueryParams`

Defined in: [packages/ledger-icrc/src/types/index-ng.params.ts:12](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/types/index-ng.params.ts#L12)

## Type Declaration

### start?

> `optional` **start**: [`IcrcSubaccount`](IcrcSubaccount.md)
