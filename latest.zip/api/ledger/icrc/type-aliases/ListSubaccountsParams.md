---
title: ListSubaccountsParams
editUrl: false
next: true
prev: true
---

> **ListSubaccountsParams** = `object` & `Pick`\<[`IcrcAccount`](../interfaces/IcrcAccount.md), `"owner"`\> & `QueryParams`

Defined in: [packages/ledger-icrc/src/types/index-ng.params.ts:12](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/types/index-ng.params.ts#L12)

## Type Declaration

### start?

> `optional` **start**: [`IcrcSubaccount`](IcrcSubaccount.md)
