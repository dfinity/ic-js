---
title: IcrcSubaccount
editUrl: false
next: true
prev: true
---

> **IcrcSubaccount** = `Uint8Array`

Defined in: [packages/ledger-icrc/src/candid/icrc\_ledger.d.ts:395](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_ledger.d.ts#L395)
