---
title: IcrcIndexNgTransaction
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icrc/src/candid/icrc\_index-ng.d.ts:103](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/candid/icrc_index-ng.d.ts#L103)

## Properties

### approve

> **approve**: \[\] \| \[`Approve`\]

Defined in: [packages/ledger-icrc/src/candid/icrc\_index-ng.d.ts:107](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/candid/icrc_index-ng.d.ts#L107)

***

### burn

> **burn**: \[\] \| \[`Burn`\]

Defined in: [packages/ledger-icrc/src/candid/icrc\_index-ng.d.ts:104](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/candid/icrc_index-ng.d.ts#L104)

***

### kind

> **kind**: `string`

Defined in: [packages/ledger-icrc/src/candid/icrc\_index-ng.d.ts:105](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/candid/icrc_index-ng.d.ts#L105)

***

### mint

> **mint**: \[\] \| \[`Mint`\]

Defined in: [packages/ledger-icrc/src/candid/icrc\_index-ng.d.ts:106](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/candid/icrc_index-ng.d.ts#L106)

***

### timestamp

> **timestamp**: `bigint`

Defined in: [packages/ledger-icrc/src/candid/icrc\_index-ng.d.ts:108](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/candid/icrc_index-ng.d.ts#L108)

***

### transfer

> **transfer**: \[\] \| \[`Transfer`\]

Defined in: [packages/ledger-icrc/src/candid/icrc\_index-ng.d.ts:109](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/candid/icrc_index-ng.d.ts#L109)
