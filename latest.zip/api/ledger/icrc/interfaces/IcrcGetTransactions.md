---
title: IcrcGetTransactions
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icrc/src/candid/icrc\_index.d.ts:47](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icrc/src/candid/icrc_index.d.ts#L47)

## Properties

### oldest\_tx\_id

> **oldest\_tx\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/ledger-icrc/src/candid/icrc\_index.d.ts:52](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icrc/src/candid/icrc_index.d.ts#L52)

The txid of the oldest transaction the account has

***

### transactions

> **transactions**: [`IcrcTransactionWithId`](IcrcTransactionWithId.md)[]

Defined in: [packages/ledger-icrc/src/candid/icrc\_index.d.ts:48](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icrc/src/candid/icrc_index.d.ts#L48)
