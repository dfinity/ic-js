---
title: TransferParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icrc/src/types/ledger.params.ts:35](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/types/ledger.params.ts#L35)

Params to make a transfer in an ICRC-1 ledger

## Param

The account to transfer tokens to.

## Param

The Amount of tokens to transfer.

## Param

The subaccount to transfer tokens to.

## Param

Transfer memo.

## Param

nanoseconds since unix epoc to trigger deduplication and avoid other issues
See the link for more details on deduplication
https://github.com/dfinity/ICRC-1/blob/main/standards/ICRC-1/index.md#transaction_deduplication

## Param

The fee of the transfer when it's not the default fee.

## Properties

### amount

> **amount**: `bigint`

Defined in: [packages/ledger-icrc/src/types/ledger.params.ts:41](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/types/ledger.params.ts#L41)

***

### created\_at\_time?

> `optional` **created\_at\_time**: `bigint`

Defined in: [packages/ledger-icrc/src/types/ledger.params.ts:40](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/types/ledger.params.ts#L40)

***

### fee?

> `optional` **fee**: `bigint`

Defined in: [packages/ledger-icrc/src/types/ledger.params.ts:37](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/types/ledger.params.ts#L37)

***

### from\_subaccount?

> `optional` **from\_subaccount**: [`IcrcSubaccount`](../type-aliases/IcrcSubaccount.md)

Defined in: [packages/ledger-icrc/src/types/ledger.params.ts:39](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/types/ledger.params.ts#L39)

***

### memo?

> `optional` **memo**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/ledger-icrc/src/types/ledger.params.ts:38](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/types/ledger.params.ts#L38)

***

### to

> **to**: [`IcrcCandidAccount`](IcrcCandidAccount.md)

Defined in: [packages/ledger-icrc/src/types/ledger.params.ts:36](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/types/ledger.params.ts#L36)
