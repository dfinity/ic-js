---
title: GetAccountTransactionsParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icrc/src/types/index.params.ts:4](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/types/index.params.ts#L4)

## Properties

### account

> **account**: [`IcrcAccount`](IcrcAccount.md)

Defined in: [packages/ledger-icrc/src/types/index.params.ts:7](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/types/index.params.ts#L7)

***

### max\_results

> **max\_results**: `bigint`

Defined in: [packages/ledger-icrc/src/types/index.params.ts:5](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/types/index.params.ts#L5)

***

### start?

> `optional` **start**: `bigint`

Defined in: [packages/ledger-icrc/src/types/index.params.ts:6](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/types/index.params.ts#L6)
