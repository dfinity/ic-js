---
title: GetAccountTransactionsParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icrc/src/types/index.params.ts:4](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icrc/src/types/index.params.ts#L4)

## Properties

### account

> **account**: [`IcrcAccount`](IcrcAccount.md)

Defined in: [packages/ledger-icrc/src/types/index.params.ts:7](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icrc/src/types/index.params.ts#L7)

***

### max\_results

> **max\_results**: `bigint`

Defined in: [packages/ledger-icrc/src/types/index.params.ts:5](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icrc/src/types/index.params.ts#L5)

***

### start?

> `optional` **start**: `bigint`

Defined in: [packages/ledger-icrc/src/types/index.params.ts:6](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icrc/src/types/index.params.ts#L6)
