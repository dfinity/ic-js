---
title: IcrcGetBlocksArgs
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icrc/src/candid/icrc\_ledger.d.ts:164](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icrc/src/candid/icrc_ledger.d.ts#L164)

## Properties

### length

> **length**: `bigint`

Defined in: [packages/ledger-icrc/src/candid/icrc\_ledger.d.ts:172](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icrc/src/candid/icrc_ledger.d.ts#L172)

Max number of blocks to fetch.

***

### start

> **start**: `bigint`

Defined in: [packages/ledger-icrc/src/candid/icrc\_ledger.d.ts:168](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icrc/src/candid/icrc_ledger.d.ts#L168)

The index of the first block to fetch.
