---
title: IcrcGetBlocksArgs
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icrc/src/candid/icrc\_ledger.d.ts:164](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_ledger.d.ts#L164)

## Properties

### length

> **length**: `bigint`

Defined in: [packages/ledger-icrc/src/candid/icrc\_ledger.d.ts:172](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_ledger.d.ts#L172)

Max number of blocks to fetch.

***

### start

> **start**: `bigint`

Defined in: [packages/ledger-icrc/src/candid/icrc\_ledger.d.ts:168](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_ledger.d.ts#L168)

The index of the first block to fetch.
