---
title: IcrcAccount
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icrc/src/types/ledger.responses.ts:18](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/types/ledger.responses.ts#L18)

## Properties

### owner

> **owner**: `Principal`

Defined in: [packages/ledger-icrc/src/types/ledger.responses.ts:19](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/types/ledger.responses.ts#L19)

***

### subaccount?

> `optional` **subaccount**: [`IcrcSubaccount`](../type-aliases/IcrcSubaccount.md)

Defined in: [packages/ledger-icrc/src/types/ledger.responses.ts:20](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/types/ledger.responses.ts#L20)
