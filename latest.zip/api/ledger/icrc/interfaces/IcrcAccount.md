---
title: IcrcAccount
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icrc/src/types/ledger.responses.ts:18](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icrc/src/types/ledger.responses.ts#L18)

## Properties

### owner

> **owner**: `Principal`

Defined in: [packages/ledger-icrc/src/types/ledger.responses.ts:19](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icrc/src/types/ledger.responses.ts#L19)

***

### subaccount?

> `optional` **subaccount**: [`IcrcSubaccount`](../type-aliases/IcrcSubaccount.md)

Defined in: [packages/ledger-icrc/src/types/ledger.responses.ts:20](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icrc/src/types/ledger.responses.ts#L20)
