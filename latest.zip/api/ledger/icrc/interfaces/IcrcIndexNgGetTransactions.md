---
title: IcrcIndexNgGetTransactions
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icrc/src/candid/icrc\_index-ng.d.ts:62](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_index-ng.d.ts#L62)

## Properties

### balance

> **balance**: `bigint`

Defined in: [packages/ledger-icrc/src/candid/icrc\_index-ng.d.ts:63](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_index-ng.d.ts#L63)

***

### oldest\_tx\_id

> **oldest\_tx\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/ledger-icrc/src/candid/icrc\_index-ng.d.ts:68](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_index-ng.d.ts#L68)

The txid of the oldest transaction the account has

***

### transactions

> **transactions**: [`IcrcIndexNgTransactionWithId`](IcrcIndexNgTransactionWithId.md)[]

Defined in: [packages/ledger-icrc/src/candid/icrc\_index-ng.d.ts:64](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_index-ng.d.ts#L64)
