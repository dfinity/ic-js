---
title: IcrcTransaction
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icrc/src/candid/icrc\_index.d.ts:77](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_index.d.ts#L77)

## Properties

### approve

> **approve**: \[\] \| \[`Approve`\]

Defined in: [packages/ledger-icrc/src/candid/icrc\_index.d.ts:81](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_index.d.ts#L81)

***

### burn

> **burn**: \[\] \| \[`Burn`\]

Defined in: [packages/ledger-icrc/src/candid/icrc\_index.d.ts:78](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_index.d.ts#L78)

***

### kind

> **kind**: `string`

Defined in: [packages/ledger-icrc/src/candid/icrc\_index.d.ts:79](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_index.d.ts#L79)

***

### mint

> **mint**: \[\] \| \[`Mint`\]

Defined in: [packages/ledger-icrc/src/candid/icrc\_index.d.ts:80](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_index.d.ts#L80)

***

### timestamp

> **timestamp**: `bigint`

Defined in: [packages/ledger-icrc/src/candid/icrc\_index.d.ts:82](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_index.d.ts#L82)

***

### transfer

> **transfer**: \[\] \| \[`Transfer`\]

Defined in: [packages/ledger-icrc/src/candid/icrc\_index.d.ts:83](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_index.d.ts#L83)
