---
title: IcrcTransactionWithId
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icrc/src/candid/icrc\_index.d.ts:85](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/candid/icrc_index.d.ts#L85)

## Properties

### id

> **id**: `bigint`

Defined in: [packages/ledger-icrc/src/candid/icrc\_index.d.ts:86](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/candid/icrc_index.d.ts#L86)

***

### transaction

> **transaction**: [`IcrcTransaction`](IcrcTransaction.md)

Defined in: [packages/ledger-icrc/src/candid/icrc\_index.d.ts:87](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/candid/icrc_index.d.ts#L87)
