---
title: toTransferFromArgs
editUrl: false
next: true
prev: true
---

> **toTransferFromArgs**(`__namedParameters`): `TransferFromArgs`

Defined in: [packages/ledger-icrc/src/converters/ledger.converters.ts:34](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icrc/src/converters/ledger.converters.ts#L34)

## Parameters

### \_\_namedParameters

[`TransferFromParams`](../type-aliases/TransferFromParams.md)

## Returns

`TransferFromArgs`
