---
title: toTransferFromArgs
editUrl: false
next: true
prev: true
---

> **toTransferFromArgs**(`__namedParameters`): `TransferFromArgs`

Defined in: [packages/ledger-icrc/src/converters/ledger.converters.ts:34](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/converters/ledger.converters.ts#L34)

## Parameters

### \_\_namedParameters

[`TransferFromParams`](../type-aliases/TransferFromParams.md)

## Returns

`TransferFromArgs`
