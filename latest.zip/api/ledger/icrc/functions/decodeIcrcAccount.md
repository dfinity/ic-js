---
title: decodeIcrcAccount
editUrl: false
next: true
prev: true
---

> **decodeIcrcAccount**(`accountString`): [`IcrcAccount`](../interfaces/IcrcAccount.md)

Defined in: [packages/ledger-icrc/src/utils/ledger.utils.ts:67](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/utils/ledger.utils.ts#L67)

Decodes a string into an Icrc-1 compatible account.
Formatting Reference: https://github.com/dfinity/ICRC-1/blob/main/standards/ICRC-1/TextualEncoding.md

## Parameters

### accountString

`string`

string

## Returns

[`IcrcAccount`](../interfaces/IcrcAccount.md)

IcrcAccount { owner: Principal, subaccount?: Uint8Array }

## Throws

Error if the string is not a valid Icrc-1 account
