---
title: encodeIcrcAccount
editUrl: false
next: true
prev: true
---

> **encodeIcrcAccount**(`account`): `string`

Defined in: [packages/ledger-icrc/src/utils/ledger.utils.ts:27](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/utils/ledger.utils.ts#L27)

Encodes an Icrc-1 account compatible into a string.
Formatting Reference: https://github.com/dfinity/ICRC-1/blob/main/standards/ICRC-1/TextualEncoding.md

## Parameters

### account

[`IcrcAccount`](../interfaces/IcrcAccount.md)

{ owner: Principal, subaccount?: Uint8Array }

## Returns

`string`

string
