---
title: toCandidAccount
editUrl: false
next: true
prev: true
---

> **toCandidAccount**(`-`): [`IcrcCandidAccount`](../interfaces/IcrcCandidAccount.md)

Defined in: [packages/ledger-icrc/src/converters/converters.ts:29](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icrc/src/converters/converters.ts#L29)

Converts an IcrcAccount to a Candid Account object, effectively transforming nullish properties into nullable ones.

## Parameters

### -

[`IcrcAccount`](../interfaces/IcrcAccount.md)

The IcrcAccount object to convert.

## Returns

[`IcrcCandidAccount`](../interfaces/IcrcCandidAccount.md)

- The converted Candid Account object.
