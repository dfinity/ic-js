---
title: toCandidAccount
editUrl: false
next: true
prev: true
---

> **toCandidAccount**(`-`): [`IcrcCandidAccount`](../interfaces/IcrcCandidAccount.md)

Defined in: [packages/ledger-icrc/src/converters/converters.ts:29](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/converters/converters.ts#L29)

Converts an IcrcAccount to a Candid Account object, effectively transforming nullish properties into nullable ones.

## Parameters

### -

[`IcrcAccount`](../interfaces/IcrcAccount.md)

The IcrcAccount object to convert.

## Returns

[`IcrcCandidAccount`](../interfaces/IcrcCandidAccount.md)

- The converted Candid Account object.
