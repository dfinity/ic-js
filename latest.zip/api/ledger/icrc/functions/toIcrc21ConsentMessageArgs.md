---
title: toIcrc21ConsentMessageArgs
editUrl: false
next: true
prev: true
---

> **toIcrc21ConsentMessageArgs**(`__namedParameters`): `icrc21_consent_message_request`

Defined in: [packages/ledger-icrc/src/converters/ledger.converters.ts:66](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/converters/ledger.converters.ts#L66)

## Parameters

### \_\_namedParameters

[`Icrc21ConsentMessageParams`](../type-aliases/Icrc21ConsentMessageParams.md)

## Returns

`icrc21_consent_message_request`
