---
title: Status
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icp/src/candid/index.d.ts:95](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/candid/index.d.ts#L95)

## Properties

### num\_blocks\_synced

> **num\_blocks\_synced**: `bigint`

Defined in: [packages/ledger-icp/src/candid/index.d.ts:96](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/candid/index.d.ts#L96)
