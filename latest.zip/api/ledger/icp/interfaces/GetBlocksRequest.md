---
title: GetBlocksRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icp/src/candid/index.d.ts:49](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icp/src/candid/index.d.ts#L49)

## Properties

### length

> **length**: `bigint`

Defined in: [packages/ledger-icp/src/candid/index.d.ts:51](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icp/src/candid/index.d.ts#L51)

***

### start

> **start**: `bigint`

Defined in: [packages/ledger-icp/src/candid/index.d.ts:50](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icp/src/candid/index.d.ts#L50)
