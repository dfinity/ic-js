---
title: GetAccountIdentifierTransactionsResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icp/src/candid/index.d.ts:25](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/index.d.ts#L25)

## Properties

### balance

> **balance**: `bigint`

Defined in: [packages/ledger-icp/src/candid/index.d.ts:26](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/index.d.ts#L26)

***

### oldest\_tx\_id

> **oldest\_tx\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/ledger-icp/src/candid/index.d.ts:28](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/index.d.ts#L28)

***

### transactions

> **transactions**: [`TransactionWithId`](TransactionWithId.md)[]

Defined in: [packages/ledger-icp/src/candid/index.d.ts:27](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/index.d.ts#L27)
