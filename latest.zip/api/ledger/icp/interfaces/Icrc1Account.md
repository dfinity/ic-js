---
title: Icrc1Account
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icp/src/candid/ledger.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/ledger.d.ts#L13)

## Properties

### owner

> **owner**: `Principal`

Defined in: [packages/ledger-icp/src/candid/ledger.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/ledger.d.ts#L14)

***

### subaccount

> **subaccount**: \[\] \| \[[`Icrc1SubAccount`](../type-aliases/Icrc1SubAccount.md)\]

Defined in: [packages/ledger-icp/src/candid/ledger.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/ledger.d.ts#L15)
