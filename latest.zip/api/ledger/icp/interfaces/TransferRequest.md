---
title: TransferRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icp/src/types/ledger\_converters.ts:11](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/types/ledger_converters.ts#L11)

## Properties

### amount

> **amount**: `bigint`

Defined in: [packages/ledger-icp/src/types/ledger\_converters.ts:13](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/types/ledger_converters.ts#L13)

***

### createdAt?

> `optional` **createdAt**: `bigint`

Defined in: [packages/ledger-icp/src/types/ledger\_converters.ts:21](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/types/ledger_converters.ts#L21)

***

### fee?

> `optional` **fee**: `bigint`

Defined in: [packages/ledger-icp/src/types/ledger\_converters.ts:15](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/types/ledger_converters.ts#L15)

***

### fromSubAccount?

> `optional` **fromSubAccount**: `number`[]

Defined in: [packages/ledger-icp/src/types/ledger\_converters.ts:17](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/types/ledger_converters.ts#L17)

***

### memo?

> `optional` **memo**: `bigint`

Defined in: [packages/ledger-icp/src/types/ledger\_converters.ts:14](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/types/ledger_converters.ts#L14)

***

### to

> **to**: [`AccountIdentifier`](../classes/AccountIdentifier.md)

Defined in: [packages/ledger-icp/src/types/ledger\_converters.ts:12](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/types/ledger_converters.ts#L12)
