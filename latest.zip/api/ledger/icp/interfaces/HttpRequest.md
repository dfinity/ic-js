---
title: HttpRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icp/src/candid/index.d.ts:57](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icp/src/candid/index.d.ts#L57)

## Properties

### body

> **body**: `Uint8Array`

Defined in: [packages/ledger-icp/src/candid/index.d.ts:60](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icp/src/candid/index.d.ts#L60)

***

### headers

> **headers**: \[`string`, `string`\][]

Defined in: [packages/ledger-icp/src/candid/index.d.ts:61](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icp/src/candid/index.d.ts#L61)

***

### method

> **method**: `string`

Defined in: [packages/ledger-icp/src/candid/index.d.ts:59](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icp/src/candid/index.d.ts#L59)

***

### url

> **url**: `string`

Defined in: [packages/ledger-icp/src/candid/index.d.ts:58](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icp/src/candid/index.d.ts#L58)
