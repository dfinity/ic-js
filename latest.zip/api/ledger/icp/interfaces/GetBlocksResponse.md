---
title: GetBlocksResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icp/src/candid/index.d.ts:53](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/index.d.ts#L53)

## Properties

### blocks

> **blocks**: `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/ledger-icp/src/candid/index.d.ts:54](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/index.d.ts#L54)

***

### chain\_length

> **chain\_length**: `bigint`

Defined in: [packages/ledger-icp/src/candid/index.d.ts:55](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/index.d.ts#L55)
