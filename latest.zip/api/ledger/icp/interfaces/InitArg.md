---
title: InitArg
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icp/src/candid/index.d.ts:68](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icp/src/candid/index.d.ts#L68)

## Properties

### ledger\_id

> **ledger\_id**: `Principal`

Defined in: [packages/ledger-icp/src/candid/index.d.ts:69](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icp/src/candid/index.d.ts#L69)
