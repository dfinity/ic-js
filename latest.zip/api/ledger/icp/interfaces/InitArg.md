---
title: InitArg
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icp/src/candid/index.d.ts:68](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/index.d.ts#L68)

## Properties

### ledger\_id

> **ledger\_id**: `Principal`

Defined in: [packages/ledger-icp/src/candid/index.d.ts:69](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/index.d.ts#L69)
