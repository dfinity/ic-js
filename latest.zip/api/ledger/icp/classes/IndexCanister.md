---
title: IndexCanister
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icp/src/index.canister.ts:19](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/index.canister.ts#L19)

## Extends

- `Canister`\<[`_SERVICE`](../interfaces/SERVICE.md)\>

## Constructors

### Constructor

> `protected` **new IndexCanister**(`id`, `service`, `certifiedService`): `IndexCanister`

Defined in: packages/utils/dist/services/canister.d.ts:7

#### Parameters

##### id

`Principal`

##### service

[`_SERVICE`](../interfaces/SERVICE.md)

##### certifiedService

[`_SERVICE`](../interfaces/SERVICE.md)

#### Returns

`IndexCanister`

#### Inherited from

`Canister<IndexService>.constructor`

## Properties

### caller()

> `protected` **caller**: (`__namedParameters`) => [`_SERVICE`](../interfaces/SERVICE.md)

Defined in: packages/utils/dist/services/canister.d.ts:9

#### Parameters

##### \_\_namedParameters

`QueryParams`

#### Returns

[`_SERVICE`](../interfaces/SERVICE.md)

#### Inherited from

`Canister.caller`

***

### certifiedService

> `protected` `readonly` **certifiedService**: [`_SERVICE`](../interfaces/SERVICE.md)

Defined in: packages/utils/dist/services/canister.d.ts:6

#### Inherited from

`Canister.certifiedService`

***

### service

> `protected` `readonly` **service**: [`_SERVICE`](../interfaces/SERVICE.md)

Defined in: packages/utils/dist/services/canister.d.ts:5

#### Inherited from

`Canister.service`

## Accessors

### canisterId

#### Get Signature

> **get** **canisterId**(): `Principal`

Defined in: packages/utils/dist/services/canister.d.ts:8

##### Returns

`Principal`

#### Inherited from

`Canister.canisterId`

## Methods

### accountBalance()

> **accountBalance**(`params`): `Promise`\<`bigint`\>

Defined in: [packages/ledger-icp/src/index.canister.ts:45](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/index.canister.ts#L45)

Returns the balance of the specified account identifier.

#### Parameters

##### params

`AccountBalanceParams`

The parameters to get the balance of an account.

#### Returns

`Promise`\<`bigint`\>

The balance of the given account.

***

### getTransactions()

> **getTransactions**(`params`): `Promise`\<[`GetAccountIdentifierTransactionsResponse`](../interfaces/GetAccountIdentifierTransactionsResponse.md)\>

Defined in: [packages/ledger-icp/src/index.canister.ts:64](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/index.canister.ts#L64)

Returns the transactions and balance of an ICP account.

#### Parameters

##### params

`GetTransactionsParams`

The parameters to get the transactions.

#### Returns

`Promise`\<[`GetAccountIdentifierTransactionsResponse`](../interfaces/GetAccountIdentifierTransactionsResponse.md)\>

The transactions, balance and the transaction id of the oldest transaction the account has.

#### Throws

IndexError

***

### create()

> `static` **create**(`__namedParameters`): `IndexCanister`

Defined in: [packages/ledger-icp/src/index.canister.ts:20](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/index.canister.ts#L20)

#### Parameters

##### \_\_namedParameters

`CanisterOptions`\<[`_SERVICE`](../interfaces/SERVICE.md)\>

#### Returns

`IndexCanister`
