---
title: GetAccountIdentifierTransactionsResult
editUrl: false
next: true
prev: true
---

> **GetAccountIdentifierTransactionsResult** = \{ `Ok`: [`GetAccountIdentifierTransactionsResponse`](../interfaces/GetAccountIdentifierTransactionsResponse.md); \} \| \{ `Err`: [`GetAccountIdentifierTransactionsError`](../interfaces/GetAccountIdentifierTransactionsError.md); \}

Defined in: [packages/ledger-icp/src/candid/index.d.ts:30](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/index.d.ts#L30)
