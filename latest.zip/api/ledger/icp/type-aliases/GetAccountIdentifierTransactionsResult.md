---
title: GetAccountIdentifierTransactionsResult
editUrl: false
next: true
prev: true
---

> **GetAccountIdentifierTransactionsResult** = \{ `Ok`: [`GetAccountIdentifierTransactionsResponse`](../interfaces/GetAccountIdentifierTransactionsResponse.md); \} \| \{ `Err`: [`GetAccountIdentifierTransactionsError`](../interfaces/GetAccountIdentifierTransactionsError.md); \}

Defined in: [packages/ledger-icp/src/candid/index.d.ts:30](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icp/src/candid/index.d.ts#L30)
