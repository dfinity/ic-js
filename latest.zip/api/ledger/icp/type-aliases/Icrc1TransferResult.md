---
title: Icrc1TransferResult
editUrl: false
next: true
prev: true
---

> **Icrc1TransferResult** = \{ `Ok`: [`Icrc1BlockIndex`](Icrc1BlockIndex.md); \} \| \{ `Err`: [`Icrc1TransferError`](Icrc1TransferError.md); \}

Defined in: [packages/ledger-icp/src/candid/ledger.d.ts:187](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/ledger.d.ts#L187)
