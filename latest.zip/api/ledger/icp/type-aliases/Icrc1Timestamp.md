---
title: Icrc1Timestamp
editUrl: false
next: true
prev: true
---

> **Icrc1Timestamp** = `bigint`

Defined in: [packages/ledger-icp/src/candid/ledger.d.ts:174](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/candid/ledger.d.ts#L174)

Number of nanoseconds since the UNIX epoch in UTC timezone.
