---
title: Icrc2TransferFromError
editUrl: false
next: true
prev: true
---

> **Icrc2TransferFromError** = \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `null`; \} \| \{ `InsufficientAllowance`: \{ `allowance`: [`Icrc1Tokens`](Icrc1Tokens.md); \}; \} \| \{ `BadBurn`: \{ `min_burn_amount`: [`Icrc1Tokens`](Icrc1Tokens.md); \}; \} \| \{ `Duplicate`: \{ `duplicate_of`: [`Icrc1BlockIndex`](Icrc1BlockIndex.md); \}; \} \| \{ `BadFee`: \{ `expected_fee`: [`Icrc1Tokens`](Icrc1Tokens.md); \}; \} \| \{ `CreatedInFuture`: \{ `ledger_time`: [`Icrc1Timestamp`](Icrc1Timestamp.md); \}; \} \| \{ `TooOld`: `null`; \} \| \{ `InsufficientFunds`: \{ `balance`: [`Icrc1Tokens`](Icrc1Tokens.md); \}; \}

Defined in: [packages/ledger-icp/src/candid/ledger.d.ts:486](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/ledger.d.ts#L486)
