---
title: Icrc1BlockIndex
editUrl: false
next: true
prev: true
---

> **Icrc1BlockIndex** = `bigint`

Defined in: [packages/ledger-icp/src/candid/ledger.d.ts:170](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icp/src/candid/ledger.d.ts#L170)
