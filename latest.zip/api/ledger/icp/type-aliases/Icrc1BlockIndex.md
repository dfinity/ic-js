---
title: Icrc1BlockIndex
editUrl: false
next: true
prev: true
---

> **Icrc1BlockIndex** = `bigint`

Defined in: [packages/ledger-icp/src/candid/ledger.d.ts:170](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/candid/ledger.d.ts#L170)
