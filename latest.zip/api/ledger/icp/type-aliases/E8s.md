---
title: E8s
editUrl: false
next: true
prev: true
---

> **E8s** = `bigint`

Defined in: [packages/ledger-icp/src/types/common.ts:3](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/types/common.ts#L3)
