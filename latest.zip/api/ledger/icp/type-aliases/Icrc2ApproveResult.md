---
title: Icrc2ApproveResult
editUrl: false
next: true
prev: true
---

> **Icrc2ApproveResult** = \{ `Ok`: [`Icrc1BlockIndex`](Icrc1BlockIndex.md); \} \| \{ `Err`: [`Icrc1ApproveError`](Icrc1ApproveError.md); \}

Defined in: [packages/ledger-icp/src/candid/ledger.d.ts:70](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icp/src/candid/ledger.d.ts#L70)
