---
title: Icrc2ApproveResult
editUrl: false
next: true
prev: true
---

> **Icrc2ApproveResult** = \{ `Ok`: [`Icrc1BlockIndex`](Icrc1BlockIndex.md); \} \| \{ `Err`: [`Icrc1ApproveError`](Icrc1ApproveError.md); \}

Defined in: [packages/ledger-icp/src/candid/ledger.d.ts:70](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/ledger.d.ts#L70)
