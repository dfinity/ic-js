---
title: Value
editUrl: false
next: true
prev: true
---

> **Value** = \{ `Int`: `bigint`; \} \| \{ `Nat`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Text`: `string`; \}

Defined in: [packages/ledger-icp/src/candid/ledger.d.ts:509](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/candid/ledger.d.ts#L509)

The value returned from the [icrc1_metadata] endpoint.
