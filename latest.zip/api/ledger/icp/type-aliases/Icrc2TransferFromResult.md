---
title: Icrc2TransferFromResult
editUrl: false
next: true
prev: true
---

> **Icrc2TransferFromResult** = \{ `Ok`: [`Icrc1BlockIndex`](Icrc1BlockIndex.md); \} \| \{ `Err`: [`Icrc2TransferFromError`](Icrc2TransferFromError.md); \}

Defined in: [packages/ledger-icp/src/candid/ledger.d.ts:498](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icp/src/candid/ledger.d.ts#L498)
