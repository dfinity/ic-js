---
title: mapIcrc2ApproveError
editUrl: false
next: true
prev: true
---

> **mapIcrc2ApproveError**(`rawApproveError`): [`ApproveError`](../classes/ApproveError.md)

Defined in: [packages/ledger-icp/src/errors/ledger.errors.ts:137](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/errors/ledger.errors.ts#L137)

## Parameters

### rawApproveError

[`Icrc1ApproveError`](../type-aliases/Icrc1ApproveError.md)

## Returns

[`ApproveError`](../classes/ApproveError.md)
