---
title: mapIcrc2ApproveError
editUrl: false
next: true
prev: true
---

> **mapIcrc2ApproveError**(`rawApproveError`): [`ApproveError`](../classes/ApproveError.md)

Defined in: [packages/ledger-icp/src/errors/ledger.errors.ts:137](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/errors/ledger.errors.ts#L137)

## Parameters

### rawApproveError

[`Icrc1ApproveError`](../type-aliases/Icrc1ApproveError.md)

## Returns

[`ApproveError`](../classes/ApproveError.md)
