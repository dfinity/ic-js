---
title: toIcrc2ApproveRawRequest
editUrl: false
next: true
prev: true
---

> **toIcrc2ApproveRawRequest**(`__namedParameters`): `ApproveArgs`

Defined in: [packages/ledger-icp/src/canisters/ledger/ledger.request.converts.ts:65](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icp/src/canisters/ledger/ledger.request.converts.ts#L65)

## Parameters

### \_\_namedParameters

[`Icrc2ApproveRequest`](../type-aliases/Icrc2ApproveRequest.md)

## Returns

`ApproveArgs`
