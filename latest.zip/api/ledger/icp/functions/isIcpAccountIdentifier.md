---
title: isIcpAccountIdentifier
editUrl: false
next: true
prev: true
---

> **isIcpAccountIdentifier**(`address`): `boolean`

Defined in: [packages/ledger-icp/src/utils/accounts.utils.ts:41](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/utils/accounts.utils.ts#L41)

Checks if a given string (or undefined) is a valid ICP account identifier.

It uses the `checkAccountId` function to validate the checksum, but it does not throw an error.

## Parameters

### address

The putative ICP account identifier.

`string` | `undefined`

## Returns

`boolean`
