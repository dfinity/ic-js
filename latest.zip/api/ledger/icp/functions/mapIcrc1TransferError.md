---
title: mapIcrc1TransferError
editUrl: false
next: true
prev: true
---

> **mapIcrc1TransferError**(`rawTransferError`): [`TransferError`](../classes/TransferError.md)

Defined in: [packages/ledger-icp/src/errors/ledger.errors.ts:111](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/errors/ledger.errors.ts#L111)

## Parameters

### rawTransferError

[`Icrc1TransferError`](../type-aliases/Icrc1TransferError.md)

## Returns

[`TransferError`](../classes/TransferError.md)
