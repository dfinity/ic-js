---
title: toSnapshotArgs
editUrl: false
next: true
prev: true
---

> **toSnapshotArgs**(`__namedParameters`): `object`

Defined in: [packages/ic-management/src/types/snapshot.params.ts:23](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/types/snapshot.params.ts#L23)

## Parameters

### \_\_namedParameters

[`SnapshotParams`](../type-aliases/SnapshotParams.md)

## Returns

`object`

### canister\_id

> **canister\_id**: `Principal`

### snapshot\_id

> **snapshot\_id**: [`snapshot_id`](../type-aliases/snapshot_id.md)
