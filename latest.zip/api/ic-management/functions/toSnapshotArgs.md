---
title: toSnapshotArgs
editUrl: false
next: true
prev: true
---

> **toSnapshotArgs**(`__namedParameters`): `object`

Defined in: [packages/ic-management/src/types/snapshot.params.ts:23](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/types/snapshot.params.ts#L23)

## Parameters

### \_\_namedParameters

[`SnapshotParams`](../type-aliases/SnapshotParams.md)

## Returns

`object`

### canister\_id

> **canister\_id**: `Principal`

### snapshot\_id

> **snapshot\_id**: [`snapshot_id`](../type-aliases/snapshot_id.md)
