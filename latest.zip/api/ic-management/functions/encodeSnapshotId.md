---
title: encodeSnapshotId
editUrl: false
next: true
prev: true
---

> **encodeSnapshotId**(`snapshotId`): `string`

Defined in: [packages/ic-management/src/utils/ic-management.utils.ts:15](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/utils/ic-management.utils.ts#L15)

Encodes a snapshot ID into a hex string representation.

A snapshot ID is a tuple `(CanisterId, u64)`, where:
- `CanisterId` is a unique identifier for a canister.
- `u64` is a subnet-local number (incremented for each new snapshot).

## Parameters

### snapshotId

[`snapshot_id`](../type-aliases/snapshot_id.md)

The snapshot ID to encode, represented as a `Uint8Array` or an array of numbers.

## Returns

`string`

The hex string representation of the snapshot ID.
