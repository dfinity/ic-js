---
title: decodeSnapshotId
editUrl: false
next: true
prev: true
---

> **decodeSnapshotId**(`snapshotId`): [`snapshot_id`](../type-aliases/snapshot_id.md)

Defined in: [packages/ic-management/src/utils/ic-management.utils.ts:28](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/utils/ic-management.utils.ts#L28)

Decodes a hex string representation of a snapshot ID back into its original format.

A snapshot ID is a tuple `(CanisterId, u64)`, where:
- `CanisterId` is a unique identifier for a canister.
- `u64` is a subnet-local number (incremented for each new snapshot).

## Parameters

### snapshotId

`string`

The hex string representation of the snapshot ID.

## Returns

[`snapshot_id`](../type-aliases/snapshot_id.md)

The decoded snapshot ID as a `Uint8Array`.
