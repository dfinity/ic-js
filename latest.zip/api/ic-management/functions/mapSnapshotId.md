---
title: mapSnapshotId
editUrl: false
next: true
prev: true
---

> **mapSnapshotId**(`snapshotId`): [`snapshot_id`](../type-aliases/snapshot_id.md)

Defined in: [packages/ic-management/src/utils/ic-management.utils.ts:40](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/utils/ic-management.utils.ts#L40)

Maps a snapshot ID to the appropriate format for the IC interface.

## Parameters

### snapshotId

The snapshot ID to map.
It can either be a `string` (SnapshotIdText) or a `Uint8Array | number[]` (snapshot_id).
If a `string` is provided, it is decoded into a `Uint8Array` using `decodeSnapshotId`.

`string` | [`snapshot_id`](../type-aliases/snapshot_id.md)

## Returns

[`snapshot_id`](../type-aliases/snapshot_id.md)

The mapped snapshot ID.
