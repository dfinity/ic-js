---
title: toCanisterSettings
editUrl: false
next: true
prev: true
---

> **toCanisterSettings**(`__namedParameters`): `canister_settings`

Defined in: [packages/ic-management/src/types/ic-management.params.ts:31](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/types/ic-management.params.ts#L31)

## Parameters

### \_\_namedParameters

[`CanisterSettings`](../interfaces/CanisterSettings.md) = `{}`

## Returns

`canister_settings`
