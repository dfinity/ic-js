---
title: toCanisterSettings
editUrl: false
next: true
prev: true
---

> **toCanisterSettings**(`__namedParameters`): `canister_settings`

Defined in: [packages/ic-management/src/types/ic-management.params.ts:31](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/types/ic-management.params.ts#L31)

## Parameters

### \_\_namedParameters

[`CanisterSettings`](../interfaces/CanisterSettings.md) = `{}`

## Returns

`canister_settings`
