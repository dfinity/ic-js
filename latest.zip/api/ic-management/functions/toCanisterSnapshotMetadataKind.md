---
title: toCanisterSnapshotMetadataKind
editUrl: false
next: true
prev: true
---

> **toCanisterSnapshotMetadataKind**(`kind`): \{ `wasm_module`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `wasm_memory`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `stable_memory`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `wasm_chunk`: \{ `hash`: `Uint8Array`; \}; \}

Defined in: [packages/ic-management/src/types/snapshot.params.ts:51](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/types/snapshot.params.ts#L51)

## Parameters

### kind

[`CanisterSnapshotMetadataKind`](../type-aliases/CanisterSnapshotMetadataKind.md)

## Returns

\{ `wasm_module`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `wasm_memory`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `stable_memory`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `wasm_chunk`: \{ `hash`: `Uint8Array`; \}; \}
