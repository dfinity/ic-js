---
title: toCanisterSnapshotMetadataKind
editUrl: false
next: true
prev: true
---

> **toCanisterSnapshotMetadataKind**(`kind`): \{ `wasm_module`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `wasm_memory`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `stable_memory`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `wasm_chunk`: \{ `hash`: `Uint8Array`; \}; \}

Defined in: [packages/ic-management/src/types/snapshot.params.ts:51](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/types/snapshot.params.ts#L51)

## Parameters

### kind

[`CanisterSnapshotMetadataKind`](../type-aliases/CanisterSnapshotMetadataKind.md)

## Returns

\{ `wasm_module`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `wasm_memory`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `stable_memory`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `wasm_chunk`: \{ `hash`: `Uint8Array`; \}; \}
