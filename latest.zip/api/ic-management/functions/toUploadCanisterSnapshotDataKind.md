---
title: toUploadCanisterSnapshotDataKind
editUrl: false
next: true
prev: true
---

> **toUploadCanisterSnapshotDataKind**(`kind`): \{ `wasm_module`: \{ `offset`: `bigint`; \}; \} \| \{ `wasm_memory`: \{ `offset`: `bigint`; \}; \} \| \{ `stable_memory`: \{ `offset`: `bigint`; \}; \} \| \{ `wasm_chunk`: `null`; \}

Defined in: [packages/ic-management/src/types/snapshot.params.ts:143](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/types/snapshot.params.ts#L143)

## Parameters

### kind

[`UploadCanisterSnapshotDataKind`](../type-aliases/UploadCanisterSnapshotDataKind.md)

## Returns

\{ `wasm_module`: \{ `offset`: `bigint`; \}; \} \| \{ `wasm_memory`: \{ `offset`: `bigint`; \}; \} \| \{ `stable_memory`: \{ `offset`: `bigint`; \}; \} \| \{ `wasm_chunk`: `null`; \}
