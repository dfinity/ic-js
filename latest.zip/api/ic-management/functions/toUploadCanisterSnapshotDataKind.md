---
title: toUploadCanisterSnapshotDataKind
editUrl: false
next: true
prev: true
---

> **toUploadCanisterSnapshotDataKind**(`kind`): \{ `wasm_module`: \{ `offset`: `bigint`; \}; \} \| \{ `wasm_memory`: \{ `offset`: `bigint`; \}; \} \| \{ `stable_memory`: \{ `offset`: `bigint`; \}; \} \| \{ `wasm_chunk`: `null`; \}

Defined in: [packages/ic-management/src/types/snapshot.params.ts:143](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/types/snapshot.params.ts#L143)

## Parameters

### kind

[`UploadCanisterSnapshotDataKind`](../type-aliases/UploadCanisterSnapshotDataKind.md)

## Returns

\{ `wasm_module`: \{ `offset`: `bigint`; \}; \} \| \{ `wasm_memory`: \{ `offset`: `bigint`; \}; \} \| \{ `stable_memory`: \{ `offset`: `bigint`; \}; \} \| \{ `wasm_chunk`: `null`; \}
