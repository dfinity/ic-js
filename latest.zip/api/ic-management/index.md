---
title: Overview
editUrl: false
next: true
prev: true
---

## Enumerations

- [LogVisibility](enumerations/LogVisibility.md)

## Classes

- [ICManagementCanister](classes/ICManagementCanister.md)
- [UnsupportedLogVisibility](classes/UnsupportedLogVisibility.md)

## Interfaces

- [canister\_log\_record](interfaces/canister_log_record.md)
- [canister\_status\_result](interfaces/canister_status_result.md)
- [CanisterSettings](interfaces/CanisterSettings.md)
- [CanisterStatusParams](interfaces/CanisterStatusParams.md)
- [chunk\_hash](interfaces/chunk_hash.md)
- [ClearChunkStoreParams](interfaces/ClearChunkStoreParams.md)
- [CreateCanisterParams](interfaces/CreateCanisterParams.md)
- [definite\_canister\_settings](interfaces/definite_canister_settings.md)
- [environment\_variable](interfaces/environment_variable.md)
- [fetch\_canister\_logs\_result](interfaces/fetch_canister_logs_result.md)
- [InstallChunkedCodeParams](interfaces/InstallChunkedCodeParams.md)
- [InstallCodeParams](interfaces/InstallCodeParams.md)
- [OptionSnapshotParams](interfaces/OptionSnapshotParams.md)
- [ProvisionalCreateCanisterWithCyclesParams](interfaces/ProvisionalCreateCanisterWithCyclesParams.md)
- [read\_canister\_snapshot\_data\_response](interfaces/read_canister_snapshot_data_response.md)
- [read\_canister\_snapshot\_metadata\_response](interfaces/read_canister_snapshot_metadata_response.md)
- [ReadCanisterSnapshotDataParams](interfaces/ReadCanisterSnapshotDataParams.md)
- [ReadCanisterSnapshotMetadataParams](interfaces/ReadCanisterSnapshotMetadataParams.md)
- [ReadCanisterSnapshotMetadataResponse](interfaces/ReadCanisterSnapshotMetadataResponse.md)
- [snapshot](interfaces/snapshot.md)
- [StoredChunksParams](interfaces/StoredChunksParams.md)
- [UninstallCodeParams](interfaces/UninstallCodeParams.md)
- [UpdateSettingsParams](interfaces/UpdateSettingsParams.md)
- [upload\_canister\_snapshot\_metadata\_response](interfaces/upload_canister_snapshot_metadata_response.md)
- [UploadCanisterSnapshotDataParams](interfaces/UploadCanisterSnapshotDataParams.md)
- [UploadCanisterSnapshotMetadataParams](interfaces/UploadCanisterSnapshotMetadataParams.md)
- [UploadChunkParams](interfaces/UploadChunkParams.md)

## Type Aliases

- [canister\_install\_mode](type-aliases/canister_install_mode.md)
- [CanisterSnapshotMetadataKind](type-aliases/CanisterSnapshotMetadataKind.md)
- [CanisterStatusResponse](type-aliases/CanisterStatusResponse.md)
- [FetchCanisterLogsResponse](type-aliases/FetchCanisterLogsResponse.md)
- [ICManagementCanisterOptions](type-aliases/ICManagementCanisterOptions.md)
- [list\_canister\_snapshots\_result](type-aliases/list_canister_snapshots_result.md)
- [log\_visibility](type-aliases/log_visibility.md)
- [snapshot\_id](type-aliases/snapshot_id.md)
- [SnapshotIdText](type-aliases/SnapshotIdText.md)
- [SnapshotParams](type-aliases/SnapshotParams.md)
- [take\_canister\_snapshot\_result](type-aliases/take_canister_snapshot_result.md)
- [UploadCanisterSnapshotDataKind](type-aliases/UploadCanisterSnapshotDataKind.md)
- [UploadCanisterSnapshotMetadataParam](type-aliases/UploadCanisterSnapshotMetadataParam.md)

## Functions

- [decodeSnapshotId](functions/decodeSnapshotId.md)
- [encodeSnapshotId](functions/encodeSnapshotId.md)
- [fromReadCanisterSnapshotMetadataResponse](functions/fromReadCanisterSnapshotMetadataResponse.md)
- [mapSnapshotId](functions/mapSnapshotId.md)
- [toCanisterSettings](functions/toCanisterSettings.md)
- [toCanisterSnapshotMetadataKind](functions/toCanisterSnapshotMetadataKind.md)
- [toReplaceSnapshotArgs](functions/toReplaceSnapshotArgs.md)
- [toSnapshotArgs](functions/toSnapshotArgs.md)
- [toUploadCanisterSnapshotDataKind](functions/toUploadCanisterSnapshotDataKind.md)
- [toUploadCanisterSnapshotMetadata](functions/toUploadCanisterSnapshotMetadata.md)
