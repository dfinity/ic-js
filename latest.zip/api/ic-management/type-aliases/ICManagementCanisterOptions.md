---
title: ICManagementCanisterOptions
editUrl: false
next: true
prev: true
---

> **ICManagementCanisterOptions** = `Pick`\<`CanisterOptions`\<`IcManagementService`\>, `"agent"` \| `"serviceOverride"` \| `"certifiedServiceOverride"`\>

Defined in: [packages/ic-management/src/types/canister.options.ts:4](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/types/canister.options.ts#L4)
