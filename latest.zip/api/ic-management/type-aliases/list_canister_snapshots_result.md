---
title: list_canister_snapshots_result
editUrl: false
next: true
prev: true
---

> **list\_canister\_snapshots\_result** = [`snapshot`](../interfaces/snapshot.md)[]

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:260](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/candid/ic-management.d.ts#L260)
