---
title: CanisterSnapshotMetadataKind
editUrl: false
next: true
prev: true
---

> **CanisterSnapshotMetadataKind** = \{ `wasmModule`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `wasmMemory`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `stableMemory`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `wasmChunk`: \{ `hash`: `Uint8Array`; \}; \}

Defined in: [packages/ic-management/src/types/snapshot.params.ts:41](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/types/snapshot.params.ts#L41)
