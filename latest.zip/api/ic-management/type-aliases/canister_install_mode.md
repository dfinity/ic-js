---
title: canister_install_mode
editUrl: false
next: true
prev: true
---

> **canister\_install\_mode** = \{ `reinstall`: `null`; \} \| \{ `upgrade`: \[\] \| \[\{ `skip_pre_upgrade`: \[\] \| \[`boolean`\]; `wasm_memory_persistence`: \[\] \| \[\{ `keep`: `null`; \} \| \{ `replace`: `null`; \}\]; \}\]; \} \| \{ `install`: `null`; \}

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:63](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/candid/ic-management.d.ts#L63)
