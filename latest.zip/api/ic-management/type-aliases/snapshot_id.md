---
title: snapshot_id
editUrl: false
next: true
prev: true
---

> **snapshot\_id** = `Uint8Array`

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:377](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/candid/ic-management.d.ts#L377)
