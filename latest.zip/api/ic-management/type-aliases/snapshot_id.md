---
title: snapshot_id
editUrl: false
next: true
prev: true
---

> **snapshot\_id** = `Uint8Array`

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:377](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/candid/ic-management.d.ts#L377)
