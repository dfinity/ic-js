---
title: log_visibility
editUrl: false
next: true
prev: true
---

> **log\_visibility** = \{ `controllers`: `null`; \} \| \{ `public`: `null`; \} \| \{ `allowed_viewers`: `Principal`[]; \}

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:266](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/candid/ic-management.d.ts#L266)
