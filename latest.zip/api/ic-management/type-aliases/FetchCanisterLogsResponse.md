---
title: FetchCanisterLogsResponse
editUrl: false
next: true
prev: true
---

> **FetchCanisterLogsResponse** = `ServiceResponse`\<`IcManagementService`, `"fetch_canister_logs"`\>

Defined in: [packages/ic-management/src/types/ic-management.responses.ts:9](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/types/ic-management.responses.ts#L9)
