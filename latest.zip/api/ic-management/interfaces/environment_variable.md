---
title: environment_variable
editUrl: false
next: true
prev: true
---

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:213](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/candid/ic-management.d.ts#L213)

## Properties

### name

> **name**: `string`

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:215](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/candid/ic-management.d.ts#L215)

***

### value

> **value**: `string`

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:214](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/candid/ic-management.d.ts#L214)
