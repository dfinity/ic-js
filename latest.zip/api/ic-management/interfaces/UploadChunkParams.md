---
title: UploadChunkParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/ic-management/src/types/ic-management.params.ts:85](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/types/ic-management.params.ts#L85)

## Extends

- `Pick`\<`upload_chunk_args`, `"chunk"`\>

## Properties

### canisterId

> **canisterId**: `Principal`

Defined in: [packages/ic-management/src/types/ic-management.params.ts:86](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/types/ic-management.params.ts#L86)

***

### chunk

> **chunk**: `Uint8Array`

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:446](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/candid/ic-management.d.ts#L446)

#### Inherited from

`Pick.chunk`
