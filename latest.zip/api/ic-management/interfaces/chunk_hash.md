---
title: chunk_hash
editUrl: false
next: true
prev: true
---

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:169](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/candid/ic-management.d.ts#L169)

## Properties

### hash

> **hash**: `Uint8Array`

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:170](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/candid/ic-management.d.ts#L170)
