---
title: CanisterSettings
editUrl: false
next: true
prev: true
---

Defined in: [packages/ic-management/src/types/ic-management.params.ts:17](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/types/ic-management.params.ts#L17)

## Properties

### computeAllocation?

> `optional` **computeAllocation**: `bigint`

Defined in: [packages/ic-management/src/types/ic-management.params.ts:21](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/types/ic-management.params.ts#L21)

***

### controllers?

> `optional` **controllers**: `string`[]

Defined in: [packages/ic-management/src/types/ic-management.params.ts:18](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/types/ic-management.params.ts#L18)

***

### environmentVariables?

> `optional` **environmentVariables**: [`environment_variable`](environment_variable.md)[]

Defined in: [packages/ic-management/src/types/ic-management.params.ts:26](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/types/ic-management.params.ts#L26)

***

### freezingThreshold?

> `optional` **freezingThreshold**: `bigint`

Defined in: [packages/ic-management/src/types/ic-management.params.ts:19](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/types/ic-management.params.ts#L19)

***

### logVisibility?

> `optional` **logVisibility**: [`LogVisibility`](../enumerations/LogVisibility.md)

Defined in: [packages/ic-management/src/types/ic-management.params.ts:23](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/types/ic-management.params.ts#L23)

***

### memoryAllocation?

> `optional` **memoryAllocation**: `bigint`

Defined in: [packages/ic-management/src/types/ic-management.params.ts:20](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/types/ic-management.params.ts#L20)

***

### reservedCyclesLimit?

> `optional` **reservedCyclesLimit**: `bigint`

Defined in: [packages/ic-management/src/types/ic-management.params.ts:22](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/types/ic-management.params.ts#L22)

***

### wasmMemoryLimit?

> `optional` **wasmMemoryLimit**: `bigint`

Defined in: [packages/ic-management/src/types/ic-management.params.ts:24](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/types/ic-management.params.ts#L24)

***

### wasmMemoryThreshold?

> `optional` **wasmMemoryThreshold**: `bigint`

Defined in: [packages/ic-management/src/types/ic-management.params.ts:25](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/types/ic-management.params.ts#L25)
