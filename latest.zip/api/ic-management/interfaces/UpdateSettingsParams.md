---
title: UpdateSettingsParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/ic-management/src/types/ic-management.params.ts:71](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/types/ic-management.params.ts#L71)

## Properties

### canisterId

> **canisterId**: `Principal`

Defined in: [packages/ic-management/src/types/ic-management.params.ts:72](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/types/ic-management.params.ts#L72)

***

### senderCanisterVersion?

> `optional` **senderCanisterVersion**: `bigint`

Defined in: [packages/ic-management/src/types/ic-management.params.ts:73](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/types/ic-management.params.ts#L73)

***

### settings

> **settings**: [`CanisterSettings`](CanisterSettings.md)

Defined in: [packages/ic-management/src/types/ic-management.params.ts:74](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/types/ic-management.params.ts#L74)
