---
title: UpdateSettingsParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/ic-management/src/types/ic-management.params.ts:71](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/types/ic-management.params.ts#L71)

## Properties

### canisterId

> **canisterId**: `Principal`

Defined in: [packages/ic-management/src/types/ic-management.params.ts:72](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/types/ic-management.params.ts#L72)

***

### senderCanisterVersion?

> `optional` **senderCanisterVersion**: `bigint`

Defined in: [packages/ic-management/src/types/ic-management.params.ts:73](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/types/ic-management.params.ts#L73)

***

### settings

> **settings**: [`CanisterSettings`](CanisterSettings.md)

Defined in: [packages/ic-management/src/types/ic-management.params.ts:74](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/types/ic-management.params.ts#L74)
