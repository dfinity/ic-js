---
title: upload_canister_snapshot_metadata_response
editUrl: false
next: true
prev: true
---

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:442](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/candid/ic-management.d.ts#L442)

## Properties

### snapshot\_id

> **snapshot\_id**: [`snapshot_id`](../type-aliases/snapshot_id.md)

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:443](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/candid/ic-management.d.ts#L443)
