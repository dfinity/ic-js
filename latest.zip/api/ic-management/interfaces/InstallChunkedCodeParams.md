---
title: InstallChunkedCodeParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/ic-management/src/types/ic-management.params.ts:97](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/types/ic-management.params.ts#L97)

## Extends

- `Omit`\<[`InstallCodeParams`](InstallCodeParams.md), `"canisterId"` \| `"wasmModule"`\>

## Properties

### arg

> **arg**: `Uint8Array`

Defined in: [packages/ic-management/src/types/ic-management.params.ts:81](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/types/ic-management.params.ts#L81)

#### Inherited from

[`InstallCodeParams`](InstallCodeParams.md).[`arg`](InstallCodeParams.md#arg)

***

### chunkHashesList

> **chunkHashesList**: [`chunk_hash`](chunk_hash.md)[]

Defined in: [packages/ic-management/src/types/ic-management.params.ts:99](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/types/ic-management.params.ts#L99)

***

### mode

> **mode**: [`canister_install_mode`](../type-aliases/canister_install_mode.md)

Defined in: [packages/ic-management/src/types/ic-management.params.ts:78](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/types/ic-management.params.ts#L78)

#### Inherited from

[`InstallCodeParams`](InstallCodeParams.md).[`mode`](InstallCodeParams.md#mode)

***

### senderCanisterVersion?

> `optional` **senderCanisterVersion**: `bigint`

Defined in: [packages/ic-management/src/types/ic-management.params.ts:82](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/types/ic-management.params.ts#L82)

#### Inherited from

[`InstallCodeParams`](InstallCodeParams.md).[`senderCanisterVersion`](InstallCodeParams.md#sendercanisterversion)

***

### storeCanisterId?

> `optional` **storeCanisterId**: `Principal`

Defined in: [packages/ic-management/src/types/ic-management.params.ts:101](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/types/ic-management.params.ts#L101)

***

### targetCanisterId

> **targetCanisterId**: `Principal`

Defined in: [packages/ic-management/src/types/ic-management.params.ts:100](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/types/ic-management.params.ts#L100)

***

### wasmModuleHash

> **wasmModuleHash**: `string` \| `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/ic-management/src/types/ic-management.params.ts:102](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/types/ic-management.params.ts#L102)
