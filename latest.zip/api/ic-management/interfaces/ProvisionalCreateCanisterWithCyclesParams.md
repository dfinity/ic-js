---
title: ProvisionalCreateCanisterWithCyclesParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/ic-management/src/types/ic-management.params.ts:110](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/types/ic-management.params.ts#L110)

## Properties

### amount?

> `optional` **amount**: `bigint`

Defined in: [packages/ic-management/src/types/ic-management.params.ts:111](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/types/ic-management.params.ts#L111)

***

### canisterId?

> `optional` **canisterId**: `Principal`

Defined in: [packages/ic-management/src/types/ic-management.params.ts:113](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/types/ic-management.params.ts#L113)

***

### settings?

> `optional` **settings**: [`CanisterSettings`](CanisterSettings.md)

Defined in: [packages/ic-management/src/types/ic-management.params.ts:112](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/types/ic-management.params.ts#L112)
