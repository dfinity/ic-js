---
title: canister_log_record
editUrl: false
next: true
prev: true
---

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:78](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/candid/ic-management.d.ts#L78)

## Properties

### content

> **content**: `Uint8Array`

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:81](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/candid/ic-management.d.ts#L81)

***

### idx

> **idx**: `bigint`

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:79](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/candid/ic-management.d.ts#L79)

***

### timestamp\_nanos

> **timestamp\_nanos**: `bigint`

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:80](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/candid/ic-management.d.ts#L80)
