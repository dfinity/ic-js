---
title: SnsAction
editUrl: false
next: true
prev: true
---

> **SnsAction** = \{ `ManageNervousSystemParameters`: [`SnsNervousSystemParameters`](../interfaces/SnsNervousSystemParameters.md); \} \| \{ `AddGenericNervousSystemFunction`: [`SnsNervousSystemFunction`](../interfaces/SnsNervousSystemFunction.md); \} \| \{ `ManageDappCanisterSettings`: `ManageDappCanisterSettings`; \} \| \{ `ExecuteExtensionOperation`: `ExecuteExtensionOperation`; \} \| \{ `UpgradeExtension`: `UpgradeExtension`; \} \| \{ `RemoveGenericNervousSystemFunction`: `bigint`; \} \| \{ `SetTopicsForCustomProposals`: `SetTopicsForCustomProposals`; \} \| \{ `RegisterExtension`: `RegisterExtension`; \} \| \{ `UpgradeSnsToNextVersion`: \{ \}; \} \| \{ `RegisterDappCanisters`: `RegisterDappCanisters`; \} \| \{ `TransferSnsTreasuryFunds`: [`TransferSnsTreasuryFunds`](../interfaces/TransferSnsTreasuryFunds.md); \} \| \{ `UpgradeSnsControlledCanister`: `UpgradeSnsControlledCanister`; \} \| \{ `DeregisterDappCanisters`: `DeregisterDappCanisters`; \} \| \{ `MintSnsTokens`: `MintSnsTokens`; \} \| \{ `AdvanceSnsTargetVersion`: `AdvanceSnsTargetVersion`; \} \| \{ `Unspecified`: \{ \}; \} \| \{ `ManageSnsMetadata`: `ManageSnsMetadata`; \} \| \{ `ExecuteGenericNervousSystemFunction`: `ExecuteGenericNervousSystemFunction`; \} \| \{ `ManageLedgerParameters`: `ManageLedgerParameters`; \} \| \{ `Motion`: `Motion`; \}

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L17)
