---
title: SnsAction
editUrl: false
next: true
prev: true
---

> **SnsAction** = \{ `ManageNervousSystemParameters`: [`SnsNervousSystemParameters`](../interfaces/SnsNervousSystemParameters.md); \} \| \{ `AddGenericNervousSystemFunction`: [`SnsNervousSystemFunction`](../interfaces/SnsNervousSystemFunction.md); \} \| \{ `ManageDappCanisterSettings`: `ManageDappCanisterSettings`; \} \| \{ `ExecuteExtensionOperation`: `ExecuteExtensionOperation`; \} \| \{ `UpgradeExtension`: `UpgradeExtension`; \} \| \{ `RemoveGenericNervousSystemFunction`: `bigint`; \} \| \{ `SetTopicsForCustomProposals`: `SetTopicsForCustomProposals`; \} \| \{ `RegisterExtension`: `RegisterExtension`; \} \| \{ `UpgradeSnsToNextVersion`: \{ \}; \} \| \{ `RegisterDappCanisters`: `RegisterDappCanisters`; \} \| \{ `TransferSnsTreasuryFunds`: [`TransferSnsTreasuryFunds`](../interfaces/TransferSnsTreasuryFunds.md); \} \| \{ `UpgradeSnsControlledCanister`: `UpgradeSnsControlledCanister`; \} \| \{ `DeregisterDappCanisters`: `DeregisterDappCanisters`; \} \| \{ `MintSnsTokens`: `MintSnsTokens`; \} \| \{ `AdvanceSnsTargetVersion`: `AdvanceSnsTargetVersion`; \} \| \{ `Unspecified`: \{ \}; \} \| \{ `ManageSnsMetadata`: `ManageSnsMetadata`; \} \| \{ `ExecuteGenericNervousSystemFunction`: `ExecuteGenericNervousSystemFunction`; \} \| \{ `ManageLedgerParameters`: `ManageLedgerParameters`; \} \| \{ `Motion`: `Motion`; \}

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_governance.d.ts#L17)
