---
title: neuronSubaccount
editUrl: false
next: true
prev: true
---

> **neuronSubaccount**(`params`): `Subaccount`

Defined in: [packages/sns/src/utils/governance.utils.ts:18](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/utils/governance.utils.ts#L18)

Neuron subaccount is calculated as "sha256(0x0c . “neuron-stake” . controller . i)"

## Parameters

### params

#### controller

`Principal`

#### index

`number`

## Returns

`Subaccount`
