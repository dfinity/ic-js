---
title: fromCandidAction
editUrl: false
next: true
prev: true
---

> **fromCandidAction**(`action`): `Action`

Defined in: [packages/sns/src/converters/governance.converters.ts:364](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/converters/governance.converters.ts#L364)

## Parameters

### action

[`SnsAction`](../type-aliases/SnsAction.md)

## Returns

`Action`
