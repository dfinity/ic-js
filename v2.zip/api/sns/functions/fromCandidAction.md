---
title: fromCandidAction
editUrl: false
next: true
prev: true
---

> **fromCandidAction**(`action`): `Action`

Defined in: [packages/sns/src/converters/governance.converters.ts:364](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/converters/governance.converters.ts#L364)

## Parameters

### action

[`SnsAction`](../type-aliases/SnsAction.md)

## Returns

`Action`
