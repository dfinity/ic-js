---
title: Overview
editUrl: false
next: true
prev: true
---

## Enumerations

- [GetOpenTicketErrorType](enumerations/GetOpenTicketErrorType.md)
- [NewSaleTicketResponseErrorType](enumerations/NewSaleTicketResponseErrorType.md)
- [SnsNeuronPermissionType](enumerations/SnsNeuronPermissionType.md)
- [SnsProposalDecisionStatus](enumerations/SnsProposalDecisionStatus.md)
- [SnsProposalRewardStatus](enumerations/SnsProposalRewardStatus.md)
- [SnsSwapLifecycle](enumerations/SnsSwapLifecycle.md)
- [SnsVote](enumerations/SnsVote.md)

## Classes

- [SnsGovernanceCanister](classes/SnsGovernanceCanister.md)
- [SnsGovernanceError](classes/SnsGovernanceError.md)
- [SnsGovernanceTestCanister](classes/SnsGovernanceTestCanister.md)
- [SnsRootCanister](classes/SnsRootCanister.md)
- [SnsSwapCanister](classes/SnsSwapCanister.md)
- [SnsSwapGetOpenTicketError](classes/SnsSwapGetOpenTicketError.md)
- [SnsSwapNewTicketError](classes/SnsSwapNewTicketError.md)
- [SnsWrapper](classes/SnsWrapper.md)
- [UnsupportedMethodError](classes/UnsupportedMethodError.md)

## Interfaces

- [CfParticipant](interfaces/CfParticipant.md)
- [InitSnsCanistersOptions](interfaces/InitSnsCanistersOptions.md)
- [InitSnsWrapper](interfaces/InitSnsWrapper.md)
- [SnsAccount](interfaces/SnsAccount.md)
- [SnsBallot](interfaces/SnsBallot.md)
- [SnsCanisterOptions](interfaces/SnsCanisterOptions.md)
- [SnsCanisterStatus](interfaces/SnsCanisterStatus.md)
- [SnsClaimNeuronParams](interfaces/SnsClaimNeuronParams.md)
- [SnsClaimOrRefreshArgs](interfaces/SnsClaimOrRefreshArgs.md)
- [SnsDefaultFollowees](interfaces/SnsDefaultFollowees.md)
- [SnsDisburseMaturityInProgress](interfaces/SnsDisburseMaturityInProgress.md)
- [SnsDisburseNeuronParams](interfaces/SnsDisburseNeuronParams.md)
- [SnsFinalizeSwapResponse](interfaces/SnsFinalizeSwapResponse.md)
- [SnsFollowee](interfaces/SnsFollowee.md)
- [SnsFolloweesForTopic](interfaces/SnsFolloweesForTopic.md)
- [SnsGetAutoFinalizationStatusResponse](interfaces/SnsGetAutoFinalizationStatusResponse.md)
- [SnsGetBuyerStateRequest](interfaces/SnsGetBuyerStateRequest.md)
- [SnsGetBuyerStateResponse](interfaces/SnsGetBuyerStateResponse.md)
- [SnsGetDerivedStateResponse](interfaces/SnsGetDerivedStateResponse.md)
- [SnsGetInitResponse](interfaces/SnsGetInitResponse.md)
- [SnsGetLifecycleResponse](interfaces/SnsGetLifecycleResponse.md)
- [SnsGetMetadataResponse](interfaces/SnsGetMetadataResponse.md)
- [SnsGetMetricsResponse](interfaces/SnsGetMetricsResponse.md)
- [SnsGetNeuronParams](interfaces/SnsGetNeuronParams.md)
- [SnsGetProposalParams](interfaces/SnsGetProposalParams.md)
- [SnsGetSaleParametersResponse](interfaces/SnsGetSaleParametersResponse.md)
- [SnsIncreaseDissolveDelayParams](interfaces/SnsIncreaseDissolveDelayParams.md)
- [SnsIncreaseStakeNeuronParams](interfaces/SnsIncreaseStakeNeuronParams.md)
- [SnsInvalidUserAmount](interfaces/SnsInvalidUserAmount.md)
- [SnsListNervousSystemFunctionsResponse](interfaces/SnsListNervousSystemFunctionsResponse.md)
- [SnsListNeuronsParams](interfaces/SnsListNeuronsParams.md)
- [SnsListProposalsParams](interfaces/SnsListProposalsParams.md)
- [SnsListProposalsResponse](interfaces/SnsListProposalsResponse.md)
- [SnsListTopicsResponse](interfaces/SnsListTopicsResponse.md)
- [SnsManageNeuron](interfaces/SnsManageNeuron.md)
- [SnsManageNeuronResponse](interfaces/SnsManageNeuronResponse.md)
- [SnsNervousSystemFunction](interfaces/SnsNervousSystemFunction.md)
- [SnsNervousSystemParameters](interfaces/SnsNervousSystemParameters.md)
- [SnsNeuron](interfaces/SnsNeuron.md)
- [SnsNeuronAutoStakeMaturityParams](interfaces/SnsNeuronAutoStakeMaturityParams.md)
- [SnsNeuronDisburseMaturityParams](interfaces/SnsNeuronDisburseMaturityParams.md)
- [SnsNeuronId](interfaces/SnsNeuronId.md)
- [SnsNeuronPermission](interfaces/SnsNeuronPermission.md)
- [SnsNeuronPermissionList](interfaces/SnsNeuronPermissionList.md)
- [SnsNeuronPermissionsParams](interfaces/SnsNeuronPermissionsParams.md)
- [SnsNeuronRecipe](interfaces/SnsNeuronRecipe.md)
- [SnsNeuronsFundParticipationConstraints](interfaces/SnsNeuronsFundParticipationConstraints.md)
- [SnsNeuronStakeMaturityParams](interfaces/SnsNeuronStakeMaturityParams.md)
- [SnsParams](interfaces/SnsParams.md)
- [SnsPercentage](interfaces/SnsPercentage.md)
- [SnsProposalData](interfaces/SnsProposalData.md)
- [SnsProposalId](interfaces/SnsProposalId.md)
- [SnsRefreshBuyerTokensResponse](interfaces/SnsRefreshBuyerTokensResponse.md)
- [SnsRegisterVoteParams](interfaces/SnsRegisterVoteParams.md)
- [SnsRewardEvent](interfaces/SnsRewardEvent.md)
- [SnsSetDissolveTimestampParams](interfaces/SnsSetDissolveTimestampParams.md)
- [SnsSetFollowingParams](interfaces/SnsSetFollowingParams.md)
- [SnsSetTopicFollowees](interfaces/SnsSetTopicFollowees.md)
- [SnsSplitNeuronParams](interfaces/SnsSplitNeuronParams.md)
- [SnsStakeNeuronParams](interfaces/SnsStakeNeuronParams.md)
- [SnsSwap](interfaces/SnsSwap.md)
- [SnsSwapBuyerState](interfaces/SnsSwapBuyerState.md)
- [SnsSwapDerivedState](interfaces/SnsSwapDerivedState.md)
- [SnsSwapInit](interfaces/SnsSwapInit.md)
- [SnsSwapTicket](interfaces/SnsSwapTicket.md)
- [SnsTally](interfaces/SnsTally.md)
- [SnsTopicInfo](interfaces/SnsTopicInfo.md)
- [SnsTransferableAmount](interfaces/SnsTransferableAmount.md)
- [SnsVotingRewardsParameters](interfaces/SnsVotingRewardsParameters.md)
- [TransferSnsTreasuryFunds](interfaces/TransferSnsTreasuryFunds.md)

## Type Aliases

- [SnsAction](type-aliases/SnsAction.md)
- [SnsFunctionType](type-aliases/SnsFunctionType.md)
- [SnsListTopicsParams](type-aliases/SnsListTopicsParams.md)
- [SnsTopic](type-aliases/SnsTopic.md)

## Variables

- [initSnsWrapper](variables/initSnsWrapper.md)

## Functions

- [fromCandidAction](functions/fromCandidAction.md)
- [neuronSubaccount](functions/neuronSubaccount.md)
