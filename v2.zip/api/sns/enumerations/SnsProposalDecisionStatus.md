---
title: SnsProposalDecisionStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/enums/governance.enums.ts:67](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/governance.enums.ts#L67)

## Enumeration Members

### PROPOSAL\_DECISION\_STATUS\_ADOPTED

> **PROPOSAL\_DECISION\_STATUS\_ADOPTED**: `3`

Defined in: [packages/sns/src/enums/governance.enums.ts:78](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/governance.enums.ts#L78)

***

### PROPOSAL\_DECISION\_STATUS\_EXECUTED

> **PROPOSAL\_DECISION\_STATUS\_EXECUTED**: `4`

Defined in: [packages/sns/src/enums/governance.enums.ts:81](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/governance.enums.ts#L81)

***

### PROPOSAL\_DECISION\_STATUS\_FAILED

> **PROPOSAL\_DECISION\_STATUS\_FAILED**: `5`

Defined in: [packages/sns/src/enums/governance.enums.ts:84](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/governance.enums.ts#L84)

***

### PROPOSAL\_DECISION\_STATUS\_OPEN

> **PROPOSAL\_DECISION\_STATUS\_OPEN**: `1`

Defined in: [packages/sns/src/enums/governance.enums.ts:71](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/governance.enums.ts#L71)

***

### PROPOSAL\_DECISION\_STATUS\_REJECTED

> **PROPOSAL\_DECISION\_STATUS\_REJECTED**: `2`

Defined in: [packages/sns/src/enums/governance.enums.ts:74](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/governance.enums.ts#L74)

***

### PROPOSAL\_DECISION\_STATUS\_UNSPECIFIED

> **PROPOSAL\_DECISION\_STATUS\_UNSPECIFIED**: `0`

Defined in: [packages/sns/src/enums/governance.enums.ts:68](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/governance.enums.ts#L68)
