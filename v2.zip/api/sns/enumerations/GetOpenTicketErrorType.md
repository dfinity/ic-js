---
title: GetOpenTicketErrorType
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/enums/swap.enums.ts:12](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/enums/swap.enums.ts#L12)

## Enumeration Members

### TYPE\_SALE\_CLOSED

> **TYPE\_SALE\_CLOSED**: `2`

Defined in: [packages/sns/src/enums/swap.enums.ts:15](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/enums/swap.enums.ts#L15)

***

### TYPE\_SALE\_NOT\_OPEN

> **TYPE\_SALE\_NOT\_OPEN**: `1`

Defined in: [packages/sns/src/enums/swap.enums.ts:14](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/enums/swap.enums.ts#L14)

***

### TYPE\_UNSPECIFIED

> **TYPE\_UNSPECIFIED**: `0`

Defined in: [packages/sns/src/enums/swap.enums.ts:13](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/enums/swap.enums.ts#L13)
