---
title: SnsVote
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/enums/governance.enums.ts:87](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/governance.enums.ts#L87)

## Enumeration Members

### No

> **No**: `2`

Defined in: [packages/sns/src/enums/governance.enums.ts:90](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/governance.enums.ts#L90)

***

### Unspecified

> **Unspecified**: `0`

Defined in: [packages/sns/src/enums/governance.enums.ts:88](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/governance.enums.ts#L88)

***

### Yes

> **Yes**: `1`

Defined in: [packages/sns/src/enums/governance.enums.ts:89](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/governance.enums.ts#L89)
