---
title: SnsNeuronPermissionType
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/enums/governance.enums.ts:2](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/governance.enums.ts#L2)

## Enumeration Members

### NEURON\_PERMISSION\_TYPE\_CONFIGURE\_DISSOLVE\_STATE

> **NEURON\_PERMISSION\_TYPE\_CONFIGURE\_DISSOLVE\_STATE**: `1`

Defined in: [packages/sns/src/enums/governance.enums.ts:7](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/governance.enums.ts#L7)

***

### NEURON\_PERMISSION\_TYPE\_DISBURSE

> **NEURON\_PERMISSION\_TYPE\_DISBURSE**: `5`

Defined in: [packages/sns/src/enums/governance.enums.ts:24](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/governance.enums.ts#L24)

***

### NEURON\_PERMISSION\_TYPE\_DISBURSE\_MATURITY

> **NEURON\_PERMISSION\_TYPE\_DISBURSE\_MATURITY**: `8`

Defined in: [packages/sns/src/enums/governance.enums.ts:38](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/governance.enums.ts#L38)

***

### NEURON\_PERMISSION\_TYPE\_MANAGE\_PRINCIPALS

> **NEURON\_PERMISSION\_TYPE\_MANAGE\_PRINCIPALS**: `2`

Defined in: [packages/sns/src/enums/governance.enums.ts:13](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/governance.enums.ts#L13)

***

### NEURON\_PERMISSION\_TYPE\_MANAGE\_VOTING\_PERMISSION

> **NEURON\_PERMISSION\_TYPE\_MANAGE\_VOTING\_PERMISSION**: `10`

Defined in: [packages/sns/src/enums/governance.enums.ts:45](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/governance.enums.ts#L45)

***

### ~~NEURON\_PERMISSION\_TYPE\_MERGE\_MATURITY~~

> **NEURON\_PERMISSION\_TYPE\_MERGE\_MATURITY**: `7`

Defined in: [packages/sns/src/enums/governance.enums.ts:34](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/governance.enums.ts#L34)

#### Deprecated

***

### NEURON\_PERMISSION\_TYPE\_SPLIT

> **NEURON\_PERMISSION\_TYPE\_SPLIT**: `6`

Defined in: [packages/sns/src/enums/governance.enums.ts:27](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/governance.enums.ts#L27)

***

### NEURON\_PERMISSION\_TYPE\_STAKE\_MATURITY

> **NEURON\_PERMISSION\_TYPE\_STAKE\_MATURITY**: `9`

Defined in: [packages/sns/src/enums/governance.enums.ts:41](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/governance.enums.ts#L41)

***

### NEURON\_PERMISSION\_TYPE\_SUBMIT\_PROPOSAL

> **NEURON\_PERMISSION\_TYPE\_SUBMIT\_PROPOSAL**: `3`

Defined in: [packages/sns/src/enums/governance.enums.ts:18](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/governance.enums.ts#L18)

***

### NEURON\_PERMISSION\_TYPE\_UNSPECIFIED

> **NEURON\_PERMISSION\_TYPE\_UNSPECIFIED**: `0`

Defined in: [packages/sns/src/enums/governance.enums.ts:3](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/governance.enums.ts#L3)

***

### NEURON\_PERMISSION\_TYPE\_VOTE

> **NEURON\_PERMISSION\_TYPE\_VOTE**: `4`

Defined in: [packages/sns/src/enums/governance.enums.ts:21](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/enums/governance.enums.ts#L21)
