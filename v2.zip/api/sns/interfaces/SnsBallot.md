---
title: SnsBallot
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:61](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L61)

## Properties

### cast\_timestamp\_seconds

> **cast\_timestamp\_seconds**: `bigint`

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:63](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L63)

***

### vote

> **vote**: `number`

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:62](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L62)

***

### voting\_power

> **voting\_power**: `bigint`

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:64](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L64)
