---
title: SnsSwapDerivedState
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:63](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L63)

## Properties

### buyer\_total\_icp\_e8s

> **buyer\_total\_icp\_e8s**: `bigint`

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:65](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L65)

***

### cf\_neuron\_count

> **cf\_neuron\_count**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:70](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L70)

***

### cf\_participant\_count

> **cf\_participant\_count**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:66](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L66)

***

### direct\_participant\_count

> **direct\_participant\_count**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:69](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L69)

***

### direct\_participation\_icp\_e8s

> **direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:68](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L68)

***

### neurons\_fund\_participation\_icp\_e8s

> **neurons\_fund\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:67](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L67)

***

### sns\_tokens\_per\_icp

> **sns\_tokens\_per\_icp**: `number`

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:64](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L64)
