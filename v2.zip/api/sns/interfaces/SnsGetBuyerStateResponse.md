---
title: SnsGetBuyerStateResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:123](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_swap.d.ts#L123)

## Properties

### buyer\_state

> **buyer\_state**: \[\] \| \[[`SnsSwapBuyerState`](SnsSwapBuyerState.md)\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:124](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_swap.d.ts#L124)
