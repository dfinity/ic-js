---
title: InitSnsWrapper
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/sns.ts:29](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.ts#L29)

> **InitSnsWrapper**(`options`): `Promise`\<[`SnsWrapper`](../classes/SnsWrapper.md)\>

Defined in: [packages/sns/src/sns.ts:30](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.ts#L30)

## Parameters

### options

[`InitSnsCanistersOptions`](InitSnsCanistersOptions.md)

## Returns

`Promise`\<[`SnsWrapper`](../classes/SnsWrapper.md)\>
