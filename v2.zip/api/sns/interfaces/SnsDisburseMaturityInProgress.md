---
title: SnsDisburseMaturityInProgress
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:185](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_governance.d.ts#L185)

## Properties

### account\_to\_disburse\_to

> **account\_to\_disburse\_to**: \[\] \| \[[`SnsAccount`](SnsAccount.md)\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:188](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_governance.d.ts#L188)

***

### amount\_e8s

> **amount\_e8s**: `bigint`

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:187](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_governance.d.ts#L187)

***

### finalize\_disbursement\_timestamp\_seconds

> **finalize\_disbursement\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:189](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_governance.d.ts#L189)

***

### timestamp\_of\_disbursement\_seconds

> **timestamp\_of\_disbursement\_seconds**: `bigint`

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:186](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_governance.d.ts#L186)
