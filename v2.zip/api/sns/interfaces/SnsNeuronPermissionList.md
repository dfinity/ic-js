---
title: SnsNeuronPermissionList
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:540](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L540)

## Properties

### permissions

> **permissions**: `Int32Array`

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:541](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L541)
