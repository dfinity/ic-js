---
title: SnsCanisterStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_root.d.ts:35](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_root.d.ts#L35)

## Properties

### cycles

> **cycles**: `bigint`

Defined in: [packages/sns/src/candid/sns\_root.d.ts:39](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_root.d.ts#L39)

***

### idle\_cycles\_burned\_per\_day

> **idle\_cycles\_burned\_per\_day**: `bigint`

Defined in: [packages/sns/src/candid/sns\_root.d.ts:42](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_root.d.ts#L42)

***

### memory\_metrics

> **memory\_metrics**: \[\] \| \[`MemoryMetrics`\]

Defined in: [packages/sns/src/candid/sns\_root.d.ts:36](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_root.d.ts#L36)

***

### memory\_size

> **memory\_size**: `bigint`

Defined in: [packages/sns/src/candid/sns\_root.d.ts:38](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_root.d.ts#L38)

***

### module\_hash

> **module\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/sns/src/candid/sns\_root.d.ts:43](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_root.d.ts#L43)

***

### query\_stats

> **query\_stats**: \[\] \| \[`QueryStats`\]

Defined in: [packages/sns/src/candid/sns\_root.d.ts:41](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_root.d.ts#L41)

***

### settings

> **settings**: `DefiniteCanisterSettingsArgs`

Defined in: [packages/sns/src/candid/sns\_root.d.ts:40](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_root.d.ts#L40)

***

### status

> **status**: `CanisterStatusType`

Defined in: [packages/sns/src/candid/sns\_root.d.ts:37](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_root.d.ts#L37)
