---
title: SnsNeuron
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:506](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L506)

## Properties

### aging\_since\_timestamp\_seconds

> **aging\_since\_timestamp\_seconds**: `bigint`

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:518](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L518)

***

### auto\_stake\_maturity

> **auto\_stake\_maturity**: \[\] \| \[`boolean`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:517](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L517)

***

### cached\_neuron\_stake\_e8s

> **cached\_neuron\_stake\_e8s**: `bigint`

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:511](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L511)

***

### created\_timestamp\_seconds

> **created\_timestamp\_seconds**: `bigint`

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:512](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L512)

***

### disburse\_maturity\_in\_progress

> **disburse\_maturity\_in\_progress**: [`SnsDisburseMaturityInProgress`](SnsDisburseMaturityInProgress.md)[]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:522](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L522)

***

### dissolve\_state

> **dissolve\_state**: \[\] \| \[`DissolveState`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:519](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L519)

***

### followees

> **followees**: \[`bigint`, `Followees`\][]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:523](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L523)

***

### id

> **id**: \[\] \| \[[`SnsNeuronId`](SnsNeuronId.md)\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:507](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L507)

***

### maturity\_e8s\_equivalent

> **maturity\_e8s\_equivalent**: `bigint`

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:510](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L510)

***

### neuron\_fees\_e8s

> **neuron\_fees\_e8s**: `bigint`

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:524](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L524)

***

### permissions

> **permissions**: [`SnsNeuronPermission`](SnsNeuronPermission.md)[]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:509](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L509)

***

### source\_nns\_neuron\_id

> **source\_nns\_neuron\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:516](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L516)

***

### staked\_maturity\_e8s\_equivalent

> **staked\_maturity\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:508](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L508)

***

### topic\_followees

> **topic\_followees**: \[\] \| \[\{ `topic_id_to_followees`: \[`number`, [`SnsFolloweesForTopic`](SnsFolloweesForTopic.md)\][]; \}\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:513](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L513)

***

### vesting\_period\_seconds

> **vesting\_period\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:521](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L521)

***

### voting\_power\_percentage\_multiplier

> **voting\_power\_percentage\_multiplier**: `bigint`

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:520](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L520)
