---
title: SnsListProposalsParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/types/governance.params.ts:32](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/types/governance.params.ts#L32)

The parameters available to list Sns proposals

## Extends

- `QueryParams`

## Properties

### beforeProposal?

> `optional` **beforeProposal**: [`SnsProposalId`](SnsProposalId.md)

Defined in: [packages/sns/src/types/governance.params.ts:41](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/types/governance.params.ts#L41)

***

### certified?

> `optional` **certified**: `boolean`

Defined in: packages/utils/dist/types/query.params.d.ts:6

Perform update calls (certified) or query calls (not certified).

#### Inherited from

`QueryParams.certified`

***

### excludeType?

> `optional` **excludeType**: `bigint`[]

Defined in: [packages/sns/src/types/governance.params.ts:47](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/types/governance.params.ts#L47)

***

### includeRewardStatus?

> `optional` **includeRewardStatus**: [`SnsProposalRewardStatus`](../enumerations/SnsProposalRewardStatus.md)[]

Defined in: [packages/sns/src/types/governance.params.ts:37](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/types/governance.params.ts#L37)

***

### includeStatus?

> `optional` **includeStatus**: [`SnsProposalDecisionStatus`](../enumerations/SnsProposalDecisionStatus.md)[]

Defined in: [packages/sns/src/types/governance.params.ts:52](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/types/governance.params.ts#L52)

***

### includeTopics?

> `optional` **includeTopics**: ([`SnsTopic`](../type-aliases/SnsTopic.md) \| `null`)[]

Defined in: [packages/sns/src/types/governance.params.ts:60](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/types/governance.params.ts#L60)

***

### limit?

> `optional` **limit**: `number`

Defined in: [packages/sns/src/types/governance.params.ts:44](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/types/governance.params.ts#L44)
