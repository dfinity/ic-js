---
title: SnsGetLifecycleResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:141](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L141)

## Properties

### decentralization\_sale\_open\_timestamp\_seconds

> **decentralization\_sale\_open\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:142](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L142)

***

### decentralization\_swap\_termination\_timestamp\_seconds

> **decentralization\_swap\_termination\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:144](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L144)

***

### lifecycle

> **lifecycle**: \[\] \| \[`number`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:143](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L143)
