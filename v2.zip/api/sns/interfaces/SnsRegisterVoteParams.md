---
title: SnsRegisterVoteParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/types/governance.params.ts:173](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/types/governance.params.ts#L173)

The parameters to register vote

## Extends

- `SnsNeuronManagementParams`

## Properties

### neuronId

> **neuronId**: [`SnsNeuronId`](SnsNeuronId.md)

Defined in: [packages/sns/src/types/governance.params.ts:106](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/types/governance.params.ts#L106)

#### Inherited from

`SnsNeuronManagementParams.neuronId`

***

### proposalId

> **proposalId**: [`SnsProposalId`](SnsProposalId.md)

Defined in: [packages/sns/src/types/governance.params.ts:175](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/types/governance.params.ts#L175)

***

### vote

> **vote**: [`SnsVote`](../enumerations/SnsVote.md)

Defined in: [packages/sns/src/types/governance.params.ts:174](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/types/governance.params.ts#L174)
