---
title: SnsProposalData
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:610](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L610)

## Properties

### action

> **action**: `bigint`

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:614](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L614)

***

### action\_auxiliary

> **action\_auxiliary**: \[\] \| \[`ActionAuxiliary`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:616](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L616)

***

### ballots

> **ballots**: \[`string`, [`SnsBallot`](SnsBallot.md)\][]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:617](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L617)

***

### decided\_timestamp\_seconds

> **decided\_timestamp\_seconds**: `bigint`

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:627](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L627)

***

### executed\_timestamp\_seconds

> **executed\_timestamp\_seconds**: `bigint`

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:633](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L633)

***

### failed\_timestamp\_seconds

> **failed\_timestamp\_seconds**: `bigint`

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:620](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L620)

***

### failure\_reason

> **failure\_reason**: \[\] \| \[`GovernanceError`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:615](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L615)

***

### id

> **id**: \[\] \| \[[`SnsProposalId`](SnsProposalId.md)\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:611](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L611)

***

### initial\_voting\_period\_seconds

> **initial\_voting\_period\_seconds**: `bigint`

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:623](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L623)

***

### is\_eligible\_for\_rewards

> **is\_eligible\_for\_rewards**: `boolean`

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:632](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L632)

***

### latest\_tally

> **latest\_tally**: \[\] \| \[[`SnsTally`](SnsTally.md)\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:625](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L625)

***

### minimum\_yes\_proportion\_of\_exercised

> **minimum\_yes\_proportion\_of\_exercised**: \[\] \| \[[`SnsPercentage`](SnsPercentage.md)\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:631](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L631)

***

### minimum\_yes\_proportion\_of\_total

> **minimum\_yes\_proportion\_of\_total**: \[\] \| \[[`SnsPercentage`](SnsPercentage.md)\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:618](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L618)

***

### payload\_text\_rendering

> **payload\_text\_rendering**: \[\] \| \[`string`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:612](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L612)

***

### proposal

> **proposal**: \[\] \| \[`Proposal`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:628](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L628)

***

### proposal\_creation\_timestamp\_seconds

> **proposal\_creation\_timestamp\_seconds**: `bigint`

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:622](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L622)

***

### proposer

> **proposer**: \[\] \| \[[`SnsNeuronId`](SnsNeuronId.md)\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:629](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L629)

***

### reject\_cost\_e8s

> **reject\_cost\_e8s**: `bigint`

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:624](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L624)

***

### reward\_event\_end\_timestamp\_seconds

> **reward\_event\_end\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:621](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L621)

***

### reward\_event\_round

> **reward\_event\_round**: `bigint`

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:619](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L619)

***

### topic

> **topic**: \[\] \| \[[`SnsTopic`](../type-aliases/SnsTopic.md)\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:613](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L613)

***

### wait\_for\_quiet\_deadline\_increase\_seconds

> **wait\_for\_quiet\_deadline\_increase\_seconds**: `bigint`

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:626](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L626)

***

### wait\_for\_quiet\_state

> **wait\_for\_quiet\_state**: \[\] \| \[`WaitForQuietState`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:630](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L630)
