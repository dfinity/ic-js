---
title: SnsFinalizeSwapResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:100](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L100)

## Properties

### claim\_neuron\_result

> **claim\_neuron\_result**: \[\] \| \[`SweepResult`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:112](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L112)

***

### create\_sns\_neuron\_recipes\_result

> **create\_sns\_neuron\_recipes\_result**: \[\] \| \[`SweepResult`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:102](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L102)

***

### error\_message

> **error\_message**: \[\] \| \[`string`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:106](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L106)

***

### set\_dapp\_controllers\_call\_result

> **set\_dapp\_controllers\_call\_result**: \[\] \| \[`SetDappControllersCallResult`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:101](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L101)

***

### set\_mode\_call\_result

> **set\_mode\_call\_result**: \[\] \| \[`SetModeCallResult`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:110](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L110)

***

### settle\_community\_fund\_participation\_result

> **settle\_community\_fund\_participation\_result**: \[\] \| \[`SettleCommunityFundParticipationResult`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:103](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L103)

***

### settle\_neurons\_fund\_participation\_result

> **settle\_neurons\_fund\_participation\_result**: \[\] \| \[`SettleNeuronsFundParticipationResult`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:107](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L107)

***

### sweep\_icp\_result

> **sweep\_icp\_result**: \[\] \| \[`SweepResult`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:111](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L111)

***

### sweep\_sns\_result

> **sweep\_sns\_result**: \[\] \| \[`SweepResult`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:113](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L113)
