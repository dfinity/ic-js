---
title: SnsListNeuronsParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/types/governance.params.ts:20](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/governance.params.ts#L20)

The parameters available to list Sns neurons

## Extends

- `QueryParams`

## Properties

### beforeNeuronId?

> `optional` **beforeNeuronId**: [`SnsNeuronId`](SnsNeuronId.md)

Defined in: [packages/sns/src/types/governance.params.ts:26](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/governance.params.ts#L26)

Index the search to returns a list that starts after specified neuron id

***

### certified?

> `optional` **certified**: `boolean`

Defined in: packages/utils/dist/types/query.params.d.ts:6

Perform update calls (certified) or query calls (not certified).

#### Inherited from

`QueryParams.certified`

***

### limit?

> `optional` **limit**: `number`

Defined in: [packages/sns/src/types/governance.params.ts:24](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/governance.params.ts#L24)

The maximum number of neurons returned by the method `list_neurons`

***

### principal?

> `optional` **principal**: `Principal`

Defined in: [packages/sns/src/types/governance.params.ts:22](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/governance.params.ts#L22)

Scope the query to a particular principal
