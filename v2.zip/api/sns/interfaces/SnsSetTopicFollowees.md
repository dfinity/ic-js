---
title: SnsSetTopicFollowees
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/types/governance.params.ts:152](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/governance.params.ts#L152)

The parameters to follow by ns-function

## Extends

- `SnsNeuronManagementParams`

## Properties

### followees

> **followees**: [`SnsNeuronId`](SnsNeuronId.md)[]

Defined in: [packages/sns/src/types/governance.params.ts:154](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/governance.params.ts#L154)

***

### functionId

> **functionId**: `bigint`

Defined in: [packages/sns/src/types/governance.params.ts:153](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/governance.params.ts#L153)

***

### neuronId

> **neuronId**: [`SnsNeuronId`](SnsNeuronId.md)

Defined in: [packages/sns/src/types/governance.params.ts:106](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/governance.params.ts#L106)

#### Inherited from

`SnsNeuronManagementParams.neuronId`
