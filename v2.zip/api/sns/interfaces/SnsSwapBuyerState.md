---
title: SnsSwapBuyerState
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L13)

## Properties

### has\_created\_neuron\_recipes

> **has\_created\_neuron\_recipes**: \[\] \| \[`boolean`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L15)

***

### icp

> **icp**: \[\] \| \[[`SnsTransferableAmount`](SnsTransferableAmount.md)\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L14)
