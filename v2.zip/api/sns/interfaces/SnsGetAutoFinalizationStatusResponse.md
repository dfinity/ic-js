---
title: SnsGetAutoFinalizationStatusResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:115](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_swap.d.ts#L115)

## Properties

### auto\_finalize\_swap\_response

> **auto\_finalize\_swap\_response**: \[\] \| \[[`SnsFinalizeSwapResponse`](SnsFinalizeSwapResponse.md)\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:116](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_swap.d.ts#L116)

***

### has\_auto\_finalize\_been\_attempted

> **has\_auto\_finalize\_been\_attempted**: \[\] \| \[`boolean`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:117](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_swap.d.ts#L117)

***

### is\_auto\_finalize\_enabled

> **is\_auto\_finalize\_enabled**: \[\] \| \[`boolean`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:118](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_swap.d.ts#L118)
