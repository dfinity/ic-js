---
title: SnsGetNeuronParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/types/governance.params.ts:75](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/types/governance.params.ts#L75)

The parameters to get a Sns neuron

## Extends

- `QueryParams`

## Properties

### certified?

> `optional` **certified**: `boolean`

Defined in: packages/utils/dist/types/query.params.d.ts:6

Perform update calls (certified) or query calls (not certified).

#### Inherited from

`QueryParams.certified`

***

### neuronId

> **neuronId**: [`SnsNeuronId`](SnsNeuronId.md)

Defined in: [packages/sns/src/types/governance.params.ts:76](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/types/governance.params.ts#L76)
