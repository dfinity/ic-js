---
title: SnsNeuronPermissionsParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/types/governance.params.ts:112](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/types/governance.params.ts#L112)

The parameters to add permissions to a neuron

## Extends

- `SnsNeuronManagementParams`

## Properties

### neuronId

> **neuronId**: [`SnsNeuronId`](SnsNeuronId.md)

Defined in: [packages/sns/src/types/governance.params.ts:106](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/types/governance.params.ts#L106)

#### Inherited from

`SnsNeuronManagementParams.neuronId`

***

### permissions

> **permissions**: [`SnsNeuronPermissionType`](../enumerations/SnsNeuronPermissionType.md)[]

Defined in: [packages/sns/src/types/governance.params.ts:114](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/types/governance.params.ts#L114)

***

### principal

> **principal**: `Principal`

Defined in: [packages/sns/src/types/governance.params.ts:113](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/types/governance.params.ts#L113)
