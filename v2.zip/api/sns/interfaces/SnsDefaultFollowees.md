---
title: SnsDefaultFollowees
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:162](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L162)

## Properties

### followees

> **followees**: \[`bigint`, `Followees`\][]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:163](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L163)
