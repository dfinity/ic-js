---
title: SnsClaimNeuronParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/types/governance.params.ts:181](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/types/governance.params.ts#L181)

The parameters to claim a neuron

## Properties

### controller

> **controller**: `Principal`

Defined in: [packages/sns/src/types/governance.params.ts:183](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/types/governance.params.ts#L183)

***

### memo

> **memo**: `bigint`

Defined in: [packages/sns/src/types/governance.params.ts:182](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/types/governance.params.ts#L182)

***

### subaccount

> **subaccount**: `Subaccount`

Defined in: [packages/sns/src/types/governance.params.ts:184](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/types/governance.params.ts#L184)
