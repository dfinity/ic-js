---
title: SnsClaimNeuronParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/types/governance.params.ts:181](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/governance.params.ts#L181)

The parameters to claim a neuron

## Properties

### controller

> **controller**: `Principal`

Defined in: [packages/sns/src/types/governance.params.ts:183](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/governance.params.ts#L183)

***

### memo

> **memo**: `bigint`

Defined in: [packages/sns/src/types/governance.params.ts:182](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/governance.params.ts#L182)

***

### subaccount

> **subaccount**: `Subaccount`

Defined in: [packages/sns/src/types/governance.params.ts:184](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/types/governance.params.ts#L184)
