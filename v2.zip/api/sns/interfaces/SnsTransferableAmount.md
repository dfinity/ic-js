---
title: SnsTransferableAmount
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:390](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L390)

## Properties

### amount\_e8s

> **amount\_e8s**: `bigint`

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:393](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L393)

***

### amount\_transferred\_e8s

> **amount\_transferred\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:394](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L394)

***

### transfer\_fee\_paid\_e8s

> **transfer\_fee\_paid\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:391](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L391)

***

### transfer\_start\_timestamp\_seconds

> **transfer\_start\_timestamp\_seconds**: `bigint`

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:392](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L392)

***

### transfer\_success\_timestamp\_seconds

> **transfer\_success\_timestamp\_seconds**: `bigint`

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:395](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L395)
