---
title: SnsListTopicsResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:396](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_governance.d.ts#L396)

## Properties

### topics

> **topics**: \[\] \| \[[`SnsTopicInfo`](SnsTopicInfo.md)[]\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:398](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_governance.d.ts#L398)

***

### uncategorized\_functions

> **uncategorized\_functions**: \[\] \| \[[`SnsNervousSystemFunction`](SnsNervousSystemFunction.md)[]\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:397](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_governance.d.ts#L397)
