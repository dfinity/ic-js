---
title: SnsAccount
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L13)

## Properties

### owner

> **owner**: \[\] \| \[`Principal`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L14)

***

### subaccount

> **subaccount**: \[\] \| \[`Subaccount`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L15)
