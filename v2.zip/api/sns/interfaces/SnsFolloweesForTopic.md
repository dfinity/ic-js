---
title: SnsFolloweesForTopic
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:244](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L244)

## Properties

### followees

> **followees**: [`SnsFollowee`](SnsFollowee.md)[]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:246](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L246)

***

### topic

> **topic**: \[\] \| \[[`SnsTopic`](../type-aliases/SnsTopic.md)\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:245](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_governance.d.ts#L245)
