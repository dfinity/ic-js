---
title: SnsFolloweesForTopic
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:244](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L244)

## Properties

### followees

> **followees**: [`SnsFollowee`](SnsFollowee.md)[]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:246](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L246)

***

### topic

> **topic**: \[\] \| \[[`SnsTopic`](../type-aliases/SnsTopic.md)\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:245](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L245)
