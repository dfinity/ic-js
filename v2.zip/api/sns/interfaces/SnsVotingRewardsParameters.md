---
title: SnsVotingRewardsParameters
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:884](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_governance.d.ts#L884)

## Properties

### final\_reward\_rate\_basis\_points

> **final\_reward\_rate\_basis\_points**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:885](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_governance.d.ts#L885)

***

### initial\_reward\_rate\_basis\_points

> **initial\_reward\_rate\_basis\_points**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:886](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_governance.d.ts#L886)

***

### reward\_rate\_transition\_duration\_seconds

> **reward\_rate\_transition\_duration\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:887](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_governance.d.ts#L887)

***

### round\_duration\_seconds

> **round\_duration\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:888](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_governance.d.ts#L888)
