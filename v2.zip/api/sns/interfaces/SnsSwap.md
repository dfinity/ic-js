---
title: SnsSwap
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:352](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L352)

## Properties

### already\_tried\_to\_auto\_finalize

> **already\_tried\_to\_auto\_finalize**: \[\] \| \[`boolean`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:361](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L361)

***

### auto\_finalize\_swap\_response

> **auto\_finalize\_swap\_response**: \[\] \| \[[`SnsFinalizeSwapResponse`](SnsFinalizeSwapResponse.md)\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:353](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L353)

***

### buyers

> **buyers**: \[`string`, [`SnsSwapBuyerState`](SnsSwapBuyerState.md)\][]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:368](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L368)

***

### cf\_participants

> **cf\_participants**: [`CfParticipant`](CfParticipant.md)[]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:359](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L359)

***

### decentralization\_sale\_open\_timestamp\_seconds

> **decentralization\_sale\_open\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:356](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L356)

***

### decentralization\_swap\_termination\_timestamp\_seconds

> **decentralization\_swap\_termination\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:367](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L367)

***

### direct\_participation\_icp\_e8s

> **direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:364](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L364)

***

### finalize\_swap\_in\_progress

> **finalize\_swap\_in\_progress**: \[\] \| \[`boolean`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:357](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L357)

***

### init

> **init**: \[\] \| \[[`SnsSwapInit`](SnsSwapInit.md)\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:360](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L360)

***

### lifecycle

> **lifecycle**: `number`

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:365](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L365)

***

### neuron\_recipes

> **neuron\_recipes**: [`SnsNeuronRecipe`](SnsNeuronRecipe.md)[]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:354](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L354)

***

### neurons\_fund\_participation\_icp\_e8s

> **neurons\_fund\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:362](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L362)

***

### next\_ticket\_id

> **next\_ticket\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:355](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L355)

***

### open\_sns\_token\_swap\_proposal\_id

> **open\_sns\_token\_swap\_proposal\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:370](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L370)

***

### params

> **params**: \[\] \| \[[`SnsParams`](SnsParams.md)\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:369](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L369)

***

### purge\_old\_tickets\_last\_completion\_timestamp\_nanoseconds

> **purge\_old\_tickets\_last\_completion\_timestamp\_nanoseconds**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:363](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L363)

***

### purge\_old\_tickets\_next\_principal

> **purge\_old\_tickets\_next\_principal**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:366](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L366)

***

### timers

> **timers**: \[\] \| \[`Timers`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:358](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L358)
