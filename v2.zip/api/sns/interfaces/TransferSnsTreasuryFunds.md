---
title: TransferSnsTreasuryFunds
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:759](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L759)

## Properties

### amount\_e8s

> **amount\_e8s**: `bigint`

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:764](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L764)

***

### from\_treasury

> **from\_treasury**: `number`

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:760](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L760)

***

### memo

> **memo**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:763](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L763)

***

### to\_principal

> **to\_principal**: \[\] \| \[`Principal`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:761](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L761)

***

### to\_subaccount

> **to\_subaccount**: \[\] \| \[`Subaccount`\]

Defined in: [packages/sns/src/candid/sns\_governance.d.ts:762](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_governance.d.ts#L762)
