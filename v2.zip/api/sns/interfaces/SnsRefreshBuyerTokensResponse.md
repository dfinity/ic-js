---
title: SnsRefreshBuyerTokensResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:321](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L321)

## Properties

### icp\_accepted\_participation\_e8s

> **icp\_accepted\_participation\_e8s**: `bigint`

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:322](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L322)

***

### icp\_ledger\_account\_balance\_e8s

> **icp\_ledger\_account\_balance\_e8s**: `bigint`

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:323](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L323)
