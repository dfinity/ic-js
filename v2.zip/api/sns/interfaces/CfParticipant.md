---
title: CfParticipant
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:47](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L47)

## Properties

### cf\_neurons

> **cf\_neurons**: `CfNeuron`[]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:50](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L50)

***

### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:48](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L48)

***

### hotkey\_principal

> **hotkey\_principal**: `string`

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:49](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L49)
