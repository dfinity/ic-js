---
title: CfParticipant
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:47](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_swap.d.ts#L47)

## Properties

### cf\_neurons

> **cf\_neurons**: `CfNeuron`[]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:50](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_swap.d.ts#L50)

***

### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:48](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_swap.d.ts#L48)

***

### hotkey\_principal

> **hotkey\_principal**: `string`

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:49](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_swap.d.ts#L49)
