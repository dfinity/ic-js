---
title: SnsSwapInit
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:170](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L170)

## Properties

### confirmation\_text

> **confirmation\_text**: \[\] \| \[`string`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:181](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L181)

***

### fallback\_controller\_principal\_ids

> **fallback\_controller\_principal\_ids**: `string`[]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:178](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L178)

***

### icp\_ledger\_canister\_id

> **icp\_ledger\_canister\_id**: `string`

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:188](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L188)

***

### max\_direct\_participation\_icp\_e8s

> **max\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:199](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L199)

***

### max\_icp\_e8s

> **max\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:179](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L179)

***

### max\_participant\_icp\_e8s

> **max\_participant\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:194](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L194)

***

### min\_direct\_participation\_icp\_e8s

> **min\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:196](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L196)

***

### min\_icp\_e8s

> **min\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:198](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L198)

***

### min\_participant\_icp\_e8s

> **min\_participant\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:174](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L174)

***

### min\_participants

> **min\_participants**: \[\] \| \[`number`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:184](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L184)

***

### neuron\_basket\_construction\_parameters

> **neuron\_basket\_construction\_parameters**: \[\] \| \[`NeuronBasketConstructionParameters`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:175](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L175)

***

### neuron\_minimum\_stake\_e8s

> **neuron\_minimum\_stake\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:180](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L180)

***

### neurons\_fund\_participation

> **neurons\_fund\_participation**: \[\] \| \[`boolean`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:173](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L173)

***

### neurons\_fund\_participation\_constraints

> **neurons\_fund\_participation\_constraints**: \[\] \| \[[`SnsNeuronsFundParticipationConstraints`](SnsNeuronsFundParticipationConstraints.md)\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:190](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L190)

***

### nns\_governance\_canister\_id

> **nns\_governance\_canister\_id**: `string`

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:186](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L186)

***

### nns\_proposal\_id

> **nns\_proposal\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:171](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L171)

***

### restricted\_countries

> **restricted\_countries**: \[\] \| \[`Countries`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:197](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L197)

***

### should\_auto\_finalize

> **should\_auto\_finalize**: \[\] \| \[`boolean`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:193](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L193)

***

### sns\_governance\_canister\_id

> **sns\_governance\_canister\_id**: `string`

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:195](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L195)

***

### sns\_ledger\_canister\_id

> **sns\_ledger\_canister\_id**: `string`

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:189](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L189)

***

### sns\_root\_canister\_id

> **sns\_root\_canister\_id**: `string`

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:172](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L172)

***

### sns\_token\_e8s

> **sns\_token\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:185](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L185)

***

### swap\_due\_timestamp\_seconds

> **swap\_due\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:183](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L183)

***

### swap\_start\_timestamp\_seconds

> **swap\_start\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:182](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L182)

***

### transaction\_fee\_e8s

> **transaction\_fee\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:187](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L187)
