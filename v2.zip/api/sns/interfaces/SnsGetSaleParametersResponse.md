---
title: SnsGetSaleParametersResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:149](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_swap.d.ts#L149)

## Properties

### params

> **params**: \[\] \| \[[`SnsParams`](SnsParams.md)\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:150](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/candid/sns_swap.d.ts#L150)
