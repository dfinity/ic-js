---
title: SnsGetSaleParametersResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:149](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L149)

## Properties

### params

> **params**: \[\] \| \[[`SnsParams`](SnsParams.md)\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:150](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/candid/sns_swap.d.ts#L150)
