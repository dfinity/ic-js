---
title: SnsGetSaleParametersResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:149](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L149)

## Properties

### params

> **params**: \[\] \| \[[`SnsParams`](SnsParams.md)\]

Defined in: [packages/sns/src/candid/sns\_swap.d.ts:150](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/candid/sns_swap.d.ts#L150)
