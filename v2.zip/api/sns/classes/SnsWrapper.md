---
title: SnsWrapper
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/sns.wrapper.ts:89](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L89)

Sns wrapper - notably used by NNS-dapp - ease the access to a particular Sns.
It knows all the Sns' canisters, wrap and enhance their available features.
A wrapper either performs query or update calls.

## Constructors

### Constructor

> **new SnsWrapper**(`__namedParameters`): `SnsWrapper`

Defined in: [packages/sns/src/sns.wrapper.ts:100](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L100)

Constructor to instantiate a Sns

#### Parameters

##### \_\_namedParameters

`SnsWrapperOptions`

#### Returns

`SnsWrapper`

## Accessors

### canisterIds

#### Get Signature

> **get** **canisterIds**(): `object`

Defined in: [packages/sns/src/sns.wrapper.ts:119](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L119)

Binds the list of canister ids of the Sns.

##### Returns

`object`

###### governanceCanisterId

> **governanceCanisterId**: `Principal`

###### indexCanisterId

> **indexCanisterId**: `Principal`

###### ledgerCanisterId

> **ledgerCanisterId**: `Principal`

###### rootCanisterId

> **rootCanisterId**: `Principal`

###### swapCanisterId

> **swapCanisterId**: `Principal`

## Methods

### addNeuronPermissions()

> **addNeuronPermissions**(`params`): `Promise`\<`void`\>

Defined in: [packages/sns/src/sns.wrapper.ts:336](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L336)

#### Parameters

##### params

[`SnsNeuronPermissionsParams`](../interfaces/SnsNeuronPermissionsParams.md)

#### Returns

`Promise`\<`void`\>

***

### autoStakeMaturity()

> **autoStakeMaturity**(`params`): `Promise`\<`void`\>

Defined in: [packages/sns/src/sns.wrapper.ts:460](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L460)

#### Parameters

##### params

[`SnsNeuronAutoStakeMaturityParams`](../interfaces/SnsNeuronAutoStakeMaturityParams.md)

#### Returns

`Promise`\<`void`\>

***

### balance()

> **balance**(`params`): `Promise`\<`bigint`\>

Defined in: [packages/sns/src/sns.wrapper.ts:182](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L182)

#### Parameters

##### params

`Omit`\<`BalanceParams`, `"certified"`\>

#### Returns

`Promise`\<`bigint`\>

***

### claimNeuron()

> **claimNeuron**(`params`): `Promise`\<[`SnsNeuronId`](../interfaces/SnsNeuronId.md)\>

Defined in: [packages/sns/src/sns.wrapper.ts:344](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L344)

#### Parameters

##### params

[`SnsClaimNeuronParams`](../interfaces/SnsClaimNeuronParams.md)

#### Returns

`Promise`\<[`SnsNeuronId`](../interfaces/SnsNeuronId.md)\>

***

### disburse()

> **disburse**(`params`): `Promise`\<`void`\>

Defined in: [packages/sns/src/sns.wrapper.ts:357](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L357)

#### Parameters

##### params

[`SnsDisburseNeuronParams`](../interfaces/SnsDisburseNeuronParams.md)

#### Returns

`Promise`\<`void`\>

***

### disburseMaturity()

> **disburseMaturity**(`params`): `Promise`\<`void`\>

Defined in: [packages/sns/src/sns.wrapper.ts:456](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L456)

#### Parameters

##### params

[`SnsNeuronDisburseMaturityParams`](../interfaces/SnsNeuronDisburseMaturityParams.md)

#### Returns

`Promise`\<`void`\>

***

### getDerivedState()

> **getDerivedState**(`params`): `Promise`\<[`SnsGetDerivedStateResponse`](../interfaces/SnsGetDerivedStateResponse.md) \| `undefined`\>

Defined in: [packages/sns/src/sns.wrapper.ts:441](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L441)

#### Parameters

##### params

`Omit`\<`QueryParams`, `"certified"`\>

#### Returns

`Promise`\<[`SnsGetDerivedStateResponse`](../interfaces/SnsGetDerivedStateResponse.md) \| `undefined`\>

***

### getFinalizationStatus()

> **getFinalizationStatus**(`params`): `Promise`\<[`SnsGetAutoFinalizationStatusResponse`](../interfaces/SnsGetAutoFinalizationStatusResponse.md) \| `undefined`\>

Defined in: [packages/sns/src/sns.wrapper.ts:431](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L431)

#### Parameters

##### params

`Omit`\<`QueryParams`, `"certified"`\>

#### Returns

`Promise`\<[`SnsGetAutoFinalizationStatusResponse`](../interfaces/SnsGetAutoFinalizationStatusResponse.md) \| `undefined`\>

***

### getLifecycle()

> **getLifecycle**(`params`): `Promise`\<[`SnsGetLifecycleResponse`](../interfaces/SnsGetLifecycleResponse.md) \| `undefined`\>

Defined in: [packages/sns/src/sns.wrapper.ts:426](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L426)

#### Parameters

##### params

`Omit`\<`QueryParams`, `"certified"`\>

#### Returns

`Promise`\<[`SnsGetLifecycleResponse`](../interfaces/SnsGetLifecycleResponse.md) \| `undefined`\>

***

### getNeuron()

> **getNeuron**(`params`): `Promise`\<[`SnsNeuron`](../interfaces/SnsNeuron.md)\>

Defined in: [packages/sns/src/sns.wrapper.ts:189](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L189)

#### Parameters

##### params

`Omit`\<[`SnsGetNeuronParams`](../interfaces/SnsGetNeuronParams.md), `"certified"`\>

#### Returns

`Promise`\<[`SnsNeuron`](../interfaces/SnsNeuron.md)\>

***

### getNeuronBalance()

> **getNeuronBalance**(`neuronId`): `Promise`\<`bigint`\>

Defined in: [packages/sns/src/sns.wrapper.ts:327](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L327)

#### Parameters

##### neuronId

[`SnsNeuronId`](../interfaces/SnsNeuronId.md)

#### Returns

`Promise`\<`bigint`\>

***

### getOpenTicket()

> **getOpenTicket**(`params`): `Promise`\<[`SnsSwapTicket`](../interfaces/SnsSwapTicket.md) \| `undefined`\>

Defined in: [packages/sns/src/sns.wrapper.ts:417](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L417)

#### Parameters

##### params

`Omit`\<`QueryParams`, `"certified"`\>

#### Returns

`Promise`\<[`SnsSwapTicket`](../interfaces/SnsSwapTicket.md) \| `undefined`\>

***

### getProposal()

> **getProposal**(`params`): `Promise`\<[`SnsProposalData`](../interfaces/SnsProposalData.md)\>

Defined in: [packages/sns/src/sns.wrapper.ts:144](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L144)

#### Parameters

##### params

`Omit`\<[`SnsGetProposalParams`](../interfaces/SnsGetProposalParams.md), `"certified"`\>

#### Returns

`Promise`\<[`SnsProposalData`](../interfaces/SnsProposalData.md)\>

***

### getSaleParameters()

> **getSaleParameters**(`params`): `Promise`\<[`SnsGetSaleParametersResponse`](../interfaces/SnsGetSaleParametersResponse.md) \| `undefined`\>

Defined in: [packages/sns/src/sns.wrapper.ts:436](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L436)

#### Parameters

##### params

`Omit`\<`QueryParams`, `"certified"`\>

#### Returns

`Promise`\<[`SnsGetSaleParametersResponse`](../interfaces/SnsGetSaleParametersResponse.md) \| `undefined`\>

***

### getTransactions()

> **getTransactions**(`params`): `Promise`\<`GetTransactions`\>

Defined in: [packages/sns/src/sns.wrapper.ts:447](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L447)

#### Parameters

##### params

`GetAccountTransactionsParams`

#### Returns

`Promise`\<`GetTransactions`\>

***

### getUserCommitment()

> **getUserCommitment**(`params`): `Promise`\<[`SnsSwapBuyerState`](../interfaces/SnsSwapBuyerState.md) \| `undefined`\>

Defined in: [packages/sns/src/sns.wrapper.ts:412](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L412)

#### Parameters

##### params

[`SnsGetBuyerStateRequest`](../interfaces/SnsGetBuyerStateRequest.md)

#### Returns

`Promise`\<[`SnsSwapBuyerState`](../interfaces/SnsSwapBuyerState.md) \| `undefined`\>

***

### increaseDissolveDelay()

> **increaseDissolveDelay**(`params`): `Promise`\<`void`\>

Defined in: [packages/sns/src/sns.wrapper.ts:374](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L374)

#### Parameters

##### params

[`SnsIncreaseDissolveDelayParams`](../interfaces/SnsIncreaseDissolveDelayParams.md)

#### Returns

`Promise`\<`void`\>

***

### increaseStakeNeuron()

> **increaseStakeNeuron**(`params`): `Promise`\<`void`\>

Defined in: [packages/sns/src/sns.wrapper.ts:308](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L308)

Increase the stake of a neuron.

This is a convenient method that transfers the stake to the neuron subaccount and then refresh the neuron.

⚠️ This feature is provided as it without warranty. It does not implement any additional checks of the validity of the payment flow - e.g. it does not handle refund nor calls refresh again in case of errors.

#### Parameters

##### params

[`SnsIncreaseStakeNeuronParams`](../interfaces/SnsIncreaseStakeNeuronParams.md)

#### Returns

`Promise`\<`void`\>

***

### ledgerMetadata()

> **ledgerMetadata**(`params`): `Promise`\<`IcrcTokenMetadataResponse`\>

Defined in: [packages/sns/src/sns.wrapper.ts:167](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L167)

#### Parameters

##### params

`Omit`\<`QueryParams`, `"certified"`\>

#### Returns

`Promise`\<`IcrcTokenMetadataResponse`\>

***

### listNervousSystemFunctions()

> **listNervousSystemFunctions**(`params`): `Promise`\<[`SnsListNervousSystemFunctionsResponse`](../interfaces/SnsListNervousSystemFunctionsResponse.md)\>

Defined in: [packages/sns/src/sns.wrapper.ts:149](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L149)

#### Parameters

##### params

`Omit`\<`QueryParams`, `"certified"`\>

#### Returns

`Promise`\<[`SnsListNervousSystemFunctionsResponse`](../interfaces/SnsListNervousSystemFunctionsResponse.md)\>

***

### listNeurons()

> **listNeurons**(`params`): `Promise`\<[`SnsNeuron`](../interfaces/SnsNeuron.md)[]\>

Defined in: [packages/sns/src/sns.wrapper.ts:135](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L135)

#### Parameters

##### params

`Omit`\<[`SnsListNeuronsParams`](../interfaces/SnsListNeuronsParams.md), `"certified"`\>

#### Returns

`Promise`\<[`SnsNeuron`](../interfaces/SnsNeuron.md)[]\>

***

### listProposals()

> **listProposals**(`params`): `Promise`\<[`SnsListProposalsResponse`](../interfaces/SnsListProposalsResponse.md)\>

Defined in: [packages/sns/src/sns.wrapper.ts:139](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L139)

#### Parameters

##### params

`Omit`\<[`SnsListProposalsParams`](../interfaces/SnsListProposalsParams.md), `"certified"`\>

#### Returns

`Promise`\<[`SnsListProposalsResponse`](../interfaces/SnsListProposalsResponse.md)\>

***

### metadata()

> **metadata**(`params`): `Promise`\<\[[`SnsGetMetadataResponse`](../interfaces/SnsGetMetadataResponse.md), `IcrcTokenMetadataResponse`\]\>

Defined in: [packages/sns/src/sns.wrapper.ts:154](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L154)

#### Parameters

##### params

`Omit`\<`QueryParams`, `"certified"`\>

#### Returns

`Promise`\<\[[`SnsGetMetadataResponse`](../interfaces/SnsGetMetadataResponse.md), `IcrcTokenMetadataResponse`\]\>

***

### nervousSystemParameters()

> **nervousSystemParameters**(`params`): `Promise`\<[`SnsNervousSystemParameters`](../interfaces/SnsNervousSystemParameters.md)\>

Defined in: [packages/sns/src/sns.wrapper.ts:162](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L162)

#### Parameters

##### params

`Omit`\<`QueryParams`, `"certified"`\>

#### Returns

`Promise`\<[`SnsNervousSystemParameters`](../interfaces/SnsNervousSystemParameters.md)\>

***

### newSaleTicket()

> **newSaleTicket**(`params`): `Promise`\<[`SnsSwapTicket`](../interfaces/SnsSwapTicket.md)\>

Defined in: [packages/sns/src/sns.wrapper.ts:423](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L423)

#### Parameters

##### params

`NewSaleTicketParams`

#### Returns

`Promise`\<[`SnsSwapTicket`](../interfaces/SnsSwapTicket.md)\>

***

### nextNeuronAccount()

> **nextNeuronAccount**(`controller`): `Promise`\<\{ `account`: `IcrcAccount`; `index`: `bigint`; \}\>

Defined in: [packages/sns/src/sns.wrapper.ts:214](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L214)

Returns the subaccount of the next neuron to be created.

The neuron account is a subaccount of the governance canister.
The subaccount is derived from the controller and an ascending index.

‼️ The id of the neuron is the subaccount (neuron ID = subaccount) ‼️.

If the neuron does not exist for that subaccount, then we use it for the next neuron.

The index is used in the memo of the transfer and when claiming the neuron.
This is how the backend can identify which neuron is being claimed.

#### Parameters

##### controller

`Principal`

#### Returns

`Promise`\<\{ `account`: `IcrcAccount`; `index`: `bigint`; \}\>

***

### notifyParticipation()

> **notifyParticipation**(`params`): `Promise`\<[`SnsRefreshBuyerTokensResponse`](../interfaces/SnsRefreshBuyerTokensResponse.md)\>

Defined in: [packages/sns/src/sns.wrapper.ts:407](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L407)

#### Parameters

##### params

`RefreshBuyerTokensRequest`

#### Returns

`Promise`\<[`SnsRefreshBuyerTokensResponse`](../interfaces/SnsRefreshBuyerTokensResponse.md)\>

***

### notifyPaymentFailure()

> **notifyPaymentFailure**(): `Promise`\<[`SnsSwapTicket`](../interfaces/SnsSwapTicket.md) \| `undefined`\>

Defined in: [packages/sns/src/sns.wrapper.ts:403](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L403)

Returns the ticket if a ticket was found for the caller and the ticket
was removed successfully. Returns None if no ticket was found for the caller.
Only the owner of a ticket can remove it.

Always certified

#### Returns

`Promise`\<[`SnsSwapTicket`](../interfaces/SnsSwapTicket.md) \| `undefined`\>

***

### queryNeuron()

> **queryNeuron**(`params`): `Promise`\<[`SnsNeuron`](../interfaces/SnsNeuron.md) \| `undefined`\>

Defined in: [packages/sns/src/sns.wrapper.ts:193](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L193)

#### Parameters

##### params

`Omit`\<[`SnsGetNeuronParams`](../interfaces/SnsGetNeuronParams.md), `"certified"`\>

#### Returns

`Promise`\<[`SnsNeuron`](../interfaces/SnsNeuron.md) \| `undefined`\>

***

### refreshNeuron()

> **refreshNeuron**(`neuronId`): `Promise`\<`void`\>

Defined in: [packages/sns/src/sns.wrapper.ts:340](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L340)

#### Parameters

##### neuronId

[`SnsNeuronId`](../interfaces/SnsNeuronId.md)

#### Returns

`Promise`\<`void`\>

***

### registerVote()

> **registerVote**(`params`): `Promise`\<`void`\>

Defined in: [packages/sns/src/sns.wrapper.ts:387](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L387)

#### Parameters

##### params

[`SnsRegisterVoteParams`](../interfaces/SnsRegisterVoteParams.md)

#### Returns

`Promise`\<`void`\>

***

### removeNeuronPermissions()

> **removeNeuronPermissions**(`params`): `Promise`\<`void`\>

Defined in: [packages/sns/src/sns.wrapper.ts:348](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L348)

#### Parameters

##### params

[`SnsNeuronPermissionsParams`](../interfaces/SnsNeuronPermissionsParams.md)

#### Returns

`Promise`\<`void`\>

***

### setDissolveTimestamp()

> **setDissolveTimestamp**(`params`): `Promise`\<`void`\>

Defined in: [packages/sns/src/sns.wrapper.ts:369](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L369)

#### Parameters

##### params

[`SnsSetDissolveTimestampParams`](../interfaces/SnsSetDissolveTimestampParams.md)

#### Returns

`Promise`\<`void`\>

***

### setFollowing()

> **setFollowing**(`params`): `Promise`\<`void`\>

Defined in: [packages/sns/src/sns.wrapper.ts:383](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L383)

#### Parameters

##### params

[`SnsSetFollowingParams`](../interfaces/SnsSetFollowingParams.md)

#### Returns

`Promise`\<`void`\>

***

### setTopicFollowees()

> **setTopicFollowees**(`params`): `Promise`\<`void`\>

Defined in: [packages/sns/src/sns.wrapper.ts:379](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L379)

#### Parameters

##### params

[`SnsSetTopicFollowees`](../interfaces/SnsSetTopicFollowees.md)

#### Returns

`Promise`\<`void`\>

***

### splitNeuron()

> **splitNeuron**(`params`): `Promise`\<[`SnsNeuronId`](../interfaces/SnsNeuronId.md) \| `undefined`\>

Defined in: [packages/sns/src/sns.wrapper.ts:353](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L353)

#### Parameters

##### params

[`SnsSplitNeuronParams`](../interfaces/SnsSplitNeuronParams.md)

#### Returns

`Promise`\<[`SnsNeuronId`](../interfaces/SnsNeuronId.md) \| `undefined`\>

***

### stakeMaturity()

> **stakeMaturity**(`params`): `Promise`\<`void`\>

Defined in: [packages/sns/src/sns.wrapper.ts:452](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L452)

#### Parameters

##### params

[`SnsNeuronStakeMaturityParams`](../interfaces/SnsNeuronStakeMaturityParams.md)

#### Returns

`Promise`\<`void`\>

***

### stakeNeuron()

> **stakeNeuron**(`params`): `Promise`\<[`SnsNeuronId`](../interfaces/SnsNeuronId.md)\>

Defined in: [packages/sns/src/sns.wrapper.ts:261](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L261)

Stakes a neuron.

This is a convenient method that transfers the stake to the neuron subaccount and then claims the neuron.

⚠️ This feature is provided as it without warranty. It does not implement any additional checks of the validity of the payment flow - e.g. it does not handle refund nor retries claiming the neuron in case of errors.

#### Parameters

##### params

[`SnsStakeNeuronParams`](../interfaces/SnsStakeNeuronParams.md)

#### Returns

`Promise`\<[`SnsNeuronId`](../interfaces/SnsNeuronId.md)\>

***

### startDissolving()

> **startDissolving**(`neuronId`): `Promise`\<`void`\>

Defined in: [packages/sns/src/sns.wrapper.ts:361](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L361)

#### Parameters

##### neuronId

[`SnsNeuronId`](../interfaces/SnsNeuronId.md)

#### Returns

`Promise`\<`void`\>

***

### stopDissolving()

> **stopDissolving**(`neuronId`): `Promise`\<`void`\>

Defined in: [packages/sns/src/sns.wrapper.ts:365](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L365)

#### Parameters

##### neuronId

[`SnsNeuronId`](../interfaces/SnsNeuronId.md)

#### Returns

`Promise`\<`void`\>

***

### swapState()

> **swapState**(`params`): `Promise`\<`GetStateResponse`\>

Defined in: [packages/sns/src/sns.wrapper.ts:390](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L390)

#### Parameters

##### params

`Omit`\<`QueryParams`, `"certified"`\>

#### Returns

`Promise`\<`GetStateResponse`\>

***

### totalTokensSupply()

> **totalTokensSupply**(`params`): `Promise`\<`bigint`\>

Defined in: [packages/sns/src/sns.wrapper.ts:177](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L177)

#### Parameters

##### params

`Omit`\<`QueryParams`, `"certified"`\>

#### Returns

`Promise`\<`bigint`\>

***

### transactionFee()

> **transactionFee**(`params`): `Promise`\<`bigint`\>

Defined in: [packages/sns/src/sns.wrapper.ts:172](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L172)

#### Parameters

##### params

`Omit`\<`QueryParams`, `"certified"`\>

#### Returns

`Promise`\<`bigint`\>

***

### transfer()

> **transfer**(`params`): `Promise`\<`bigint`\>

Defined in: [packages/sns/src/sns.wrapper.ts:186](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.wrapper.ts#L186)

#### Parameters

##### params

`TransferParams`

#### Returns

`Promise`\<`bigint`\>
