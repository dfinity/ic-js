---
title: SnsRootCanister
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/root.canister.ts:10](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/root.canister.ts#L10)

## Extends

- `Canister`\<`SnsRootService`\>

## Constructors

### Constructor

> `protected` **new SnsRootCanister**(`id`, `service`, `certifiedService`): `SnsRootCanister`

Defined in: packages/utils/dist/services/canister.d.ts:7

#### Parameters

##### id

`Principal`

##### service

`_SERVICE`

##### certifiedService

`_SERVICE`

#### Returns

`SnsRootCanister`

#### Inherited from

`Canister<SnsRootService>.constructor`

## Properties

### caller()

> `protected` **caller**: (`__namedParameters`) => `_SERVICE`

Defined in: packages/utils/dist/services/canister.d.ts:9

#### Parameters

##### \_\_namedParameters

`QueryParams`

#### Returns

`_SERVICE`

#### Inherited from

`Canister.caller`

***

### certifiedService

> `protected` `readonly` **certifiedService**: `_SERVICE`

Defined in: packages/utils/dist/services/canister.d.ts:6

#### Inherited from

`Canister.certifiedService`

***

### service

> `protected` `readonly` **service**: `_SERVICE`

Defined in: packages/utils/dist/services/canister.d.ts:5

#### Inherited from

`Canister.service`

## Accessors

### canisterId

#### Get Signature

> **get** **canisterId**(): `Principal`

Defined in: packages/utils/dist/services/canister.d.ts:8

##### Returns

`Principal`

#### Inherited from

`Canister.canisterId`

## Methods

### listSnsCanisters()

> **listSnsCanisters**(`params`): `Promise`\<`ListSnsCanistersResponse`\>

Defined in: [packages/sns/src/root.canister.ts:32](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/root.canister.ts#L32)

List the canisters that are part of the Sns.

Source code: https://github.com/dfinity/ic/blob/master/rs/sns/root/src/lib.rs

#### Parameters

##### params

###### certified?

`boolean` = `true`

Query or update calls

#### Returns

`Promise`\<`ListSnsCanistersResponse`\>

- A list of canisters ('root' | 'governance' | 'ledger' | 'dapps' | 'swap' | 'archives')

***

### create()

> `static` **create**(`options`): `SnsRootCanister`

Defined in: [packages/sns/src/root.canister.ts:11](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/sns/src/root.canister.ts#L11)

#### Parameters

##### options

[`SnsCanisterOptions`](../interfaces/SnsCanisterOptions.md)\<`_SERVICE`\>

#### Returns

`SnsRootCanister`
