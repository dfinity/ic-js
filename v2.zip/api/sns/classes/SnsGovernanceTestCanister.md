---
title: SnsGovernanceTestCanister
editUrl: false
next: true
prev: true
---

Defined in: [packages/sns/src/governance\_test.canister.ts:18](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/governance_test.canister.ts#L18)

## Extends

- `Canister`\<`SnsGovernanceTestService`\>

## Constructors

### Constructor

> `protected` **new SnsGovernanceTestCanister**(`id`, `service`, `certifiedService`): `SnsGovernanceTestCanister`

Defined in: packages/utils/dist/services/canister.d.ts:7

#### Parameters

##### id

`Principal`

##### service

`_SERVICE`

##### certifiedService

`_SERVICE`

#### Returns

`SnsGovernanceTestCanister`

#### Inherited from

`Canister<SnsGovernanceTestService>.constructor`

## Properties

### caller()

> `protected` **caller**: (`__namedParameters`) => `_SERVICE`

Defined in: packages/utils/dist/services/canister.d.ts:9

#### Parameters

##### \_\_namedParameters

`QueryParams`

#### Returns

`_SERVICE`

#### Inherited from

`Canister.caller`

***

### certifiedService

> `protected` `readonly` **certifiedService**: `_SERVICE`

Defined in: packages/utils/dist/services/canister.d.ts:6

#### Inherited from

`Canister.certifiedService`

***

### service

> `protected` `readonly` **service**: `_SERVICE`

Defined in: packages/utils/dist/services/canister.d.ts:5

#### Inherited from

`Canister.service`

## Accessors

### canisterId

#### Get Signature

> **get** **canisterId**(): `Principal`

Defined in: packages/utils/dist/services/canister.d.ts:8

##### Returns

`Principal`

#### Inherited from

`Canister.canisterId`

## Methods

### addMaturity()

> **addMaturity**(`params`): `Promise`\<`void`\>

Defined in: [packages/sns/src/governance\_test.canister.ts:38](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/governance_test.canister.ts#L38)

Add maturity to a neuron (only for testing purposes. Testnet only.)

#### Parameters

##### params

`SnsAddMaturityParams`

#### Returns

`Promise`\<`void`\>

***

### create()

> `static` **create**(`options`): `SnsGovernanceTestCanister`

Defined in: [packages/sns/src/governance\_test.canister.ts:24](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/sns/src/governance_test.canister.ts#L24)

Instantiate a canister to interact with the governance of a Sns project.

#### Parameters

##### options

[`SnsCanisterOptions`](../interfaces/SnsCanisterOptions.md)\<`_SERVICE`\>

Miscellaneous options to initialize the canister. Its ID being the only mandatory parammeter.

#### Returns

`SnsGovernanceTestCanister`
