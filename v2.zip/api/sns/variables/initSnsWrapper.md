---
title: initSnsWrapper
editUrl: false
next: true
prev: true
---

> `const` **initSnsWrapper**: [`InitSnsWrapper`](../interfaces/InitSnsWrapper.md)

Defined in: [packages/sns/src/sns.ts:36](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/sns/src/sns.ts#L36)

Lookup for the canister ids of a Sns and initialize the wrapper to access its features.
