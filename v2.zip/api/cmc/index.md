---
title: Overview
editUrl: false
next: true
prev: true
---

## Classes

- [CMCCanister](classes/CMCCanister.md)
- [CMCError](classes/CMCError.md)
- [InvalidaTransactionError](classes/InvalidaTransactionError.md)
- [ProcessingError](classes/ProcessingError.md)
- [RefundedError](classes/RefundedError.md)
- [TransactionTooOldError](classes/TransactionTooOldError.md)

## Interfaces

- [NotifyCreateCanisterArg](interfaces/NotifyCreateCanisterArg.md)
- [NotifyTopUpArg](interfaces/NotifyTopUpArg.md)
- [SubnetTypesToSubnetsResponse](interfaces/SubnetTypesToSubnetsResponse.md)

## Type Aliases

- [Cycles](type-aliases/Cycles.md)

## Functions

- [throwNotifyError](functions/throwNotifyError.md)
