---
title: throwNotifyError
editUrl: false
next: true
prev: true
---

> **throwNotifyError**(`__namedParameters`): `void`

Defined in: [packages/cmc/src/cmc.errors.ts:11](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cmc/src/cmc.errors.ts#L11)

## Parameters

### \_\_namedParameters

#### Err

`NotifyError`

## Returns

`void`
