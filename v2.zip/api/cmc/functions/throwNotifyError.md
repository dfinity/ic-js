---
title: throwNotifyError
editUrl: false
next: true
prev: true
---

> **throwNotifyError**(`__namedParameters`): `void`

Defined in: [packages/cmc/src/cmc.errors.ts:11](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/cmc/src/cmc.errors.ts#L11)

## Parameters

### \_\_namedParameters

#### Err

`NotifyError`

## Returns

`void`
