---
title: SubnetTypesToSubnetsResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/cmc/src/candid/cmc.d.ts:287](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cmc/src/candid/cmc.d.ts#L287)

## Properties

### data

> **data**: \[`string`, `Principal`[]\][]

Defined in: [packages/cmc/src/candid/cmc.d.ts:288](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cmc/src/candid/cmc.d.ts#L288)
