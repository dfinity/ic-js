---
title: SubnetTypesToSubnetsResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/cmc/src/candid/cmc.d.ts:287](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/cmc/src/candid/cmc.d.ts#L287)

## Properties

### data

> **data**: \[`string`, `Principal`[]\][]

Defined in: [packages/cmc/src/candid/cmc.d.ts:288](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/cmc/src/candid/cmc.d.ts#L288)
