---
title: NeuronId
editUrl: false
next: true
prev: true
---

> **NeuronId** = `bigint`

Defined in: [packages/nns/src/types/common.ts:2](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/common.ts#L2)
