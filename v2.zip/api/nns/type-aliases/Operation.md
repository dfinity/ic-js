---
title: Operation
editUrl: false
next: true
prev: true
---

> **Operation** = \{ `RemoveHotKey`: [`RemoveHotKey`](../interfaces/RemoveHotKey.md); \} \| \{ `AddHotKey`: [`AddHotKey`](../interfaces/AddHotKey.md); \} \| \{ `StopDissolving`: `Record`\<`string`, `never`\>; \} \| \{ `StartDissolving`: `Record`\<`string`, `never`\>; \} \| \{ `IncreaseDissolveDelay`: [`IncreaseDissolveDelay`](../interfaces/IncreaseDissolveDelay.md); \} \| \{ `JoinCommunityFund`: `Record`\<`string`, `never`\>; \} \| \{ `LeaveCommunityFund`: `Record`\<`string`, `never`\>; \} \| \{ `SetDissolveTimestamp`: [`SetDissolveTimestamp`](../interfaces/SetDissolveTimestamp.md); \} \| \{ `ChangeAutoStakeMaturity`: [`ChangeAutoStakeMaturity`](../interfaces/ChangeAutoStakeMaturity.md); \} \| \{ `SetVisibility`: [`SetVisibility`](../interfaces/SetVisibility.md); \}

Defined in: [packages/nns/src/types/governance\_converters.ts:458](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L458)
