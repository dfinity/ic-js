---
title: AuthzChangeOp
editUrl: false
next: true
prev: true
---

> **AuthzChangeOp** = \{ `Authorize`: \{ `addSelf`: `boolean`; \}; \} \| \{ `Deauthorize`: `null`; \}

Defined in: [packages/nns/src/types/governance\_converters.ts:72](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L72)
