---
title: Memo
editUrl: false
next: true
prev: true
---

> **Memo** = `bigint`

Defined in: [packages/nns/src/types/common.ts:4](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/common.ts#L4)
