---
title: RewardMode
editUrl: false
next: true
prev: true
---

> **RewardMode** = \{ `RewardToNeuron`: [`RewardToNeuron`](../interfaces/RewardToNeuron.md); \} \| \{ `RewardToAccount`: [`RewardToAccount`](../interfaces/RewardToAccount.md); \}

Defined in: [packages/nns/src/types/governance\_converters.ts:503](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L503)
