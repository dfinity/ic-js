---
title: Change
editUrl: false
next: true
prev: true
---

> **Change** = \{ `ToRemove`: [`NodeProvider`](../interfaces/NodeProvider.md); \} \| \{ `ToAdd`: [`NodeProvider`](../interfaces/NodeProvider.md); \}

Defined in: [packages/nns/src/types/governance\_converters.ts:91](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L91)
