---
title: GovernanceTestCanister
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/governance\_test.canister.ts:17](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/governance_test.canister.ts#L17)

## Methods

### updateNeuron()

> **updateNeuron**(`neuron`): `Promise`\<\[\] \| \[`GovernanceError`\]\>

Defined in: [packages/nns/src/governance\_test.canister.ts:47](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/governance_test.canister.ts#L47)

Test method to update fields of a neuron.

Only available in the governance test canister.

#### Parameters

##### neuron

[`Neuron`](../interfaces/Neuron.md)

#### Returns

`Promise`\<\[\] \| \[`GovernanceError`\]\>

***

### create()

> `static` **create**(`options`): `GovernanceTestCanister`

Defined in: [packages/nns/src/governance\_test.canister.ts:26](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/governance_test.canister.ts#L26)

#### Parameters

##### options

`CanisterOptions`\<`_SERVICE`\> = `{}`

#### Returns

`GovernanceTestCanister`
