---
title: CanisterInstallMode
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/enums/governance.enums.ts:189](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L189)

## Enumeration Members

### Install

> **Install**: `1`

Defined in: [packages/nns/src/enums/governance.enums.ts:191](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L191)

***

### Reinstall

> **Reinstall**: `2`

Defined in: [packages/nns/src/enums/governance.enums.ts:192](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L192)

***

### Unspecified

> **Unspecified**: `0`

Defined in: [packages/nns/src/enums/governance.enums.ts:190](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L190)

***

### Upgrade

> **Upgrade**: `3`

Defined in: [packages/nns/src/enums/governance.enums.ts:193](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L193)
