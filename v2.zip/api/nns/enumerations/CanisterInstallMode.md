---
title: CanisterInstallMode
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/enums/governance.enums.ts:189](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/enums/governance.enums.ts#L189)

## Enumeration Members

### Install

> **Install**: `1`

Defined in: [packages/nns/src/enums/governance.enums.ts:191](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/enums/governance.enums.ts#L191)

***

### Reinstall

> **Reinstall**: `2`

Defined in: [packages/nns/src/enums/governance.enums.ts:192](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/enums/governance.enums.ts#L192)

***

### Unspecified

> **Unspecified**: `0`

Defined in: [packages/nns/src/enums/governance.enums.ts:190](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/enums/governance.enums.ts#L190)

***

### Upgrade

> **Upgrade**: `3`

Defined in: [packages/nns/src/enums/governance.enums.ts:193](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/enums/governance.enums.ts#L193)
