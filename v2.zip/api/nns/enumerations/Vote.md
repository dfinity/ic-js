---
title: Vote
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/enums/governance.enums.ts:82](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L82)

## Enumeration Members

### No

> **No**: `2`

Defined in: [packages/nns/src/enums/governance.enums.ts:85](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L85)

***

### Unspecified

> **Unspecified**: `0`

Defined in: [packages/nns/src/enums/governance.enums.ts:83](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L83)

***

### Yes

> **Yes**: `1`

Defined in: [packages/nns/src/enums/governance.enums.ts:84](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L84)
