---
title: LogVisibility
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/enums/governance.enums.ts:164](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L164)

## Enumeration Members

### Controllers

> **Controllers**: `1`

Defined in: [packages/nns/src/enums/governance.enums.ts:167](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L167)

***

### Public

> **Public**: `2`

Defined in: [packages/nns/src/enums/governance.enums.ts:169](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L169)

***

### Unspecified

> **Unspecified**: `0`

Defined in: [packages/nns/src/enums/governance.enums.ts:165](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L165)
