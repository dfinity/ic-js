---
title: LogVisibility
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/enums/governance.enums.ts:164](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L164)

## Enumeration Members

### Controllers

> **Controllers**: `1`

Defined in: [packages/nns/src/enums/governance.enums.ts:167](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L167)

***

### Public

> **Public**: `2`

Defined in: [packages/nns/src/enums/governance.enums.ts:169](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L169)

***

### Unspecified

> **Unspecified**: `0`

Defined in: [packages/nns/src/enums/governance.enums.ts:165](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L165)
