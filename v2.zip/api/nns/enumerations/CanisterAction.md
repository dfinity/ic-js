---
title: CanisterAction
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/enums/governance.enums.ts:173](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L173)

## Enumeration Members

### Start

> **Start**: `2`

Defined in: [packages/nns/src/enums/governance.enums.ts:178](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L178)

***

### Stop

> **Stop**: `1`

Defined in: [packages/nns/src/enums/governance.enums.ts:176](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L176)

***

### Unspecified

> **Unspecified**: `0`

Defined in: [packages/nns/src/enums/governance.enums.ts:174](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/enums/governance.enums.ts#L174)
