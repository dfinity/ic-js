---
title: CanisterAction
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/enums/governance.enums.ts:173](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/enums/governance.enums.ts#L173)

## Enumeration Members

### Start

> **Start**: `2`

Defined in: [packages/nns/src/enums/governance.enums.ts:178](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/enums/governance.enums.ts#L178)

***

### Stop

> **Stop**: `1`

Defined in: [packages/nns/src/enums/governance.enums.ts:176](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/enums/governance.enums.ts#L176)

***

### Unspecified

> **Unspecified**: `0`

Defined in: [packages/nns/src/enums/governance.enums.ts:174](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/enums/governance.enums.ts#L174)
