---
title: CanisterAction
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/enums/governance.enums.ts:173](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L173)

## Enumeration Members

### Start

> **Start**: `2`

Defined in: [packages/nns/src/enums/governance.enums.ts:178](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L178)

***

### Stop

> **Stop**: `1`

Defined in: [packages/nns/src/enums/governance.enums.ts:176](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L176)

***

### Unspecified

> **Unspecified**: `0`

Defined in: [packages/nns/src/enums/governance.enums.ts:174](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L174)
