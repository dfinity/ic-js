---
title: ProposalRewardStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/enums/governance.enums.ts:42](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L42)

## Enumeration Members

### AcceptVotes

> **AcceptVotes**: `1`

Defined in: [packages/nns/src/enums/governance.enums.ts:47](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L47)

***

### Ineligible

> **Ineligible**: `4`

Defined in: [packages/nns/src/enums/governance.enums.ts:57](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L57)

***

### ReadyToSettle

> **ReadyToSettle**: `2`

Defined in: [packages/nns/src/enums/governance.enums.ts:51](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L51)

***

### Settled

> **Settled**: `3`

Defined in: [packages/nns/src/enums/governance.enums.ts:54](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L54)

***

### Unknown

> **Unknown**: `0`

Defined in: [packages/nns/src/enums/governance.enums.ts:43](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L43)
