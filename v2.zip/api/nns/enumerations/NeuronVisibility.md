---
title: NeuronVisibility
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/enums/governance.enums.ts:182](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/enums/governance.enums.ts#L182)

## Enumeration Members

### Private

> **Private**: `1`

Defined in: [packages/nns/src/enums/governance.enums.ts:184](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/enums/governance.enums.ts#L184)

***

### Public

> **Public**: `2`

Defined in: [packages/nns/src/enums/governance.enums.ts:185](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/enums/governance.enums.ts#L185)

***

### Unspecified

> **Unspecified**: `0`

Defined in: [packages/nns/src/enums/governance.enums.ts:183](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/enums/governance.enums.ts#L183)
