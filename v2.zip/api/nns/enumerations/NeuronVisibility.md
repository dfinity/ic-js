---
title: NeuronVisibility
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/enums/governance.enums.ts:182](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L182)

## Enumeration Members

### Private

> **Private**: `1`

Defined in: [packages/nns/src/enums/governance.enums.ts:184](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L184)

***

### Public

> **Public**: `2`

Defined in: [packages/nns/src/enums/governance.enums.ts:185](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L185)

***

### Unspecified

> **Unspecified**: `0`

Defined in: [packages/nns/src/enums/governance.enums.ts:183](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/enums/governance.enums.ts#L183)
