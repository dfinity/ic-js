---
title: SetDissolveTimestamp
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:210](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L210)

## Properties

### dissolveTimestampSeconds

> **dissolveTimestampSeconds**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:211](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L211)
