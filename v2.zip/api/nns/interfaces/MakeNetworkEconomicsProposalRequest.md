---
title: MakeNetworkEconomicsProposalRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:628](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L628)

## Properties

### networkEconomics

> **networkEconomics**: [`NetworkEconomics`](NetworkEconomics.md)

Defined in: [packages/nns/src/types/governance\_converters.ts:633](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L633)

***

### neuronId

> **neuronId**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:629](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L629)

***

### summary

> **summary**: `string`

Defined in: [packages/nns/src/types/governance\_converters.ts:631](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L631)

***

### title

> **title**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:630](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L630)

***

### url

> **url**: `string`

Defined in: [packages/nns/src/types/governance\_converters.ts:632](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L632)
