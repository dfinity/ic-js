---
title: ListProposalsRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:219](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L219)

## Properties

### beforeProposal

> **beforeProposal**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:228](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L228)

***

### excludeTopic

> **excludeTopic**: [`Topic`](../enumerations/Topic.md)[]

Defined in: [packages/nns/src/types/governance\_converters.ts:242](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L242)

***

### includeAllManageNeuronProposals

> **includeAllManageNeuronProposals**: `boolean`

Defined in: [packages/nns/src/types/governance\_converters.ts:247](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L247)

***

### includeRewardStatus

> **includeRewardStatus**: [`ProposalRewardStatus`](../enumerations/ProposalRewardStatus.md)[]

Defined in: [packages/nns/src/types/governance\_converters.ts:236](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L236)

***

### includeStatus

> **includeStatus**: [`ProposalStatus`](../enumerations/ProposalStatus.md)[]

Defined in: [packages/nns/src/types/governance\_converters.ts:252](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L252)

***

### limit

> **limit**: `number`

Defined in: [packages/nns/src/types/governance\_converters.ts:223](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L223)

***

### omitLargeFields?

> `optional` **omitLargeFields**: `boolean`

Defined in: [packages/nns/src/types/governance\_converters.ts:258](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L258)
