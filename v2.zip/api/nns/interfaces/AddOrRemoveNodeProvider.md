---
title: AddOrRemoveNodeProvider
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:66](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L66)

## Properties

### change

> **change**: [`Option`](../type-aliases/Option.md)\<[`Change`](../type-aliases/Change.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:67](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L67)
