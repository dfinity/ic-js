---
title: ExecuteNnsFunction
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:166](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L166)

## Properties

### nnsFunctionId

> **nnsFunctionId**: `number`

Defined in: [packages/nns/src/types/governance\_converters.ts:167](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L167)

***

### payloadBytes?

> `optional` **payloadBytes**: `ArrayBuffer`

Defined in: [packages/nns/src/types/governance\_converters.ts:168](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L168)
