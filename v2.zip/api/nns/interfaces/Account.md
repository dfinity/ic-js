---
title: Account
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:179](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L179)

## Properties

### owner

> **owner**: [`Option`](../type-aliases/Option.md)\<`Principal`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:180](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L180)

***

### subaccount

> **subaccount**: [`Option`](../type-aliases/Option.md)\<`number`[]\>

Defined in: [packages/nns/src/types/governance\_converters.ts:181](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L181)
