---
title: InstallCode
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:276](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L276)

## Properties

### argHash

> **argHash**: `string`

Defined in: [packages/nns/src/types/governance\_converters.ts:277](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L277)

***

### canisterId

> **canisterId**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:280](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L280)

***

### installMode

> **installMode**: [`Option`](../type-aliases/Option.md)\<[`CanisterInstallMode`](../enumerations/CanisterInstallMode.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:281](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L281)

***

### skipStoppingBeforeInstalling

> **skipStoppingBeforeInstalling**: [`Option`](../type-aliases/Option.md)\<`boolean`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:279](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L279)

***

### wasmModuleHash

> **wasmModuleHash**: `string`

Defined in: [packages/nns/src/types/governance\_converters.ts:278](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L278)
