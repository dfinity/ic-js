---
title: StakeMaturity
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:319](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L319)

## Properties

### percentageToStake

> **percentageToStake**: [`Option`](../type-aliases/Option.md)\<`number`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:320](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L320)
