---
title: NeuronSubsetMetrics
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:773](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L773)

## Properties

### count

> **count**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:778](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L778)

***

### countBuckets

> **countBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/nns/src/types/governance\_converters.ts:787](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L787)

***

### decidingVotingPowerBuckets

> **decidingVotingPowerBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/nns/src/types/governance\_converters.ts:779](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L779)

***

### maturityE8sEquivalentBuckets

> **maturityE8sEquivalentBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/nns/src/types/governance\_converters.ts:775](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L775)

***

### potentialVotingPowerBuckets

> **potentialVotingPowerBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/nns/src/types/governance\_converters.ts:786](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L786)

***

### stakedE8sBuckets

> **stakedE8sBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/nns/src/types/governance\_converters.ts:784](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L784)

***

### stakedMaturityE8sEquivalentBuckets

> **stakedMaturityE8sEquivalentBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/nns/src/types/governance\_converters.ts:783](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L783)

***

### totalDecidingVotingPower

> **totalDecidingVotingPower**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:782](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L782)

***

### totalMaturityE8sEquivalent

> **totalMaturityE8sEquivalent**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:774](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L774)

***

### totalPotentialVotingPower

> **totalPotentialVotingPower**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:781](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L781)

***

### totalStakedE8s

> **totalStakedE8s**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:777](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L777)

***

### totalStakedMaturityE8sEquivalent

> **totalStakedMaturityE8sEquivalent**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:780](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L780)

***

### totalVotingPower

> **totalVotingPower**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:785](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L785)

***

### votingPowerBuckets

> **votingPowerBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/nns/src/types/governance\_converters.ts:776](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L776)
