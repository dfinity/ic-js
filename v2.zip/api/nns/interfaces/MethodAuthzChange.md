---
title: MethodAuthzChange
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:333](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L333)

## Properties

### canister

> **canister**: `string`

Defined in: [packages/nns/src/types/governance\_converters.ts:336](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L336)

***

### methodName

> **methodName**: `string`

Defined in: [packages/nns/src/types/governance\_converters.ts:335](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L335)

***

### operation

> **operation**: [`AuthzChangeOp`](../type-aliases/AuthzChangeOp.md)

Defined in: [packages/nns/src/types/governance\_converters.ts:337](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L337)

***

### principal

> **principal**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:334](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L334)
