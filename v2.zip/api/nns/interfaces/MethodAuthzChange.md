---
title: MethodAuthzChange
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:333](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L333)

## Properties

### canister

> **canister**: `string`

Defined in: [packages/nns/src/types/governance\_converters.ts:336](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L336)

***

### methodName

> **methodName**: `string`

Defined in: [packages/nns/src/types/governance\_converters.ts:335](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L335)

***

### operation

> **operation**: [`AuthzChangeOp`](../type-aliases/AuthzChangeOp.md)

Defined in: [packages/nns/src/types/governance\_converters.ts:337](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L337)

***

### principal

> **principal**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:334](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L334)
