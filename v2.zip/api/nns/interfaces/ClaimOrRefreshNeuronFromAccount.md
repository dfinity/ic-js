---
title: ClaimOrRefreshNeuronFromAccount
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:95](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L95)

## Properties

### controller

> **controller**: [`Option`](../type-aliases/Option.md)\<`Principal`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:96](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L96)

***

### memo

> **memo**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:97](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L97)
