---
title: LedgerParameters
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:691](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L691)

## Properties

### tokenLogo

> **tokenLogo**: [`Option`](../type-aliases/Option.md)\<[`Image`](Image.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:694](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L694)

***

### tokenName

> **tokenName**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:695](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L695)

***

### tokenSymbol

> **tokenSymbol**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:693](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L693)

***

### transactionFee

> **transactionFee**: [`Option`](../type-aliases/Option.md)\<[`Tokens`](Tokens.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:692](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L692)
