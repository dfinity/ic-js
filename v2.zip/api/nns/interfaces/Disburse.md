---
title: Disburse
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:142](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L142)

## Properties

### amount

> **amount**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:144](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L144)

***

### toAccountId

> **toAccountId**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:143](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L143)
