---
title: KnownNeuron
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:200](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L200)

## Properties

### committed\_topics

> **committed\_topics**: [`Option`](../type-aliases/Option.md)\<(\[\] \| \[`TopicToFollow`\])[]\>

Defined in: [packages/nns/src/types/governance\_converters.ts:205](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L205)

***

### description

> **description**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:203](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L203)

***

### id

> **id**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:201](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L201)

***

### links

> **links**: [`Option`](../type-aliases/Option.md)\<`string`[]\>

Defined in: [packages/nns/src/types/governance\_converters.ts:204](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L204)

***

### name

> **name**: `string`

Defined in: [packages/nns/src/types/governance\_converters.ts:202](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L202)
