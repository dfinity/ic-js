---
title: KnownNeuron
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:200](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L200)

## Properties

### committed\_topics

> **committed\_topics**: [`Option`](../type-aliases/Option.md)\<(\[\] \| \[`TopicToFollow`\])[]\>

Defined in: [packages/nns/src/types/governance\_converters.ts:205](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L205)

***

### description

> **description**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:203](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L203)

***

### id

> **id**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:201](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L201)

***

### links

> **links**: [`Option`](../type-aliases/Option.md)\<`string`[]\>

Defined in: [packages/nns/src/types/governance\_converters.ts:204](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L204)

***

### name

> **name**: `string`

Defined in: [packages/nns/src/types/governance\_converters.ts:202](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L202)
