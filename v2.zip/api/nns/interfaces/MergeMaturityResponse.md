---
title: MergeMaturityResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:329](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L329)

## Properties

### mergedMaturityE8s

> **mergedMaturityE8s**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:330](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L330)

***

### newStakeE8s

> **newStakeE8s**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:331](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L331)
