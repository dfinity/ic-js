---
title: NeuronsFundEconomics
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:393](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L393)

## Properties

### maximumIcpXdrRate

> **maximumIcpXdrRate**: [`Option`](../type-aliases/Option.md)\<[`Percentage`](Percentage.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:394](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L394)

***

### maxTheoreticalNeuronsFundParticipationAmountXdr

> **maxTheoreticalNeuronsFundParticipationAmountXdr**: [`Option`](../type-aliases/Option.md)\<[`Decimal`](Decimal.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:396](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L396)

***

### minimumIcpXdrRate

> **minimumIcpXdrRate**: [`Option`](../type-aliases/Option.md)\<[`Percentage`](Percentage.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:397](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L397)

***

### neuronsFundMatchedFundingCurveCoefficients

> **neuronsFundMatchedFundingCurveCoefficients**: [`Option`](../type-aliases/Option.md)\<[`NeuronsFundMatchedFundingCurveCoefficients`](NeuronsFundMatchedFundingCurveCoefficients.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:395](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L395)
