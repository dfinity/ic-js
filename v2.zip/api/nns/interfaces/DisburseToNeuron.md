---
title: DisburseToNeuron
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:149](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L149)

## Properties

### amount

> **amount**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:152](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L152)

***

### dissolveDelaySeconds

> **dissolveDelaySeconds**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:150](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L150)

***

### kycVerified

> **kycVerified**: `boolean`

Defined in: [packages/nns/src/types/governance\_converters.ts:151](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L151)

***

### newController

> **newController**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:153](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L153)

***

### nonce

> **nonce**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:154](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L154)
