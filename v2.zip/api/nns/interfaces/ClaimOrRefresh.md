---
title: ClaimOrRefresh
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:92](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L92)

## Properties

### by

> **by**: [`Option`](../type-aliases/Option.md)\<[`By`](../type-aliases/By.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:93](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L93)
