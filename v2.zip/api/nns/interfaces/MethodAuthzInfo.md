---
title: MethodAuthzInfo
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:339](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L339)

## Properties

### methodName

> **methodName**: `string`

Defined in: [packages/nns/src/types/governance\_converters.ts:340](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L340)

***

### principalIds

> **principalIds**: `ArrayBuffer`[]

Defined in: [packages/nns/src/types/governance\_converters.ts:341](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L341)
