---
title: RewardEvent
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/candid/governance.d.ts:1051](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/candid/governance.d.ts#L1051)

## Properties

### actual\_timestamp\_seconds

> **actual\_timestamp\_seconds**: `bigint`

Defined in: [packages/nns/src/candid/governance.d.ts:1054](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/candid/governance.d.ts#L1054)

***

### day\_after\_genesis

> **day\_after\_genesis**: `bigint`

Defined in: [packages/nns/src/candid/governance.d.ts:1053](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/candid/governance.d.ts#L1053)

***

### distributed\_e8s\_equivalent

> **distributed\_e8s\_equivalent**: `bigint`

Defined in: [packages/nns/src/candid/governance.d.ts:1057](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/candid/governance.d.ts#L1057)

***

### latest\_round\_available\_e8s\_equivalent

> **latest\_round\_available\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/nns/src/candid/governance.d.ts:1056](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/candid/governance.d.ts#L1056)

***

### rounds\_since\_last\_distribution

> **rounds\_since\_last\_distribution**: \[\] \| \[`bigint`\]

Defined in: [packages/nns/src/candid/governance.d.ts:1052](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/candid/governance.d.ts#L1052)

***

### settled\_proposals

> **settled\_proposals**: `ProposalId`[]

Defined in: [packages/nns/src/candid/governance.d.ts:1058](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/candid/governance.d.ts#L1058)

***

### total\_available\_e8s\_equivalent

> **total\_available\_e8s\_equivalent**: `bigint`

Defined in: [packages/nns/src/candid/governance.d.ts:1055](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/candid/governance.d.ts#L1055)
