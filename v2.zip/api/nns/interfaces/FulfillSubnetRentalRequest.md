---
title: FulfillSubnetRentalRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:307](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L307)

## Properties

### nodeIds

> **nodeIds**: `Principal`[] \| `undefined`

Defined in: [packages/nns/src/types/governance\_converters.ts:310](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L310)

***

### replicaVersionId

> **replicaVersionId**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:309](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L309)

***

### user

> **user**: [`Option`](../type-aliases/Option.md)\<`Principal`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:308](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L308)
