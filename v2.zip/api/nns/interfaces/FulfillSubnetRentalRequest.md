---
title: FulfillSubnetRentalRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:307](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L307)

## Properties

### nodeIds

> **nodeIds**: `Principal`[] \| `undefined`

Defined in: [packages/nns/src/types/governance\_converters.ts:310](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L310)

***

### replicaVersionId

> **replicaVersionId**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:309](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L309)

***

### user

> **user**: [`Option`](../type-aliases/Option.md)\<`Principal`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:308](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L308)
