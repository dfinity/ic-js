---
title: IncreaseDissolveDelayRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:565](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L565)

## Properties

### additionalDissolveDelaySeconds

> **additionalDissolveDelaySeconds**: `number`

Defined in: [packages/nns/src/types/governance\_converters.ts:567](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L567)

***

### neuronId

> **neuronId**: `bigint`

Defined in: [packages/nns/src/types/governance\_converters.ts:566](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L566)
