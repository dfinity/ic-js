---
title: VotingRewardParameters
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:698](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L698)

## Properties

### finalRewardRate

> **finalRewardRate**: [`Option`](../type-aliases/Option.md)\<[`Percentage`](Percentage.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:701](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L701)

***

### initialRewardRate

> **initialRewardRate**: [`Option`](../type-aliases/Option.md)\<[`Percentage`](Percentage.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:700](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L700)

***

### rewardRateTransitionDuration

> **rewardRateTransitionDuration**: [`Option`](../type-aliases/Option.md)\<[`Duration`](Duration.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:699](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L699)
