---
title: VotingRewardParameters
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:698](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L698)

## Properties

### finalRewardRate

> **finalRewardRate**: [`Option`](../type-aliases/Option.md)\<[`Percentage`](Percentage.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:701](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L701)

***

### initialRewardRate

> **initialRewardRate**: [`Option`](../type-aliases/Option.md)\<[`Percentage`](Percentage.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:700](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L700)

***

### rewardRateTransitionDuration

> **rewardRateTransitionDuration**: [`Option`](../type-aliases/Option.md)\<[`Duration`](Duration.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:699](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/types/governance_converters.ts#L699)
