---
title: GovernanceParameters
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:704](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L704)

## Properties

### neuronMaximumAgeBonus

> **neuronMaximumAgeBonus**: [`Option`](../type-aliases/Option.md)\<[`Percentage`](Percentage.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:709](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L709)

***

### neuronMaximumAgeForAgeBonus

> **neuronMaximumAgeForAgeBonus**: [`Option`](../type-aliases/Option.md)\<[`Duration`](Duration.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:706](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L706)

***

### neuronMaximumDissolveDelay

> **neuronMaximumDissolveDelay**: [`Option`](../type-aliases/Option.md)\<[`Duration`](Duration.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:707](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L707)

***

### neuronMaximumDissolveDelayBonus

> **neuronMaximumDissolveDelayBonus**: [`Option`](../type-aliases/Option.md)\<[`Percentage`](Percentage.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:705](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L705)

***

### neuronMinimumDissolveDelayToVote

> **neuronMinimumDissolveDelayToVote**: [`Option`](../type-aliases/Option.md)\<[`Duration`](Duration.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:708](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L708)

***

### neuronMinimumStake

> **neuronMinimumStake**: [`Option`](../type-aliases/Option.md)\<[`Tokens`](Tokens.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:710](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L710)

***

### proposalInitialVotingPeriod

> **proposalInitialVotingPeriod**: [`Option`](../type-aliases/Option.md)\<[`Duration`](Duration.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:712](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L712)

***

### proposalRejectionFee

> **proposalRejectionFee**: [`Option`](../type-aliases/Option.md)\<[`Tokens`](Tokens.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:713](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L713)

***

### proposalWaitForQuietDeadlineIncrease

> **proposalWaitForQuietDeadlineIncrease**: [`Option`](../type-aliases/Option.md)\<[`Duration`](Duration.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:711](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L711)

***

### votingRewardParameters

> **votingRewardParameters**: [`Option`](../type-aliases/Option.md)\<[`VotingRewardParameters`](VotingRewardParameters.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:714](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L714)
