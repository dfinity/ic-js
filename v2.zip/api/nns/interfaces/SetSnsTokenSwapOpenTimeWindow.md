---
title: SetSnsTokenSwapOpenTimeWindow
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:367](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L367)

## Properties

### request

> **request**: [`Option`](../type-aliases/Option.md)\<\{ `openTimeWindow`: [`Option`](../type-aliases/Option.md)\<\{ `endTimestampSeconds`: `bigint`; `startTimestampSeconds`: `bigint`; \}\>; \}\>

Defined in: [packages/nns/src/types/governance\_converters.ts:368](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L368)

***

### swapCanisterId

> **swapCanisterId**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:374](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L374)
