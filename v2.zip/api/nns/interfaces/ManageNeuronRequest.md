---
title: ManageNeuronRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:271](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L271)

## Properties

### command

> **command**: [`Option`](../type-aliases/Option.md)\<[`ManageNeuronCommandRequest`](../type-aliases/ManageNeuronCommandRequest.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:273](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L273)

***

### id

> **id**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:272](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L272)

***

### neuronIdOrSubaccount

> **neuronIdOrSubaccount**: [`Option`](../type-aliases/Option.md)\<[`NeuronIdOrSubaccount`](../type-aliases/NeuronIdOrSubaccount.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:274](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/types/governance_converters.ts#L274)
