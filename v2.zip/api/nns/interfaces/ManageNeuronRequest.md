---
title: ManageNeuronRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/nns/src/types/governance\_converters.ts:271](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L271)

## Properties

### command

> **command**: [`Option`](../type-aliases/Option.md)\<[`ManageNeuronCommandRequest`](../type-aliases/ManageNeuronCommandRequest.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:273](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L273)

***

### id

> **id**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/nns/src/types/governance\_converters.ts:272](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L272)

***

### neuronIdOrSubaccount

> **neuronIdOrSubaccount**: [`Option`](../type-aliases/Option.md)\<[`NeuronIdOrSubaccount`](../type-aliases/NeuronIdOrSubaccount.md)\>

Defined in: [packages/nns/src/types/governance\_converters.ts:274](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/types/governance_converters.ts#L274)
