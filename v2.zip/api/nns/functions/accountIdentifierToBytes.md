---
title: accountIdentifierToBytes
editUrl: false
next: true
prev: true
---

> **accountIdentifierToBytes**(`accountIdentifier`): `Uint8Array`

Defined in: [packages/nns/src/utils/account\_identifier.utils.ts:15](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/utils/account_identifier.utils.ts#L15)

## Parameters

### accountIdentifier

`string`

## Returns

`Uint8Array`
