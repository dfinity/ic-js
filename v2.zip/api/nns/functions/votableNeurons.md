---
title: votableNeurons
editUrl: false
next: true
prev: true
---

> **votableNeurons**(`params`): [`NeuronInfo`](../interfaces/NeuronInfo.md)[]

Defined in: [packages/nns/src/utils/neurons.utils.ts:66](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/utils/neurons.utils.ts#L66)

Filter the neurons that can vote for a proposal - i.e. the neurons that have not voted yet and are eligible

## Parameters

### params

#### neurons

[`NeuronInfo`](../interfaces/NeuronInfo.md)[]

The neurons to filter.

#### proposal

[`ProposalInfo`](../interfaces/ProposalInfo.md)

The proposal to match against the selected neurons.

## Returns

[`NeuronInfo`](../interfaces/NeuronInfo.md)[]
