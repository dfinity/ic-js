---
title: votableNeurons
editUrl: false
next: true
prev: true
---

> **votableNeurons**(`params`): [`NeuronInfo`](../interfaces/NeuronInfo.md)[]

Defined in: [packages/nns/src/utils/neurons.utils.ts:66](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/utils/neurons.utils.ts#L66)

Filter the neurons that can vote for a proposal - i.e. the neurons that have not voted yet and are eligible

## Parameters

### params

#### neurons

[`NeuronInfo`](../interfaces/NeuronInfo.md)[]

The neurons to filter.

#### proposal

[`ProposalInfo`](../interfaces/ProposalInfo.md)

The proposal to match against the selected neurons.

## Returns

[`NeuronInfo`](../interfaces/NeuronInfo.md)[]
