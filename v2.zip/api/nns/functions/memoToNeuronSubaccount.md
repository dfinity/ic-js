---
title: memoToNeuronSubaccount
editUrl: false
next: true
prev: true
---

> **memoToNeuronSubaccount**(`__namedParameters`): `SubAccount`

Defined in: [packages/nns/src/utils/neurons.utils.ts:101](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/utils/neurons.utils.ts#L101)

## Parameters

### \_\_namedParameters

#### controller

`Principal`

#### memo

`bigint`

## Returns

`SubAccount`
