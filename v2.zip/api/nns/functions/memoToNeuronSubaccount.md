---
title: memoToNeuronSubaccount
editUrl: false
next: true
prev: true
---

> **memoToNeuronSubaccount**(`__namedParameters`): `SubAccount`

Defined in: [packages/nns/src/utils/neurons.utils.ts:101](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/utils/neurons.utils.ts#L101)

## Parameters

### \_\_namedParameters

#### controller

`Principal`

#### memo

`bigint`

## Returns

`SubAccount`
