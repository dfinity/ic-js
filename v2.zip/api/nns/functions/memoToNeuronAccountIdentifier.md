---
title: memoToNeuronAccountIdentifier
editUrl: false
next: true
prev: true
---

> **memoToNeuronAccountIdentifier**(`__namedParameters`): `AccountIdentifier`

Defined in: [packages/nns/src/utils/neurons.utils.ts:122](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/nns/src/utils/neurons.utils.ts#L122)

## Parameters

### \_\_namedParameters

#### controller

`Principal`

#### governanceCanisterId

`Principal`

#### memo

`bigint`

## Returns

`AccountIdentifier`
