---
title: memoToNeuronAccountIdentifier
editUrl: false
next: true
prev: true
---

> **memoToNeuronAccountIdentifier**(`__namedParameters`): `AccountIdentifier`

Defined in: [packages/nns/src/utils/neurons.utils.ts:122](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/nns/src/utils/neurons.utils.ts#L122)

## Parameters

### \_\_namedParameters

#### controller

`Principal`

#### governanceCanisterId

`Principal`

#### memo

`bigint`

## Returns

`AccountIdentifier`
