---
title: votedNeurons
editUrl: false
next: true
prev: true
---

> **votedNeurons**(`params`): [`NeuronInfo`](../interfaces/NeuronInfo.md)[]

Defined in: [packages/nns/src/utils/neurons.utils.ts:89](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/nns/src/utils/neurons.utils.ts#L89)

Filter the neurons that have voted for a proposal.

## Parameters

### params

#### neurons

[`NeuronInfo`](../interfaces/NeuronInfo.md)[]

The neurons to filter.

#### proposal

[`ProposalInfo`](../interfaces/ProposalInfo.md)

The proposal for which some neurons might have already voted.

## Returns

[`NeuronInfo`](../interfaces/NeuronInfo.md)[]
