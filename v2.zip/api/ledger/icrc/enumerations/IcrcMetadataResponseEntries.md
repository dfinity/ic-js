---
title: IcrcMetadataResponseEntries
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icrc/src/types/ledger.responses.ts:5](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/types/ledger.responses.ts#L5)

## Enumeration Members

### DECIMALS

> **DECIMALS**: `"icrc1:decimals"`

Defined in: [packages/ledger-icrc/src/types/ledger.responses.ts:8](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/types/ledger.responses.ts#L8)

***

### FEE

> **FEE**: `"icrc1:fee"`

Defined in: [packages/ledger-icrc/src/types/ledger.responses.ts:9](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/types/ledger.responses.ts#L9)

***

### LOGO

> **LOGO**: `"icrc1:logo"`

Defined in: [packages/ledger-icrc/src/types/ledger.responses.ts:10](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/types/ledger.responses.ts#L10)

***

### NAME

> **NAME**: `"icrc1:name"`

Defined in: [packages/ledger-icrc/src/types/ledger.responses.ts:7](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/types/ledger.responses.ts#L7)

***

### SYMBOL

> **SYMBOL**: `"icrc1:symbol"`

Defined in: [packages/ledger-icrc/src/types/ledger.responses.ts:6](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/types/ledger.responses.ts#L6)
