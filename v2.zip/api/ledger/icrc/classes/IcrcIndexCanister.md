---
title: IcrcIndexCanister
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icrc/src/index.canister.ts:14](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/index.canister.ts#L14)

## Extends

- `Canister`\<`IcrcIndexService`\>

## Constructors

### Constructor

> `protected` **new IcrcIndexCanister**(`id`, `service`, `certifiedService`): `IcrcIndexCanister`

Defined in: packages/utils/dist/services/canister.d.ts:7

#### Parameters

##### id

`Principal`

##### service

`_SERVICE`

##### certifiedService

`_SERVICE`

#### Returns

`IcrcIndexCanister`

#### Inherited from

`Canister<IcrcIndexService>.constructor`

## Properties

### caller()

> `protected` **caller**: (`__namedParameters`) => `_SERVICE`

Defined in: packages/utils/dist/services/canister.d.ts:9

#### Parameters

##### \_\_namedParameters

`QueryParams`

#### Returns

`_SERVICE`

#### Inherited from

`Canister.caller`

***

### certifiedService

> `protected` `readonly` **certifiedService**: `_SERVICE`

Defined in: packages/utils/dist/services/canister.d.ts:6

#### Inherited from

`Canister.certifiedService`

***

### service

> `protected` `readonly` **service**: `_SERVICE`

Defined in: packages/utils/dist/services/canister.d.ts:5

#### Inherited from

`Canister.service`

## Accessors

### canisterId

#### Get Signature

> **get** **canisterId**(): `Principal`

Defined in: packages/utils/dist/services/canister.d.ts:8

##### Returns

`Principal`

#### Inherited from

`Canister.canisterId`

## Methods

### getTransactions()

> **getTransactions**(`params`): `Promise`\<[`IcrcGetTransactions`](../interfaces/IcrcGetTransactions.md)\>

Defined in: [packages/ledger-icrc/src/index.canister.ts:34](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/index.canister.ts#L34)

Get the transactions of an account

Always certified.
`get_account_transactions` needs to be called with an update
because the index canisters makes a call to the ledger canister to get the transaction data.
Index Canister only holds the transactions ids in state, not the whole transaction data.

#### Parameters

##### params

[`GetAccountTransactionsParams`](../interfaces/GetAccountTransactionsParams.md)

#### Returns

`Promise`\<[`IcrcGetTransactions`](../interfaces/IcrcGetTransactions.md)\>

***

### ledgerId()

> **ledgerId**(`params`): `Promise`\<`Principal`\>

Defined in: [packages/ledger-icrc/src/index.canister.ts:51](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/index.canister.ts#L51)

Returns the ledger canister ID related to the index canister.

#### Parameters

##### params

`QueryParams`

#### Returns

`Promise`\<`Principal`\>

***

### create()

> `static` **create**(`options`): `IcrcIndexCanister`

Defined in: [packages/ledger-icrc/src/index.canister.ts:15](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/index.canister.ts#L15)

#### Parameters

##### options

`IcrcLedgerCanisterOptions`\<`_SERVICE`\>

#### Returns

`IcrcIndexCanister`
