---
title: IcrcIndexNgCanister
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icrc/src/index-ng.canister.ts:23](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/index-ng.canister.ts#L23)

## Extends

- `IcrcCanister`\<`IcrcIndexNgService`\>

## Constructors

### Constructor

> `protected` **new IcrcIndexNgCanister**(`id`, `service`, `certifiedService`): `IcrcIndexNgCanister`

Defined in: packages/utils/dist/services/canister.d.ts:7

#### Parameters

##### id

`Principal`

##### service

`_SERVICE`

##### certifiedService

`_SERVICE`

#### Returns

`IcrcIndexNgCanister`

#### Inherited from

`IcrcCanister<IcrcIndexNgService>.constructor`

## Properties

### caller()

> `protected` **caller**: (`__namedParameters`) => `_SERVICE`

Defined in: packages/utils/dist/services/canister.d.ts:9

#### Parameters

##### \_\_namedParameters

`QueryParams`

#### Returns

`_SERVICE`

#### Inherited from

`IcrcCanister.caller`

***

### certifiedService

> `protected` `readonly` **certifiedService**: `_SERVICE`

Defined in: packages/utils/dist/services/canister.d.ts:6

#### Inherited from

`IcrcCanister.certifiedService`

***

### service

> `protected` `readonly` **service**: `_SERVICE`

Defined in: packages/utils/dist/services/canister.d.ts:5

#### Inherited from

`IcrcCanister.service`

## Accessors

### canisterId

#### Get Signature

> **get** **canisterId**(): `Principal`

Defined in: packages/utils/dist/services/canister.d.ts:8

##### Returns

`Principal`

#### Inherited from

`IcrcCanister.canisterId`

## Methods

### balance()

> **balance**(`params`): `Promise`\<`bigint`\>

Defined in: [packages/ledger-icrc/src/canister.ts:18](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/canister.ts#L18)

Returns the balance for a given account provided as owner and with optional subaccount.

#### Parameters

##### params

[`BalanceParams`](../type-aliases/BalanceParams.md)

The parameters to get the balance of an account.

#### Returns

`Promise`\<`bigint`\>

The balance of the given account.

#### Inherited from

`IcrcCanister.balance`

***

### getTransactions()

> **getTransactions**(`params`): `Promise`\<[`IcrcIndexNgGetTransactions`](../interfaces/IcrcIndexNgGetTransactions.md)\>

Defined in: [packages/ledger-icrc/src/index-ng.canister.ts:49](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/index-ng.canister.ts#L49)

Get the transactions of an account.

#### Parameters

##### params

[`GetIndexNgAccountTransactionsParams`](../type-aliases/GetIndexNgAccountTransactionsParams.md)

The parameters to get the transactions of an account.

#### Returns

`Promise`\<[`IcrcIndexNgGetTransactions`](../interfaces/IcrcIndexNgGetTransactions.md)\>

The list of transactions and further related information of the given account.

***

### ledgerId()

> **ledgerId**(`params`): `Promise`\<`Principal`\>

Defined in: [packages/ledger-icrc/src/index-ng.canister.ts:67](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/index-ng.canister.ts#L67)

Returns the ledger canister ID related to the index canister.

#### Parameters

##### params

`QueryParams`

#### Returns

`Promise`\<`Principal`\>

***

### listSubaccounts()

> **listSubaccounts**(`params`): `Promise`\<`SubAccount`[]\>

Defined in: [packages/ledger-icrc/src/index-ng.canister.ts:87](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/index-ng.canister.ts#L87)

Returns the list of subaccounts for a given owner.

#### Parameters

##### params

[`ListSubaccountsParams`](../type-aliases/ListSubaccountsParams.md)

The parameters to get the list of subaccounts.

#### Returns

`Promise`\<`SubAccount`[]\>

The list of subaccounts.

***

### status()

> **status**(`params`): `Promise`\<[`IcrcNgStatus`](../interfaces/IcrcNgStatus.md)\>

Defined in: [packages/ledger-icrc/src/index-ng.canister.ts:78](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/index-ng.canister.ts#L78)

Returns the status of the index canister.

#### Parameters

##### params

`QueryParams`

The parameters to get the status of the index canister.

#### Returns

`Promise`\<[`IcrcNgStatus`](../interfaces/IcrcNgStatus.md)\>

The status of the index canister.

***

### create()

> `static` **create**(`options`): `IcrcIndexNgCanister`

Defined in: [packages/ledger-icrc/src/index-ng.canister.ts:24](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/index-ng.canister.ts#L24)

#### Parameters

##### options

`IcrcLedgerCanisterOptions`\<`_SERVICE`\>

#### Returns

`IcrcIndexNgCanister`
