---
title: IcrcTokenMetadataResponse
editUrl: false
next: true
prev: true
---

> **IcrcTokenMetadataResponse** = \[`string` \| [`IcrcMetadataResponseEntries`](../enumerations/IcrcMetadataResponseEntries.md), [`IcrcValue`](IcrcValue.md)\][]

Defined in: [packages/ledger-icrc/src/types/ledger.responses.ts:13](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icrc/src/types/ledger.responses.ts#L13)
