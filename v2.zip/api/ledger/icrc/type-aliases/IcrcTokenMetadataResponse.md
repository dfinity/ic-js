---
title: IcrcTokenMetadataResponse
editUrl: false
next: true
prev: true
---

> **IcrcTokenMetadataResponse** = \[`string` \| [`IcrcMetadataResponseEntries`](../enumerations/IcrcMetadataResponseEntries.md), [`IcrcValue`](IcrcValue.md)\][]

Defined in: [packages/ledger-icrc/src/types/ledger.responses.ts:13](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/types/ledger.responses.ts#L13)
