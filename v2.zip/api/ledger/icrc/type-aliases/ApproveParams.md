---
title: ApproveParams
editUrl: false
next: true
prev: true
---

> **ApproveParams** = `Omit`\<[`TransferParams`](../interfaces/TransferParams.md), `"to"`\> & `object`

Defined in: [packages/ledger-icrc/src/types/ledger.params.ts:72](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/types/ledger.params.ts#L72)

Params for an icrc2_approve.

## Type Declaration

### expected\_allowance?

> `optional` **expected\_allowance**: [`IcrcTokens`](IcrcTokens.md)

### expires\_at?

> `optional` **expires\_at**: [`IcrcTimestamp`](IcrcTimestamp.md)

### spender

> **spender**: [`IcrcCandidAccount`](../interfaces/IcrcCandidAccount.md)

## Param

The account of the spender.

## Param

The Amount of tokens to approve.

## Param

The subaccount to transfer tokens from.

## Param

Transfer memo.

## Param

nanoseconds since unix epoc to trigger deduplication and avoid other issues

## Param

The fee of the transfer when it's not the default fee.

## Param

The optional allowance expected. If the expected_allowance field is set, the ledger MUST ensure that the current allowance for the spender from the caller's account is equal to the given value and return the AllowanceChanged error otherwise.

## Param

When the approval expires. If the field is set, it's greater than the current ledger time.
