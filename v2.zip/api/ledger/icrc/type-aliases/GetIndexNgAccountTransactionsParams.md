---
title: GetIndexNgAccountTransactionsParams
editUrl: false
next: true
prev: true
---

> **GetIndexNgAccountTransactionsParams** = `object` & `QueryParams`

Defined in: [packages/ledger-icrc/src/types/index-ng.params.ts:6](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/types/index-ng.params.ts#L6)

## Type Declaration

### account

> **account**: [`IcrcAccount`](../interfaces/IcrcAccount.md)

### max\_results

> **max\_results**: `bigint`

### start?

> `optional` **start**: [`IcrcNgTxId`](IcrcNgTxId.md)
