---
title: IcrcTxId
editUrl: false
next: true
prev: true
---

> **IcrcTxId** = `bigint`

Defined in: [packages/ledger-icrc/src/candid/icrc\_index.d.ts:98](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/candid/icrc_index.d.ts#L98)
