---
title: Icrc3Value
editUrl: false
next: true
prev: true
---

> **Icrc3Value** = \{ `Int`: `bigint`; \} \| \{ `Map`: \[`string`, `ICRC3Value`\][]; \} \| \{ `Nat`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Text`: `string`; \} \| \{ `Array`: `ICRC3Value`[]; \}

Defined in: [packages/ledger-icrc/src/candid/icrc\_ledger.d.ts:319](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_ledger.d.ts#L319)
