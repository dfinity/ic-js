---
title: IcrcTimestamp
editUrl: false
next: true
prev: true
---

> **IcrcTimestamp** = `bigint`

Defined in: [packages/ledger-icrc/src/candid/icrc\_ledger.d.ts:399](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_ledger.d.ts#L399)

Number of nanoseconds since the UNIX epoch in UTC timezone.
