---
title: BalanceParams
editUrl: false
next: true
prev: true
---

> **BalanceParams** = [`IcrcAccount`](../interfaces/IcrcAccount.md) & `QueryParams`

Defined in: [packages/ledger-icrc/src/types/ledger.params.ts:16](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/types/ledger.params.ts#L16)

Params to get the balance of an ICRC-1 account.
