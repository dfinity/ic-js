---
title: IcrcTransferVariantError
editUrl: false
next: true
prev: true
---

> **IcrcTransferVariantError** = \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `null`; \} \| \{ `BadBurn`: \{ `min_burn_amount`: [`IcrcTokens`](IcrcTokens.md); \}; \} \| \{ `Duplicate`: \{ `duplicate_of`: [`IcrcBlockIndex`](IcrcBlockIndex.md); \}; \} \| \{ `BadFee`: \{ `expected_fee`: [`IcrcTokens`](IcrcTokens.md); \}; \} \| \{ `CreatedInFuture`: \{ `ledger_time`: [`IcrcTimestamp`](IcrcTimestamp.md); \}; \} \| \{ `TooOld`: `null`; \} \| \{ `InsufficientFunds`: \{ `balance`: [`IcrcTokens`](IcrcTokens.md); \}; \}

Defined in: [packages/ledger-icrc/src/candid/icrc\_ledger.d.ts:449](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/candid/icrc_ledger.d.ts#L449)
