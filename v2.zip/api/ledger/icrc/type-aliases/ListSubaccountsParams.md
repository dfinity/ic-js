---
title: ListSubaccountsParams
editUrl: false
next: true
prev: true
---

> **ListSubaccountsParams** = `object` & `Pick`\<[`IcrcAccount`](../interfaces/IcrcAccount.md), `"owner"`\> & `QueryParams`

Defined in: [packages/ledger-icrc/src/types/index-ng.params.ts:12](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icrc/src/types/index-ng.params.ts#L12)

## Type Declaration

### start?

> `optional` **start**: [`IcrcSubaccount`](IcrcSubaccount.md)
