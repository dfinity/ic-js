---
title: IcrcNgTxId
editUrl: false
next: true
prev: true
---

> **IcrcNgTxId** = `bigint`

Defined in: [packages/ledger-icrc/src/candid/icrc\_index-ng.d.ts:28](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icrc/src/candid/icrc_index-ng.d.ts#L28)
