---
title: IcrcNgTxId
editUrl: false
next: true
prev: true
---

> **IcrcNgTxId** = `bigint`

Defined in: [packages/ledger-icrc/src/candid/icrc\_index-ng.d.ts:28](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/candid/icrc_index-ng.d.ts#L28)
