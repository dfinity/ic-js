---
title: IcrcNgTxId
editUrl: false
next: true
prev: true
---

> **IcrcNgTxId** = `bigint`

Defined in: [packages/ledger-icrc/src/candid/icrc\_index-ng.d.ts:28](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_index-ng.d.ts#L28)
