---
title: TransferFromParams
editUrl: false
next: true
prev: true
---

> **TransferFromParams** = `Omit`\<[`TransferParams`](../interfaces/TransferParams.md), `"from_subaccount"`\> & `object`

Defined in: [packages/ledger-icrc/src/types/ledger.params.ts:55](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/types/ledger.params.ts#L55)

Params for an icrc2_transfer_from.

## Type Declaration

### from

> **from**: [`IcrcCandidAccount`](../interfaces/IcrcCandidAccount.md)

### spender\_subaccount?

> `optional` **spender\_subaccount**: [`IcrcSubaccount`](IcrcSubaccount.md)

## Param

The account to transfer tokens to.

## Param

The account to transfer tokens from.

## Param

A spender subaccount.

## Param

The Amount of tokens to transfer.

## Param

Transfer memo.

## Param

nanoseconds since unix epoc to trigger deduplication and avoid other issues

## Param

The fee of the transfer when it's not the default fee.
