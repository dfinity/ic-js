---
title: IcrcValue
editUrl: false
next: true
prev: true
---

> **IcrcValue** = \{ `Int`: `bigint`; \} \| \{ `Map`: `Map`; \} \| \{ `Nat`: `bigint`; \} \| \{ `Nat64`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Text`: `string`; \} \| \{ `Array`: `Value`[]; \}

Defined in: [packages/ledger-icrc/src/candid/icrc\_ledger.d.ts:497](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icrc/src/candid/icrc_ledger.d.ts#L497)
