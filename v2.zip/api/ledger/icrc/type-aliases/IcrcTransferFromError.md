---
title: IcrcTransferFromError
editUrl: false
next: true
prev: true
---

> **IcrcTransferFromError** = \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `null`; \} \| \{ `InsufficientAllowance`: \{ `allowance`: [`IcrcTokens`](IcrcTokens.md); \}; \} \| \{ `BadBurn`: \{ `min_burn_amount`: [`IcrcTokens`](IcrcTokens.md); \}; \} \| \{ `Duplicate`: \{ `duplicate_of`: [`IcrcBlockIndex`](IcrcBlockIndex.md); \}; \} \| \{ `BadFee`: \{ `expected_fee`: [`IcrcTokens`](IcrcTokens.md); \}; \} \| \{ `CreatedInFuture`: \{ `ledger_time`: [`IcrcTimestamp`](IcrcTimestamp.md); \}; \} \| \{ `TooOld`: `null`; \} \| \{ `InsufficientFunds`: \{ `balance`: [`IcrcTokens`](IcrcTokens.md); \}; \}

Defined in: [packages/ledger-icrc/src/candid/icrc\_ledger.d.ts:469](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_ledger.d.ts#L469)
