---
title: GetBlocksParams
editUrl: false
next: true
prev: true
---

> **GetBlocksParams** = `QueryParams` & `object`

Defined in: [packages/ledger-icrc/src/types/ledger.params.ts:133](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/types/ledger.params.ts#L133)

Parameters to get the canister blocks.

## Type Declaration

### args

> **args**: [`IcrcGetBlocksArgs`](../interfaces/IcrcGetBlocksArgs.md)[]
