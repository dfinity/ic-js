---
title: Icrc21ConsentMessageDeviceSpec
editUrl: false
next: true
prev: true
---

> **Icrc21ConsentMessageDeviceSpec** = \{ `GenericDisplay`: `null`; \} \| \{ `FieldsDisplay`: `null`; \}

Defined in: [packages/ledger-icrc/src/types/ledger.params.ts:99](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/types/ledger.params.ts#L99)

Device specification for displaying the consent message.

## Param

A generic display able to handle large documents and do line wrapping and pagination / scrolling.  Text must be Markdown formatted, no external resources (e.g. images) are allowed.

## Param

A simple display able to handle multiple fields with a title and content.
