---
title: mapIcrc106GetIndexPrincipalError
editUrl: false
next: true
prev: true
---

> **mapIcrc106GetIndexPrincipalError**(`err`): [`GenericError`](../classes/GenericError.md) \| [`IndexPrincipalNotSetError`](../classes/IndexPrincipalNotSetError.md)

Defined in: [packages/ledger-icrc/src/errors/ledger.errors.ts:64](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icrc/src/errors/ledger.errors.ts#L64)

## Parameters

### err

`GetIndexPrincipalError`

## Returns

[`GenericError`](../classes/GenericError.md) \| [`IndexPrincipalNotSetError`](../classes/IndexPrincipalNotSetError.md)
