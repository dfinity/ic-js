---
title: mapIcrc106GetIndexPrincipalError
editUrl: false
next: true
prev: true
---

> **mapIcrc106GetIndexPrincipalError**(`err`): [`GenericError`](../classes/GenericError.md) \| [`IndexPrincipalNotSetError`](../classes/IndexPrincipalNotSetError.md)

Defined in: [packages/ledger-icrc/src/errors/ledger.errors.ts:64](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/errors/ledger.errors.ts#L64)

## Parameters

### err

`GetIndexPrincipalError`

## Returns

[`GenericError`](../classes/GenericError.md) \| [`IndexPrincipalNotSetError`](../classes/IndexPrincipalNotSetError.md)
