---
title: toIcrc21ConsentMessageArgs
editUrl: false
next: true
prev: true
---

> **toIcrc21ConsentMessageArgs**(`__namedParameters`): `icrc21_consent_message_request`

Defined in: [packages/ledger-icrc/src/converters/ledger.converters.ts:66](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icrc/src/converters/ledger.converters.ts#L66)

## Parameters

### \_\_namedParameters

[`Icrc21ConsentMessageParams`](../type-aliases/Icrc21ConsentMessageParams.md)

## Returns

`icrc21_consent_message_request`
