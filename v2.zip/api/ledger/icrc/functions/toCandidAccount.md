---
title: toCandidAccount
editUrl: false
next: true
prev: true
---

> **toCandidAccount**(`-`): [`IcrcCandidAccount`](../interfaces/IcrcCandidAccount.md)

Defined in: [packages/ledger-icrc/src/converters/converters.ts:29](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/converters/converters.ts#L29)

Converts an IcrcAccount to a Candid Account object, effectively transforming nullish properties into nullable ones.

## Parameters

### -

[`IcrcAccount`](../interfaces/IcrcAccount.md)

The IcrcAccount object to convert.

## Returns

[`IcrcCandidAccount`](../interfaces/IcrcCandidAccount.md)

- The converted Candid Account object.
