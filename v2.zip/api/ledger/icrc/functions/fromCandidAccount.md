---
title: fromCandidAccount
editUrl: false
next: true
prev: true
---

> **fromCandidAccount**(`-`): [`IcrcAccount`](../interfaces/IcrcAccount.md)

Defined in: [packages/ledger-icrc/src/converters/converters.ts:11](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/converters/converters.ts#L11)

Converts a Candid Account object to an IcrcAccount, effectively transforming nullable properties into nullish ones.

## Parameters

### -

[`IcrcCandidAccount`](../interfaces/IcrcCandidAccount.md)

The Candid Account object to convert.

## Returns

[`IcrcAccount`](../interfaces/IcrcAccount.md)

- The converted IcrcAccount object.
