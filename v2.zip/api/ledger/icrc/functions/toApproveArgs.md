---
title: toApproveArgs
editUrl: false
next: true
prev: true
---

> **toApproveArgs**(`__namedParameters`): `ApproveArgs`

Defined in: [packages/ledger-icrc/src/converters/ledger.converters.ts:48](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/converters/ledger.converters.ts#L48)

## Parameters

### \_\_namedParameters

[`ApproveParams`](../type-aliases/ApproveParams.md)

## Returns

`ApproveArgs`
