---
title: toTransferFromArgs
editUrl: false
next: true
prev: true
---

> **toTransferFromArgs**(`__namedParameters`): `TransferFromArgs`

Defined in: [packages/ledger-icrc/src/converters/ledger.converters.ts:34](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/converters/ledger.converters.ts#L34)

## Parameters

### \_\_namedParameters

[`TransferFromParams`](../type-aliases/TransferFromParams.md)

## Returns

`TransferFromArgs`
