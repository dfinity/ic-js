---
title: toTransferArg
editUrl: false
next: true
prev: true
---

> **toTransferArg**(`__namedParameters`): [`IcrcTransferArg`](../interfaces/IcrcTransferArg.md)

Defined in: [packages/ledger-icrc/src/converters/ledger.converters.ts:20](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/converters/ledger.converters.ts#L20)

## Parameters

### \_\_namedParameters

[`TransferParams`](../interfaces/TransferParams.md)

## Returns

[`IcrcTransferArg`](../interfaces/IcrcTransferArg.md)
