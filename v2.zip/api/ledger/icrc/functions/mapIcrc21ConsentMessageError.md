---
title: mapIcrc21ConsentMessageError
editUrl: false
next: true
prev: true
---

> **mapIcrc21ConsentMessageError**(`rawError`): [`ConsentMessageError`](../classes/ConsentMessageError.md)

Defined in: [packages/ledger-icrc/src/errors/ledger.errors.ts:29](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/errors/ledger.errors.ts#L29)

## Parameters

### rawError

`icrc21_error`

## Returns

[`ConsentMessageError`](../classes/ConsentMessageError.md)
