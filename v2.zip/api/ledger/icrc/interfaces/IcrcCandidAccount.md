---
title: IcrcCandidAccount
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icrc/src/candid/icrc\_ledger.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icrc/src/candid/icrc_ledger.d.ts#L13)

## Properties

### owner

> **owner**: `Principal`

Defined in: [packages/ledger-icrc/src/candid/icrc\_ledger.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icrc/src/candid/icrc_ledger.d.ts#L14)

***

### subaccount

> **subaccount**: \[\] \| \[[`IcrcSubaccount`](../type-aliases/IcrcSubaccount.md)\]

Defined in: [packages/ledger-icrc/src/candid/icrc\_ledger.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icrc/src/candid/icrc_ledger.d.ts#L15)
