---
title: IcrcGetBlocksResult
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icrc/src/candid/icrc\_ledger.d.ts:221](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_ledger.d.ts#L221)

## Properties

### archived\_blocks

> **archived\_blocks**: `object`[]

Defined in: [packages/ledger-icrc/src/candid/icrc\_ledger.d.ts:228](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_ledger.d.ts#L228)

#### args

> **args**: [`IcrcGetBlocksArgs`](IcrcGetBlocksArgs.md)[]

#### callback

> **callback**: \[`Principal`, `string`\]

***

### blocks

> **blocks**: `object`[]

Defined in: [packages/ledger-icrc/src/candid/icrc\_ledger.d.ts:227](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_ledger.d.ts#L227)

#### block

> **block**: [`Icrc3Value`](../type-aliases/Icrc3Value.md)

#### id

> **id**: `bigint`

***

### log\_length

> **log\_length**: `bigint`

Defined in: [packages/ledger-icrc/src/candid/icrc\_ledger.d.ts:226](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_ledger.d.ts#L226)

Total number of blocks in the
block log
