---
title: IcrcTransactionWithId
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icrc/src/candid/icrc\_index.d.ts:85](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_index.d.ts#L85)

## Properties

### id

> **id**: `bigint`

Defined in: [packages/ledger-icrc/src/candid/icrc\_index.d.ts:86](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_index.d.ts#L86)

***

### transaction

> **transaction**: [`IcrcTransaction`](IcrcTransaction.md)

Defined in: [packages/ledger-icrc/src/candid/icrc\_index.d.ts:87](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_index.d.ts#L87)
