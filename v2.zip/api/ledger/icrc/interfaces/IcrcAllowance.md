---
title: IcrcAllowance
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icrc/src/candid/icrc\_ledger.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/candid/icrc_ledger.d.ts#L17)

## Properties

### allowance

> **allowance**: `bigint`

Defined in: [packages/ledger-icrc/src/candid/icrc\_ledger.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/candid/icrc_ledger.d.ts#L18)

***

### expires\_at

> **expires\_at**: \[\] \| \[`bigint`\]

Defined in: [packages/ledger-icrc/src/candid/icrc\_ledger.d.ts:19](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/candid/icrc_ledger.d.ts#L19)
