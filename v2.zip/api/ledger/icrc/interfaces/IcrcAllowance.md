---
title: IcrcAllowance
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icrc/src/candid/icrc\_ledger.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icrc/src/candid/icrc_ledger.d.ts#L17)

## Properties

### allowance

> **allowance**: `bigint`

Defined in: [packages/ledger-icrc/src/candid/icrc\_ledger.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icrc/src/candid/icrc_ledger.d.ts#L18)

***

### expires\_at

> **expires\_at**: \[\] \| \[`bigint`\]

Defined in: [packages/ledger-icrc/src/candid/icrc\_ledger.d.ts:19](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icrc/src/candid/icrc_ledger.d.ts#L19)
