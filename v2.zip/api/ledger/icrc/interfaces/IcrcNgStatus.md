---
title: IcrcNgStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icrc/src/candid/icrc\_index-ng.d.ts:98](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_index-ng.d.ts#L98)

## Properties

### num\_blocks\_synced

> **num\_blocks\_synced**: `bigint`

Defined in: [packages/ledger-icrc/src/candid/icrc\_index-ng.d.ts:99](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_index-ng.d.ts#L99)
