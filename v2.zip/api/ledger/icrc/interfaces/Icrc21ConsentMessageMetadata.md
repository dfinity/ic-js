---
title: Icrc21ConsentMessageMetadata
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icrc/src/types/ledger.params.ts:88](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/types/ledger.params.ts#L88)

Metadata for the consent message in ICRC-21 specification.

## Param

The user's local timezone offset in minutes from UTC. If absent, the default is UTC.

## Param

BCP-47 language tag. See https://www.rfc-editor.org/rfc/bcp/bcp47.txt

## Properties

### language

> **language**: `string`

Defined in: [packages/ledger-icrc/src/types/ledger.params.ts:90](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/types/ledger.params.ts#L90)

***

### utcOffsetMinutes?

> `optional` **utcOffsetMinutes**: `number`

Defined in: [packages/ledger-icrc/src/types/ledger.params.ts:89](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/types/ledger.params.ts#L89)
