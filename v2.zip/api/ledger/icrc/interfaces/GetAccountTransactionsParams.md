---
title: GetAccountTransactionsParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icrc/src/types/index.params.ts:4](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/types/index.params.ts#L4)

## Properties

### account

> **account**: [`IcrcAccount`](IcrcAccount.md)

Defined in: [packages/ledger-icrc/src/types/index.params.ts:7](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/types/index.params.ts#L7)

***

### max\_results

> **max\_results**: `bigint`

Defined in: [packages/ledger-icrc/src/types/index.params.ts:5](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/types/index.params.ts#L5)

***

### start?

> `optional` **start**: `bigint`

Defined in: [packages/ledger-icrc/src/types/index.params.ts:6](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/types/index.params.ts#L6)
