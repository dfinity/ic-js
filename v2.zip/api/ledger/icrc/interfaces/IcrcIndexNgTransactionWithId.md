---
title: IcrcIndexNgTransactionWithId
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icrc/src/candid/icrc\_index-ng.d.ts:111](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_index-ng.d.ts#L111)

## Properties

### id

> **id**: `bigint`

Defined in: [packages/ledger-icrc/src/candid/icrc\_index-ng.d.ts:112](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_index-ng.d.ts#L112)

***

### transaction

> **transaction**: [`IcrcIndexNgTransaction`](IcrcIndexNgTransaction.md)

Defined in: [packages/ledger-icrc/src/candid/icrc\_index-ng.d.ts:113](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_index-ng.d.ts#L113)
