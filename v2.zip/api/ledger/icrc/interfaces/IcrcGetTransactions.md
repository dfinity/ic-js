---
title: IcrcGetTransactions
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icrc/src/candid/icrc\_index.d.ts:47](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/candid/icrc_index.d.ts#L47)

## Properties

### oldest\_tx\_id

> **oldest\_tx\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/ledger-icrc/src/candid/icrc\_index.d.ts:52](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/candid/icrc_index.d.ts#L52)

The txid of the oldest transaction the account has

***

### transactions

> **transactions**: [`IcrcTransactionWithId`](IcrcTransactionWithId.md)[]

Defined in: [packages/ledger-icrc/src/candid/icrc\_index.d.ts:48](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/candid/icrc_index.d.ts#L48)
