---
title: IcrcGetTransactions
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icrc/src/candid/icrc\_index.d.ts:47](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_index.d.ts#L47)

## Properties

### oldest\_tx\_id

> **oldest\_tx\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/ledger-icrc/src/candid/icrc\_index.d.ts:52](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_index.d.ts#L52)

The txid of the oldest transaction the account has

***

### transactions

> **transactions**: [`IcrcTransactionWithId`](IcrcTransactionWithId.md)[]

Defined in: [packages/ledger-icrc/src/candid/icrc\_index.d.ts:48](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/candid/icrc_index.d.ts#L48)
