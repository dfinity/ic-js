---
title: IcrcGetBlocksArgs
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icrc/src/candid/icrc\_ledger.d.ts:164](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/candid/icrc_ledger.d.ts#L164)

## Properties

### length

> **length**: `bigint`

Defined in: [packages/ledger-icrc/src/candid/icrc\_ledger.d.ts:172](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/candid/icrc_ledger.d.ts#L172)

Max number of blocks to fetch.

***

### start

> **start**: `bigint`

Defined in: [packages/ledger-icrc/src/candid/icrc\_ledger.d.ts:168](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/candid/icrc_ledger.d.ts#L168)

The index of the first block to fetch.
