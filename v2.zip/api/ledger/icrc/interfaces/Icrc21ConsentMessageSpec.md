---
title: Icrc21ConsentMessageSpec
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icrc/src/types/ledger.params.ts:111](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/types/ledger.params.ts#L111)

Specification for the consent message, including metadata and device preferences.

## Param

Metadata of the consent message.

## Param

Information about the device responsible for presenting the consent message to the user.

## Properties

### deriveSpec?

> `optional` **deriveSpec**: [`Icrc21ConsentMessageDeviceSpec`](../type-aliases/Icrc21ConsentMessageDeviceSpec.md)

Defined in: [packages/ledger-icrc/src/types/ledger.params.ts:113](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/types/ledger.params.ts#L113)

***

### metadata

> **metadata**: [`Icrc21ConsentMessageMetadata`](Icrc21ConsentMessageMetadata.md)

Defined in: [packages/ledger-icrc/src/types/ledger.params.ts:112](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icrc/src/types/ledger.params.ts#L112)
