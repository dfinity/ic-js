---
title: Icrc21ConsentMessageSpec
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icrc/src/types/ledger.params.ts:111](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/types/ledger.params.ts#L111)

Specification for the consent message, including metadata and device preferences.

## Param

Metadata of the consent message.

## Param

Information about the device responsible for presenting the consent message to the user.

## Properties

### deriveSpec?

> `optional` **deriveSpec**: [`Icrc21ConsentMessageDeviceSpec`](../type-aliases/Icrc21ConsentMessageDeviceSpec.md)

Defined in: [packages/ledger-icrc/src/types/ledger.params.ts:113](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/types/ledger.params.ts#L113)

***

### metadata

> **metadata**: [`Icrc21ConsentMessageMetadata`](Icrc21ConsentMessageMetadata.md)

Defined in: [packages/ledger-icrc/src/types/ledger.params.ts:112](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icrc/src/types/ledger.params.ts#L112)
