---
title: AccountIdentifier
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icp/src/account\_identifier.ts:23](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/account_identifier.ts#L23)

A 32-byte account identifier used to send and receive ICP tokens.

The ICP Ledger uses the concept of an `AccountIdentifier` to represent accounts.
It’s a unique value derived from a principal (the identity controlling the account)
and a subaccount. This design allows a single principal to control multiple accounts
by using different subaccounts.

## See

 - https://internetcomputer.org/docs/references/ledger#_accounts
 - https://internetcomputer.org/docs/defi/token-ledgers/setup/icp_ledger_setup
 - https://internetcomputer.org/docs/references/ledger#_operations_transactions_blocks_transaction_ledger

## Methods

### toAccountIdentifierHash()

> **toAccountIdentifierHash**(): `object`

Defined in: [packages/ledger-icp/src/account\_identifier.ts:127](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/account_identifier.ts#L127)

Returns the raw bytes wrapped in an object under the `hash` key.

#### Returns

`object`

`{ hash: Uint8Array }` where `hash` is the raw 32-byte `Uint8Array`.

##### hash

> **hash**: `Uint8Array`

***

### toHex()

> **toHex**(): `string`

Defined in: [packages/ledger-icp/src/account\_identifier.ts:100](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/account_identifier.ts#L100)

Returns the ICP Ledger Account Identifier as a 64-character hexadecimal string.
This is the format typically used to display the account identifier in a human-readable way.

#### Returns

`string`

Hex representation (64-character string).

***

### toNumbers()

> **toNumbers**(): `number`[]

Defined in: [packages/ledger-icp/src/account\_identifier.ts:118](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/account_identifier.ts#L118)

Returns the account identifier as an array of numbers.

#### Returns

`number`[]

An array of byte values.

***

### toUint8Array()

> **toUint8Array**(): `Uint8Array`

Defined in: [packages/ledger-icp/src/account\_identifier.ts:109](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/account_identifier.ts#L109)

Returns the raw 32-byte `Uint8Array` of the account identifier.

#### Returns

`Uint8Array`

The raw bytes of the account identifier.

***

### fromHex()

> `static` **fromHex**(`hex`): `AccountIdentifier`

Defined in: [packages/ledger-icp/src/account\_identifier.ts:34](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/account_identifier.ts#L34)

Creates an `AccountIdentifier` object from a hexadecimal string (e.g. d3e13d4777e22367532053190b6c6ccf57444a61337e996242b1abfb52cf92c8).
Validates the checksum in the process.

#### Parameters

##### hex

`string`

The 64-character hexadecimal representation of the account identifier.

#### Returns

`AccountIdentifier`

An instance of `AccountIdentifier`.

#### Throws

If the length is not 32 bytes or if the checksum is invalid.

***

### fromPrincipal()

> `static` **fromPrincipal**(`__namedParameters`): `AccountIdentifier`

Defined in: [packages/ledger-icp/src/account\_identifier.ts:68](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/account_identifier.ts#L68)

Creates an `AccountIdentifier` object from a principal and optional subaccount.

When no subaccount is provided, a 32-byte array of zeros is used by default.
You can use any arbitrary 32 bytes as a subaccount identifier to derive a distinct account identifier
for the same principal.

#### Parameters

##### \_\_namedParameters

###### principal

`Principal`

###### subAccount?

[`SubAccount`](SubAccount.md) = `...`

#### Returns

`AccountIdentifier`

An instance of `AccountIdentifier`.
