---
title: LedgerCanister
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icp/src/ledger.canister.ts:35](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/ledger.canister.ts#L35)

## Extends

- `Canister`\<`LedgerService`\>

## Constructors

### Constructor

> `protected` **new LedgerCanister**(`id`, `service`, `certifiedService`): `LedgerCanister`

Defined in: packages/utils/dist/services/canister.d.ts:7

#### Parameters

##### id

`Principal`

##### service

`_SERVICE`

##### certifiedService

`_SERVICE`

#### Returns

`LedgerCanister`

#### Inherited from

`Canister<LedgerService>.constructor`

## Properties

### caller()

> `protected` **caller**: (`__namedParameters`) => `_SERVICE`

Defined in: packages/utils/dist/services/canister.d.ts:9

#### Parameters

##### \_\_namedParameters

`QueryParams`

#### Returns

`_SERVICE`

#### Inherited from

`Canister.caller`

***

### certifiedService

> `protected` `readonly` **certifiedService**: `_SERVICE`

Defined in: packages/utils/dist/services/canister.d.ts:6

#### Inherited from

`Canister.certifiedService`

***

### service

> `protected` `readonly` **service**: `_SERVICE`

Defined in: packages/utils/dist/services/canister.d.ts:5

#### Inherited from

`Canister.service`

## Accessors

### canisterId

#### Get Signature

> **get** **canisterId**(): `Principal`

Defined in: packages/utils/dist/services/canister.d.ts:8

##### Returns

`Principal`

#### Inherited from

`Canister.canisterId`

## Methods

### accountBalance()

> **accountBalance**(`params`): `Promise`\<`bigint`\>

Defined in: [packages/ledger-icp/src/ledger.canister.ts:64](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/ledger.canister.ts#L64)

Returns the balance of the specified account identifier.

If `certified` is true, the request is fetched as an update call, otherwise
it is fetched using a query call.

#### Parameters

##### params

`AccountBalanceParams`

The parameters to get the balance of an account.

#### Returns

`Promise`\<`bigint`\>

The balance of the given account.

#### Throws

Error

***

### icrc1Transfer()

> **icrc1Transfer**(`request`): `Promise`\<`bigint`\>

Defined in: [packages/ledger-icp/src/ledger.canister.ts:132](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/ledger.canister.ts#L132)

Transfer ICP from the caller to the destination `Account`.
Returns the index of the block containing the tx if it was successful.

#### Parameters

##### request

[`Icrc1TransferRequest`](../interfaces/Icrc1TransferRequest.md)

#### Returns

`Promise`\<`bigint`\>

#### Throws

[TransferError](TransferError.md)

***

### icrc21ConsentMessage()

> **icrc21ConsentMessage**(`params`): `Promise`\<`icrc21_consent_info`\>

Defined in: [packages/ledger-icp/src/ledger.canister.ts:179](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/ledger.canister.ts#L179)

Fetches the consent message for a specified canister call, intended to provide a human-readable message that helps users make informed decisions.

@link: https://github.com/dfinity/wg-identity-authentication/blob/main/topics/ICRC-21/icrc_21_consent_msg.md

#### Parameters

##### params

`Icrc21ConsentMessageRequest`

The request parameters containing the method name, arguments, and consent preferences (e.g., language).

#### Returns

`Promise`\<`icrc21_consent_info`\>

- A promise that resolves to the consent message response, which includes the consent message in the specified language and other related information.

#### Throws

- This error is reserved for future use, in case payment extensions are introduced. For example, if consent messages, which are currently free, begin to require payments.

#### Throws

- If the specified canister call is not supported.

#### Throws

- If there is no consent message available.

#### Throws

- For any other generic errors.

***

### icrc2Approve()

> **icrc2Approve**(`params`): `Promise`\<`bigint`\>

Defined in: [packages/ledger-icp/src/ledger.canister.ts:152](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/ledger.canister.ts#L152)

This method entitles the `spender` to transfer token `amount` on behalf of the caller from account `{ owner = caller; subaccount = from_subaccount }`.

Reference: https://github.com/dfinity/ICRC-1/blob/main/standards/ICRC-2/index.md#icrc2_approve

#### Parameters

##### params

[`Icrc2ApproveRequest`](../type-aliases/Icrc2ApproveRequest.md)

The parameters to approve.

#### Returns

`Promise`\<`bigint`\>

The block index of the approved transaction.

#### Throws

If the approval fails.

***

### metadata()

> **metadata**(`params`): `Promise`\<\[`string`, [`Value`](../type-aliases/Value.md)\][]\>

Defined in: [packages/ledger-icp/src/ledger.canister.ts:83](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/ledger.canister.ts#L83)

Fetches the ledger metadata.

#### Parameters

##### params

`QueryParams`

The parameters used to fetch the metadata, notably query or certified call.

#### Returns

`Promise`\<\[`string`, [`Value`](../type-aliases/Value.md)\][]\>

The metadata of the ICP ledger. A promise that resolves to an array of metadata entries, where each entry is a tuple consisting of a string and a value.

***

### transactionFee()

> **transactionFee**(`params?`): `Promise`\<`bigint`\>

Defined in: [packages/ledger-icp/src/ledger.canister.ts:94](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/ledger.canister.ts#L94)

Returns the transaction fee of the ICP ledger canister.

#### Parameters

##### params?

`QueryParams` = `...`

Optional query parameters for the request, defaulting to `{ certified: false }` for backwards compatibility reason.

#### Returns

`Promise`\<`bigint`\>

A promise that resolves to the transaction fee as a bigint.

***

### transfer()

> **transfer**(`request`): `Promise`\<`bigint`\>

Defined in: [packages/ledger-icp/src/ledger.canister.ts:112](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/ledger.canister.ts#L112)

Transfer ICP from the caller to the destination `accountIdentifier`.
Returns the index of the block containing the tx if it was successful.

#### Parameters

##### request

[`TransferRequest`](../interfaces/TransferRequest.md)

#### Returns

`Promise`\<`bigint`\>

#### Throws

[TransferError](TransferError.md)

***

### create()

> `static` **create**(`options`): `LedgerCanister`

Defined in: [packages/ledger-icp/src/ledger.canister.ts:36](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/ledger.canister.ts#L36)

#### Parameters

##### options

[`LedgerCanisterOptions`](../type-aliases/LedgerCanisterOptions.md) = `{}`

#### Returns

`LedgerCanister`
