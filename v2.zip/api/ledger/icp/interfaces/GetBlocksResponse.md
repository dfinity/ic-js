---
title: GetBlocksResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icp/src/candid/index.d.ts:53](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/candid/index.d.ts#L53)

## Properties

### blocks

> **blocks**: `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/ledger-icp/src/candid/index.d.ts:54](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/candid/index.d.ts#L54)

***

### chain\_length

> **chain\_length**: `bigint`

Defined in: [packages/ledger-icp/src/candid/index.d.ts:55](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/candid/index.d.ts#L55)
