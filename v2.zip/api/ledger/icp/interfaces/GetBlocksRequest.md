---
title: GetBlocksRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icp/src/candid/index.d.ts:49](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/index.d.ts#L49)

## Properties

### length

> **length**: `bigint`

Defined in: [packages/ledger-icp/src/candid/index.d.ts:51](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/index.d.ts#L51)

***

### start

> **start**: `bigint`

Defined in: [packages/ledger-icp/src/candid/index.d.ts:50](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/index.d.ts#L50)
