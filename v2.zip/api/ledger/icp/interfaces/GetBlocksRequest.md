---
title: GetBlocksRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icp/src/candid/index.d.ts:49](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/candid/index.d.ts#L49)

## Properties

### length

> **length**: `bigint`

Defined in: [packages/ledger-icp/src/candid/index.d.ts:51](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/candid/index.d.ts#L51)

***

### start

> **start**: `bigint`

Defined in: [packages/ledger-icp/src/candid/index.d.ts:50](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/candid/index.d.ts#L50)
