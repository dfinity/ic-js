---
title: GetAccountIdentifierTransactionsError
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icp/src/candid/index.d.ts:22](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icp/src/candid/index.d.ts#L22)

## Properties

### message

> **message**: `string`

Defined in: [packages/ledger-icp/src/candid/index.d.ts:23](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icp/src/candid/index.d.ts#L23)
