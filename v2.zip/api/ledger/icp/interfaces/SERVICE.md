---
title: _SERVICE
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icp/src/candid/index.d.ts:115](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icp/src/candid/index.d.ts#L115)

## Properties

### get\_account\_identifier\_balance

> **get\_account\_identifier\_balance**: `ActorMethod`\<\[`string`\], `bigint`\>

Defined in: [packages/ledger-icp/src/candid/index.d.ts:116](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icp/src/candid/index.d.ts#L116)

***

### get\_account\_identifier\_transactions

> **get\_account\_identifier\_transactions**: `ActorMethod`\<\[[`GetAccountIdentifierTransactionsArgs`](GetAccountIdentifierTransactionsArgs.md)\], [`GetAccountIdentifierTransactionsResult`](../type-aliases/GetAccountIdentifierTransactionsResult.md)\>

Defined in: [packages/ledger-icp/src/candid/index.d.ts:117](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icp/src/candid/index.d.ts#L117)

***

### get\_account\_transactions

> **get\_account\_transactions**: `ActorMethod`\<\[[`GetAccountTransactionsArgs`](GetAccountTransactionsArgs.md)\], [`GetAccountIdentifierTransactionsResult`](../type-aliases/GetAccountIdentifierTransactionsResult.md)\>

Defined in: [packages/ledger-icp/src/candid/index.d.ts:121](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icp/src/candid/index.d.ts#L121)

***

### get\_blocks

> **get\_blocks**: `ActorMethod`\<\[[`GetBlocksRequest`](GetBlocksRequest.md)\], [`GetBlocksResponse`](GetBlocksResponse.md)\>

Defined in: [packages/ledger-icp/src/candid/index.d.ts:125](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icp/src/candid/index.d.ts#L125)

***

### http\_request

> **http\_request**: `ActorMethod`\<\[[`HttpRequest`](HttpRequest.md)\], [`HttpResponse`](HttpResponse.md)\>

Defined in: [packages/ledger-icp/src/candid/index.d.ts:126](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icp/src/candid/index.d.ts#L126)

***

### icrc1\_balance\_of

> **icrc1\_balance\_of**: `ActorMethod`\<\[[`Account`](Account.md)\], `bigint`\>

Defined in: [packages/ledger-icp/src/candid/index.d.ts:127](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icp/src/candid/index.d.ts#L127)

***

### ledger\_id

> **ledger\_id**: `ActorMethod`\<\[\], `Principal`\>

Defined in: [packages/ledger-icp/src/candid/index.d.ts:128](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icp/src/candid/index.d.ts#L128)

***

### status

> **status**: `ActorMethod`\<\[\], [`Status`](Status.md)\>

Defined in: [packages/ledger-icp/src/candid/index.d.ts:129](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icp/src/candid/index.d.ts#L129)
