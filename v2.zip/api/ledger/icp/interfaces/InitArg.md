---
title: InitArg
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icp/src/candid/index.d.ts:68](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/candid/index.d.ts#L68)

## Properties

### ledger\_id

> **ledger\_id**: `Principal`

Defined in: [packages/ledger-icp/src/candid/index.d.ts:69](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/candid/index.d.ts#L69)
