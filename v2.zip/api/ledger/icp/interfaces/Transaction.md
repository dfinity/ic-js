---
title: Transaction
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icp/src/candid/index.d.ts:104](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/index.d.ts#L104)

## Properties

### created\_at\_time

> **created\_at\_time**: \[\] \| \[[`TimeStamp`](TimeStamp.md)\]

Defined in: [packages/ledger-icp/src/candid/index.d.ts:109](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/index.d.ts#L109)

***

### icrc1\_memo

> **icrc1\_memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/ledger-icp/src/candid/index.d.ts:106](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/index.d.ts#L106)

***

### memo

> **memo**: `bigint`

Defined in: [packages/ledger-icp/src/candid/index.d.ts:105](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/index.d.ts#L105)

***

### operation

> **operation**: [`Operation`](../type-aliases/Operation.md)

Defined in: [packages/ledger-icp/src/candid/index.d.ts:107](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/index.d.ts#L107)

***

### timestamp

> **timestamp**: \[\] \| \[[`TimeStamp`](TimeStamp.md)\]

Defined in: [packages/ledger-icp/src/candid/index.d.ts:108](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/index.d.ts#L108)
