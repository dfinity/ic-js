---
title: Icrc1TransferRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icp/src/types/ledger\_converters.ts:29](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/types/ledger_converters.ts#L29)

## Properties

### amount

> **amount**: `bigint`

Defined in: [packages/ledger-icp/src/types/ledger\_converters.ts:31](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/types/ledger_converters.ts#L31)

***

### createdAt?

> `optional` **createdAt**: `bigint`

Defined in: [packages/ledger-icp/src/types/ledger\_converters.ts:38](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/types/ledger_converters.ts#L38)

***

### fee?

> `optional` **fee**: `bigint`

Defined in: [packages/ledger-icp/src/types/ledger\_converters.ts:33](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/types/ledger_converters.ts#L33)

***

### fromSubAccount?

> `optional` **fromSubAccount**: [`Icrc1SubAccount`](../type-aliases/Icrc1SubAccount.md)

Defined in: [packages/ledger-icp/src/types/ledger\_converters.ts:34](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/types/ledger_converters.ts#L34)

***

### icrc1Memo?

> `optional` **icrc1Memo**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/ledger-icp/src/types/ledger\_converters.ts:32](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/types/ledger_converters.ts#L32)

***

### to

> **to**: [`Icrc1Account`](Icrc1Account.md)

Defined in: [packages/ledger-icp/src/types/ledger\_converters.ts:30](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/types/ledger_converters.ts#L30)
