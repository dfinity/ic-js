---
title: HttpResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icp/src/candid/index.d.ts:63](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/candid/index.d.ts#L63)

## Properties

### body

> **body**: `Uint8Array`

Defined in: [packages/ledger-icp/src/candid/index.d.ts:64](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/candid/index.d.ts#L64)

***

### headers

> **headers**: \[`string`, `string`\][]

Defined in: [packages/ledger-icp/src/candid/index.d.ts:65](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/candid/index.d.ts#L65)

***

### status\_code

> **status\_code**: `number`

Defined in: [packages/ledger-icp/src/candid/index.d.ts:66](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/candid/index.d.ts#L66)
