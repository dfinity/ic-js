---
title: HttpResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icp/src/candid/index.d.ts:63](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/index.d.ts#L63)

## Properties

### body

> **body**: `Uint8Array`

Defined in: [packages/ledger-icp/src/candid/index.d.ts:64](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/index.d.ts#L64)

***

### headers

> **headers**: \[`string`, `string`\][]

Defined in: [packages/ledger-icp/src/candid/index.d.ts:65](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/index.d.ts#L65)

***

### status\_code

> **status\_code**: `number`

Defined in: [packages/ledger-icp/src/candid/index.d.ts:66](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/index.d.ts#L66)
