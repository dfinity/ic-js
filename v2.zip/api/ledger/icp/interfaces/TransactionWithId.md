---
title: TransactionWithId
editUrl: false
next: true
prev: true
---

Defined in: [packages/ledger-icp/src/candid/index.d.ts:111](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/index.d.ts#L111)

## Properties

### id

> **id**: `bigint`

Defined in: [packages/ledger-icp/src/candid/index.d.ts:112](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/index.d.ts#L112)

***

### transaction

> **transaction**: [`Transaction`](Transaction.md)

Defined in: [packages/ledger-icp/src/candid/index.d.ts:113](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/index.d.ts#L113)
