---
title: init
editUrl: false
next: true
prev: true
---

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/ledger-icp/src/candid/index.d.ts:132](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/candid/index.d.ts#L132)

## Parameters

### args

#### IDL

*typeof* `IDL`

## Returns

`IDL.Type`[]
