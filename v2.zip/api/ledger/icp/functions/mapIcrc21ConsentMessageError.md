---
title: mapIcrc21ConsentMessageError
editUrl: false
next: true
prev: true
---

> **mapIcrc21ConsentMessageError**(`rawError`): [`ConsentMessageError`](../classes/ConsentMessageError.md)

Defined in: [packages/ledger-icp/src/errors/ledger.errors.ts:194](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/errors/ledger.errors.ts#L194)

## Parameters

### rawError

`icrc21_error`

## Returns

[`ConsentMessageError`](../classes/ConsentMessageError.md)
