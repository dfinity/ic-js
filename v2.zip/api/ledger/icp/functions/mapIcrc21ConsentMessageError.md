---
title: mapIcrc21ConsentMessageError
editUrl: false
next: true
prev: true
---

> **mapIcrc21ConsentMessageError**(`rawError`): [`ConsentMessageError`](../classes/ConsentMessageError.md)

Defined in: [packages/ledger-icp/src/errors/ledger.errors.ts:194](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icp/src/errors/ledger.errors.ts#L194)

## Parameters

### rawError

`icrc21_error`

## Returns

[`ConsentMessageError`](../classes/ConsentMessageError.md)
