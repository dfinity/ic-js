---
title: toTransferRawRequest
editUrl: false
next: true
prev: true
---

> **toTransferRawRequest**(`__namedParameters`): `TransferArgs`

Defined in: [packages/ledger-icp/src/canisters/ledger/ledger.request.converts.ts:23](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icp/src/canisters/ledger/ledger.request.converts.ts#L23)

## Parameters

### \_\_namedParameters

[`TransferRequest`](../interfaces/TransferRequest.md)

## Returns

`TransferArgs`
