---
title: toTransferRawRequest
editUrl: false
next: true
prev: true
---

> **toTransferRawRequest**(`__namedParameters`): `TransferArgs`

Defined in: [packages/ledger-icp/src/canisters/ledger/ledger.request.converts.ts:23](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/canisters/ledger/ledger.request.converts.ts#L23)

## Parameters

### \_\_namedParameters

[`TransferRequest`](../interfaces/TransferRequest.md)

## Returns

`TransferArgs`
