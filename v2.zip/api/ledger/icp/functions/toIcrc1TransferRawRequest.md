---
title: toIcrc1TransferRawRequest
editUrl: false
next: true
prev: true
---

> **toIcrc1TransferRawRequest**(`__namedParameters`): `TransferArg`

Defined in: [packages/ledger-icp/src/canisters/ledger/ledger.request.converts.ts:49](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/canisters/ledger/ledger.request.converts.ts#L49)

## Parameters

### \_\_namedParameters

[`Icrc1TransferRequest`](../interfaces/Icrc1TransferRequest.md)

## Returns

`TransferArg`
