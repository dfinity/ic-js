---
title: toIcrc1TransferRawRequest
editUrl: false
next: true
prev: true
---

> **toIcrc1TransferRawRequest**(`__namedParameters`): `TransferArg`

Defined in: [packages/ledger-icp/src/canisters/ledger/ledger.request.converts.ts:49](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/canisters/ledger/ledger.request.converts.ts#L49)

## Parameters

### \_\_namedParameters

[`Icrc1TransferRequest`](../interfaces/Icrc1TransferRequest.md)

## Returns

`TransferArg`
