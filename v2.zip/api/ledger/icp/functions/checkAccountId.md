---
title: checkAccountId
editUrl: false
next: true
prev: true
---

> **checkAccountId**(`accountId`): `void`

Defined in: [packages/ledger-icp/src/utils/accounts.utils.ts:15](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/utils/accounts.utils.ts#L15)

Checks account id check sum

## Parameters

### accountId

`string`

## Returns

`void`

## Throws

InvalidAccountIDError
