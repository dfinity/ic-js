---
title: toIcrc2ApproveRawRequest
editUrl: false
next: true
prev: true
---

> **toIcrc2ApproveRawRequest**(`__namedParameters`): `ApproveArgs`

Defined in: [packages/ledger-icp/src/canisters/ledger/ledger.request.converts.ts:65](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/canisters/ledger/ledger.request.converts.ts#L65)

## Parameters

### \_\_namedParameters

[`Icrc2ApproveRequest`](../type-aliases/Icrc2ApproveRequest.md)

## Returns

`ApproveArgs`
