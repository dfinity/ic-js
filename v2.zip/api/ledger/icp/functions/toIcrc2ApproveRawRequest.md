---
title: toIcrc2ApproveRawRequest
editUrl: false
next: true
prev: true
---

> **toIcrc2ApproveRawRequest**(`__namedParameters`): `ApproveArgs`

Defined in: [packages/ledger-icp/src/canisters/ledger/ledger.request.converts.ts:65](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/canisters/ledger/ledger.request.converts.ts#L65)

## Parameters

### \_\_namedParameters

[`Icrc2ApproveRequest`](../type-aliases/Icrc2ApproveRequest.md)

## Returns

`ApproveArgs`
