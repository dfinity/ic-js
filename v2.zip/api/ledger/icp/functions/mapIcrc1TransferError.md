---
title: mapIcrc1TransferError
editUrl: false
next: true
prev: true
---

> **mapIcrc1TransferError**(`rawTransferError`): [`TransferError`](../classes/TransferError.md)

Defined in: [packages/ledger-icp/src/errors/ledger.errors.ts:111](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/errors/ledger.errors.ts#L111)

## Parameters

### rawTransferError

[`Icrc1TransferError`](../type-aliases/Icrc1TransferError.md)

## Returns

[`TransferError`](../classes/TransferError.md)
