---
title: mapIcrc1TransferError
editUrl: false
next: true
prev: true
---

> **mapIcrc1TransferError**(`rawTransferError`): [`TransferError`](../classes/TransferError.md)

Defined in: [packages/ledger-icp/src/errors/ledger.errors.ts:111](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icp/src/errors/ledger.errors.ts#L111)

## Parameters

### rawTransferError

[`Icrc1TransferError`](../type-aliases/Icrc1TransferError.md)

## Returns

[`TransferError`](../classes/TransferError.md)
