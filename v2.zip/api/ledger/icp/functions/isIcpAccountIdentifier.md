---
title: isIcpAccountIdentifier
editUrl: false
next: true
prev: true
---

> **isIcpAccountIdentifier**(`address`): `boolean`

Defined in: [packages/ledger-icp/src/utils/accounts.utils.ts:41](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icp/src/utils/accounts.utils.ts#L41)

Checks if a given string (or undefined) is a valid ICP account identifier.

It uses the `checkAccountId` function to validate the checksum, but it does not throw an error.

## Parameters

### address

The putative ICP account identifier.

`string` | `undefined`

## Returns

`boolean`
