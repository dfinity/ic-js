---
title: mapTransferError
editUrl: false
next: true
prev: true
---

> **mapTransferError**(`rawTransferError`): [`TransferError`](../classes/TransferError.md)

Defined in: [packages/ledger-icp/src/errors/ledger.errors.ts:83](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/errors/ledger.errors.ts#L83)

## Parameters

### rawTransferError

`TransferError`

## Returns

[`TransferError`](../classes/TransferError.md)
