---
title: mapTransferError
editUrl: false
next: true
prev: true
---

> **mapTransferError**(`rawTransferError`): [`TransferError`](../classes/TransferError.md)

Defined in: [packages/ledger-icp/src/errors/ledger.errors.ts:83](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/errors/ledger.errors.ts#L83)

## Parameters

### rawTransferError

`TransferError`

## Returns

[`TransferError`](../classes/TransferError.md)
