---
title: toIcrc21ConsentMessageRawRequest
editUrl: false
next: true
prev: true
---

> **toIcrc21ConsentMessageRawRequest**(`__namedParameters`): `icrc21_consent_message_request`

Defined in: [packages/ledger-icp/src/canisters/ledger/ledger.request.converts.ts:85](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/canisters/ledger/ledger.request.converts.ts#L85)

## Parameters

### \_\_namedParameters

`Icrc21ConsentMessageRequest`

## Returns

`icrc21_consent_message_request`
