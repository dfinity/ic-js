---
title: toIcrc21ConsentMessageRawRequest
editUrl: false
next: true
prev: true
---

> **toIcrc21ConsentMessageRawRequest**(`__namedParameters`): `icrc21_consent_message_request`

Defined in: [packages/ledger-icp/src/canisters/ledger/ledger.request.converts.ts:85](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icp/src/canisters/ledger/ledger.request.converts.ts#L85)

## Parameters

### \_\_namedParameters

`Icrc21ConsentMessageRequest`

## Returns

`icrc21_consent_message_request`
