---
title: Icrc2ApproveResult
editUrl: false
next: true
prev: true
---

> **Icrc2ApproveResult** = \{ `Ok`: [`Icrc1BlockIndex`](Icrc1BlockIndex.md); \} \| \{ `Err`: [`Icrc1ApproveError`](Icrc1ApproveError.md); \}

Defined in: [packages/ledger-icp/src/candid/ledger.d.ts:70](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/candid/ledger.d.ts#L70)
