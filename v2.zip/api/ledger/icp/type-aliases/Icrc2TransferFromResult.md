---
title: Icrc2TransferFromResult
editUrl: false
next: true
prev: true
---

> **Icrc2TransferFromResult** = \{ `Ok`: [`Icrc1BlockIndex`](Icrc1BlockIndex.md); \} \| \{ `Err`: [`Icrc2TransferFromError`](Icrc2TransferFromError.md); \}

Defined in: [packages/ledger-icp/src/candid/ledger.d.ts:498](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/ledger.d.ts#L498)
