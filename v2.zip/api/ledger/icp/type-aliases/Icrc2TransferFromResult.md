---
title: Icrc2TransferFromResult
editUrl: false
next: true
prev: true
---

> **Icrc2TransferFromResult** = \{ `Ok`: [`Icrc1BlockIndex`](Icrc1BlockIndex.md); \} \| \{ `Err`: [`Icrc2TransferFromError`](Icrc2TransferFromError.md); \}

Defined in: [packages/ledger-icp/src/candid/ledger.d.ts:498](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/candid/ledger.d.ts#L498)
