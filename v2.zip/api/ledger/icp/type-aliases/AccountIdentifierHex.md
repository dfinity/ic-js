---
title: AccountIdentifierHex
editUrl: false
next: true
prev: true
---

> **AccountIdentifierHex** = `string`

Defined in: [packages/ledger-icp/src/types/common.ts:1](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/types/common.ts#L1)
