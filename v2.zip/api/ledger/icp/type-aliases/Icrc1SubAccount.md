---
title: Icrc1SubAccount
editUrl: false
next: true
prev: true
---

> **Icrc1SubAccount** = `Uint8Array`

Defined in: [packages/ledger-icp/src/candid/ledger.d.ts:364](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/ledger.d.ts#L364)

Subaccount is an arbitrary 32-byte byte array.
Ledger uses subaccounts to compute the source address, which enables one
principal to control multiple ledger accounts.
