---
title: Icrc1SubAccount
editUrl: false
next: true
prev: true
---

> **Icrc1SubAccount** = `Uint8Array`

Defined in: [packages/ledger-icp/src/candid/ledger.d.ts:364](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icp/src/candid/ledger.d.ts#L364)

Subaccount is an arbitrary 32-byte byte array.
Ledger uses subaccounts to compute the source address, which enables one
principal to control multiple ledger accounts.
