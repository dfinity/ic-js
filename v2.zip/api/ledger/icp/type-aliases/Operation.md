---
title: Operation
editUrl: false
next: true
prev: true
---

> **Operation** = \{ `Approve`: \{ `allowance`: [`Tokens`](../interfaces/Tokens.md); `expected_allowance`: \[\] \| \[[`Tokens`](../interfaces/Tokens.md)\]; `expires_at`: \[\] \| \[[`TimeStamp`](../interfaces/TimeStamp.md)\]; `fee`: [`Tokens`](../interfaces/Tokens.md); `from`: `string`; `spender`: `string`; \}; \} \| \{ `Burn`: \{ `amount`: [`Tokens`](../interfaces/Tokens.md); `from`: `string`; `spender`: \[\] \| \[`string`\]; \}; \} \| \{ `Mint`: \{ `amount`: [`Tokens`](../interfaces/Tokens.md); `to`: `string`; \}; \} \| \{ `Transfer`: \{ `amount`: [`Tokens`](../interfaces/Tokens.md); `fee`: [`Tokens`](../interfaces/Tokens.md); `from`: `string`; `spender`: \[\] \| \[`string`\]; `to`: `string`; \}; \}

Defined in: [packages/ledger-icp/src/candid/index.d.ts:71](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/index.d.ts#L71)
