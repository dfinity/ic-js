---
title: Operation
editUrl: false
next: true
prev: true
---

> **Operation** = \{ `Approve`: \{ `allowance`: [`Tokens`](../interfaces/Tokens.md); `expected_allowance`: \[\] \| \[[`Tokens`](../interfaces/Tokens.md)\]; `expires_at`: \[\] \| \[[`TimeStamp`](../interfaces/TimeStamp.md)\]; `fee`: [`Tokens`](../interfaces/Tokens.md); `from`: `string`; `spender`: `string`; \}; \} \| \{ `Burn`: \{ `amount`: [`Tokens`](../interfaces/Tokens.md); `from`: `string`; `spender`: \[\] \| \[`string`\]; \}; \} \| \{ `Mint`: \{ `amount`: [`Tokens`](../interfaces/Tokens.md); `to`: `string`; \}; \} \| \{ `Transfer`: \{ `amount`: [`Tokens`](../interfaces/Tokens.md); `fee`: [`Tokens`](../interfaces/Tokens.md); `from`: `string`; `spender`: \[\] \| \[`string`\]; `to`: `string`; \}; \}

Defined in: [packages/ledger-icp/src/candid/index.d.ts:71](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/candid/index.d.ts#L71)
