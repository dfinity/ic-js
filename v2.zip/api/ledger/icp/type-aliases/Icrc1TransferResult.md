---
title: Icrc1TransferResult
editUrl: false
next: true
prev: true
---

> **Icrc1TransferResult** = \{ `Ok`: [`Icrc1BlockIndex`](Icrc1BlockIndex.md); \} \| \{ `Err`: [`Icrc1TransferError`](Icrc1TransferError.md); \}

Defined in: [packages/ledger-icp/src/candid/ledger.d.ts:187](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ledger-icp/src/candid/ledger.d.ts#L187)
