---
title: Icrc1TransferResult
editUrl: false
next: true
prev: true
---

> **Icrc1TransferResult** = \{ `Ok`: [`Icrc1BlockIndex`](Icrc1BlockIndex.md); \} \| \{ `Err`: [`Icrc1TransferError`](Icrc1TransferError.md); \}

Defined in: [packages/ledger-icp/src/candid/ledger.d.ts:187](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icp/src/candid/ledger.d.ts#L187)
