---
title: Icrc1Timestamp
editUrl: false
next: true
prev: true
---

> **Icrc1Timestamp** = `bigint`

Defined in: [packages/ledger-icp/src/candid/ledger.d.ts:174](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/candid/ledger.d.ts#L174)

Number of nanoseconds since the UNIX epoch in UTC timezone.
