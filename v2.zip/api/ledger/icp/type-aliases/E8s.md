---
title: E8s
editUrl: false
next: true
prev: true
---

> **E8s** = `bigint`

Defined in: [packages/ledger-icp/src/types/common.ts:3](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ledger-icp/src/types/common.ts#L3)
