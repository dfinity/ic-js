---
title: E8s
editUrl: false
next: true
prev: true
---

> **E8s** = `bigint`

Defined in: [packages/ledger-icp/src/types/common.ts:3](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ledger-icp/src/types/common.ts#L3)
