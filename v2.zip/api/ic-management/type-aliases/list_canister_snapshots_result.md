---
title: list_canister_snapshots_result
editUrl: false
next: true
prev: true
---

> **list\_canister\_snapshots\_result** = [`snapshot`](../interfaces/snapshot.md)[]

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:260](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/candid/ic-management.d.ts#L260)
