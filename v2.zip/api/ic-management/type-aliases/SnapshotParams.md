---
title: SnapshotParams
editUrl: false
next: true
prev: true
---

> **SnapshotParams** = `Required`\<[`OptionSnapshotParams`](../interfaces/OptionSnapshotParams.md)\>

Defined in: [packages/ic-management/src/types/snapshot.params.ts:21](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/types/snapshot.params.ts#L21)
