---
title: SnapshotIdText
editUrl: false
next: true
prev: true
---

> **SnapshotIdText** = `string`

Defined in: [packages/ic-management/src/types/snapshot.params.ts:14](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/types/snapshot.params.ts#L14)
