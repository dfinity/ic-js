---
title: SnapshotIdText
editUrl: false
next: true
prev: true
---

> **SnapshotIdText** = `string`

Defined in: [packages/ic-management/src/types/snapshot.params.ts:14](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/types/snapshot.params.ts#L14)
