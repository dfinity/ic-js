---
title: FetchCanisterLogsResponse
editUrl: false
next: true
prev: true
---

> **FetchCanisterLogsResponse** = `ServiceResponse`\<`IcManagementService`, `"fetch_canister_logs"`\>

Defined in: [packages/ic-management/src/types/ic-management.responses.ts:9](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/types/ic-management.responses.ts#L9)
