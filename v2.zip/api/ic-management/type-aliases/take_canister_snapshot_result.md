---
title: take_canister_snapshot_result
editUrl: false
next: true
prev: true
---

> **take\_canister\_snapshot\_result** = [`snapshot`](../interfaces/snapshot.md)

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:399](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/candid/ic-management.d.ts#L399)
