---
title: snapshot_id
editUrl: false
next: true
prev: true
---

> **snapshot\_id** = `Uint8Array`

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:377](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/candid/ic-management.d.ts#L377)
