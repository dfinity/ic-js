---
title: UploadCanisterSnapshotMetadataParam
editUrl: false
next: true
prev: true
---

> **UploadCanisterSnapshotMetadataParam** = `Pick`\<[`ReadCanisterSnapshotMetadataResponse`](../interfaces/ReadCanisterSnapshotMetadataResponse.md), `"globals"` \| `"certifiedData"` \| `"globalTimer"` \| `"onLowWasmMemoryHookStatus"` \| `"wasmModuleSize"` \| `"stableMemorySize"` \| `"wasmMemorySize"`\>

Defined in: [packages/ic-management/src/types/snapshot.params.ts:73](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/types/snapshot.params.ts#L73)
