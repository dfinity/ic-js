---
title: canister_install_mode
editUrl: false
next: true
prev: true
---

> **canister\_install\_mode** = \{ `reinstall`: `null`; \} \| \{ `upgrade`: \[\] \| \[\{ `skip_pre_upgrade`: \[\] \| \[`boolean`\]; `wasm_memory_persistence`: \[\] \| \[\{ `keep`: `null`; \} \| \{ `replace`: `null`; \}\]; \}\]; \} \| \{ `install`: `null`; \}

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:63](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/candid/ic-management.d.ts#L63)
