---
title: canister_install_mode
editUrl: false
next: true
prev: true
---

> **canister\_install\_mode** = \{ `reinstall`: `null`; \} \| \{ `upgrade`: \[\] \| \[\{ `skip_pre_upgrade`: \[\] \| \[`boolean`\]; `wasm_memory_persistence`: \[\] \| \[\{ `keep`: `null`; \} \| \{ `replace`: `null`; \}\]; \}\]; \} \| \{ `install`: `null`; \}

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:63](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/candid/ic-management.d.ts#L63)
