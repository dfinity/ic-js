---
title: UploadCanisterSnapshotDataKind
editUrl: false
next: true
prev: true
---

> **UploadCanisterSnapshotDataKind** = \{ `wasmModule`: \{ `offset`: `bigint`; \}; \} \| \{ `wasmMemory`: \{ `offset`: `bigint`; \}; \} \| \{ `stableMemory`: \{ `offset`: `bigint`; \}; \} \| \{ `wasmChunk`: `null`; \}

Defined in: [packages/ic-management/src/types/snapshot.params.ts:128](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/types/snapshot.params.ts#L128)
