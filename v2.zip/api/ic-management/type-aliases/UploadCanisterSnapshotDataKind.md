---
title: UploadCanisterSnapshotDataKind
editUrl: false
next: true
prev: true
---

> **UploadCanisterSnapshotDataKind** = \{ `wasmModule`: \{ `offset`: `bigint`; \}; \} \| \{ `wasmMemory`: \{ `offset`: `bigint`; \}; \} \| \{ `stableMemory`: \{ `offset`: `bigint`; \}; \} \| \{ `wasmChunk`: `null`; \}

Defined in: [packages/ic-management/src/types/snapshot.params.ts:128](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/types/snapshot.params.ts#L128)
