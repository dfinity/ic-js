---
title: UploadChunkParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/ic-management/src/types/ic-management.params.ts:85](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/types/ic-management.params.ts#L85)

## Extends

- `Pick`\<`upload_chunk_args`, `"chunk"`\>

## Properties

### canisterId

> **canisterId**: `Principal`

Defined in: [packages/ic-management/src/types/ic-management.params.ts:86](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/types/ic-management.params.ts#L86)

***

### chunk

> **chunk**: `Uint8Array`

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:446](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/candid/ic-management.d.ts#L446)

#### Inherited from

`Pick.chunk`
