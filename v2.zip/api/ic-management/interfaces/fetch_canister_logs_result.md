---
title: fetch_canister_logs_result
editUrl: false
next: true
prev: true
---

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:220](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/candid/ic-management.d.ts#L220)

## Properties

### canister\_log\_records

> **canister\_log\_records**: [`canister_log_record`](canister_log_record.md)[]

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:221](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/candid/ic-management.d.ts#L221)
