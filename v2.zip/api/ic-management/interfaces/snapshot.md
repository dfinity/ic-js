---
title: snapshot
editUrl: false
next: true
prev: true
---

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:372](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/candid/ic-management.d.ts#L372)

## Properties

### id

> **id**: [`snapshot_id`](../type-aliases/snapshot_id.md)

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:373](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/candid/ic-management.d.ts#L373)

***

### taken\_at\_timestamp

> **taken\_at\_timestamp**: `bigint`

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:375](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/candid/ic-management.d.ts#L375)

***

### total\_size

> **total\_size**: `bigint`

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:374](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/candid/ic-management.d.ts#L374)
