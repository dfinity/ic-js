---
title: UpdateSettingsParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/ic-management/src/types/ic-management.params.ts:71](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/types/ic-management.params.ts#L71)

## Properties

### canisterId

> **canisterId**: `Principal`

Defined in: [packages/ic-management/src/types/ic-management.params.ts:72](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/types/ic-management.params.ts#L72)

***

### senderCanisterVersion?

> `optional` **senderCanisterVersion**: `bigint`

Defined in: [packages/ic-management/src/types/ic-management.params.ts:73](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/types/ic-management.params.ts#L73)

***

### settings

> **settings**: [`CanisterSettings`](CanisterSettings.md)

Defined in: [packages/ic-management/src/types/ic-management.params.ts:74](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/types/ic-management.params.ts#L74)
