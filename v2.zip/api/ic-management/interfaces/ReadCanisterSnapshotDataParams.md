---
title: ReadCanisterSnapshotDataParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/ic-management/src/types/snapshot.params.ts:47](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/types/snapshot.params.ts#L47)

## Extends

- [`SnapshotParams`](../type-aliases/SnapshotParams.md)

## Properties

### canisterId

> **canisterId**: `Principal`

Defined in: [packages/ic-management/src/types/snapshot.params.ts:17](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/types/snapshot.params.ts#L17)

#### Inherited from

[`OptionSnapshotParams`](OptionSnapshotParams.md).[`canisterId`](OptionSnapshotParams.md#canisterid)

***

### kind

> **kind**: [`CanisterSnapshotMetadataKind`](../type-aliases/CanisterSnapshotMetadataKind.md)

Defined in: [packages/ic-management/src/types/snapshot.params.ts:48](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/types/snapshot.params.ts#L48)

***

### snapshotId

> **snapshotId**: `string` \| [`snapshot_id`](../type-aliases/snapshot_id.md)

Defined in: [packages/ic-management/src/types/snapshot.params.ts:18](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/types/snapshot.params.ts#L18)

#### Inherited from

[`OptionSnapshotParams`](OptionSnapshotParams.md).[`snapshotId`](OptionSnapshotParams.md#snapshotid)
