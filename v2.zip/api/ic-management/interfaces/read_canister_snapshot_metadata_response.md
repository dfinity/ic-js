---
title: read_canister_snapshot_metadata_response
editUrl: false
next: true
prev: true
---

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:318](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/candid/ic-management.d.ts#L318)

## Properties

### canister\_version

> **canister\_version**: `bigint`

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:326](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/candid/ic-management.d.ts#L326)

***

### certified\_data

> **certified\_data**: `Uint8Array`

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:328](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/candid/ic-management.d.ts#L328)

***

### global\_timer

> **global\_timer**: \[\] \| \[\{ `active`: `bigint`; \} \| \{ `inactive`: `null`; \}\]

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:329](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/candid/ic-management.d.ts#L329)

***

### globals

> **globals**: (\{ `f32`: `number`; \} \| \{ `f64`: `number`; \} \| \{ `i32`: `number`; \} \| \{ `i64`: `bigint`; \} \| \{ `v128`: `bigint`; \})[]

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:319](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/candid/ic-management.d.ts#L319)

***

### on\_low\_wasm\_memory\_hook\_status

> **on\_low\_wasm\_memory\_hook\_status**: \[\] \| \[\{ `condition_not_satisfied`: `null`; \} \| \{ `executed`: `null`; \} \| \{ `ready`: `null`; \}\]

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:330](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/candid/ic-management.d.ts#L330)

***

### source

> **source**: \{ `metadata_upload`: `any`; \} \| \{ `taken_from_canister`: `any`; \}

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:327](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/candid/ic-management.d.ts#L327)

***

### stable\_memory\_size

> **stable\_memory\_size**: `bigint`

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:338](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/candid/ic-management.d.ts#L338)

***

### taken\_at\_timestamp

> **taken\_at\_timestamp**: `bigint`

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:340](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/candid/ic-management.d.ts#L340)

***

### wasm\_chunk\_store

> **wasm\_chunk\_store**: `object`[]

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:339](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/candid/ic-management.d.ts#L339)

#### hash

> **hash**: `Uint8Array`

***

### wasm\_memory\_size

> **wasm\_memory\_size**: `bigint`

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:341](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/candid/ic-management.d.ts#L341)

***

### wasm\_module\_size

> **wasm\_module\_size**: `bigint`

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:337](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/candid/ic-management.d.ts#L337)
