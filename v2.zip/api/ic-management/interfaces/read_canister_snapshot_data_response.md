---
title: read_canister_snapshot_data_response
editUrl: false
next: true
prev: true
---

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:311](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/candid/ic-management.d.ts#L311)

## Properties

### chunk

> **chunk**: `Uint8Array`

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:312](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/candid/ic-management.d.ts#L312)
