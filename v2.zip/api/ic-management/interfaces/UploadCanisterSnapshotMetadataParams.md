---
title: UploadCanisterSnapshotMetadataParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/ic-management/src/types/snapshot.params.ts:84](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/types/snapshot.params.ts#L84)

## Extends

- [`OptionSnapshotParams`](OptionSnapshotParams.md)

## Properties

### canisterId

> **canisterId**: `Principal`

Defined in: [packages/ic-management/src/types/snapshot.params.ts:17](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/types/snapshot.params.ts#L17)

#### Inherited from

[`OptionSnapshotParams`](OptionSnapshotParams.md).[`canisterId`](OptionSnapshotParams.md#canisterid)

***

### metadata

> **metadata**: [`UploadCanisterSnapshotMetadataParam`](../type-aliases/UploadCanisterSnapshotMetadataParam.md)

Defined in: [packages/ic-management/src/types/snapshot.params.ts:86](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/types/snapshot.params.ts#L86)

***

### snapshotId?

> `optional` **snapshotId**: `string` \| [`snapshot_id`](../type-aliases/snapshot_id.md)

Defined in: [packages/ic-management/src/types/snapshot.params.ts:18](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/types/snapshot.params.ts#L18)

#### Inherited from

[`OptionSnapshotParams`](OptionSnapshotParams.md).[`snapshotId`](OptionSnapshotParams.md#snapshotid)
