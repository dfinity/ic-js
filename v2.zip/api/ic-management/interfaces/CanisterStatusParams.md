---
title: CanisterStatusParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/ic-management/src/types/ic-management.params.ts:116](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/types/ic-management.params.ts#L116)

## Extends

- `QueryParams`

## Properties

### canisterId

> **canisterId**: `Principal`

Defined in: [packages/ic-management/src/types/ic-management.params.ts:117](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/types/ic-management.params.ts#L117)

***

### certified?

> `optional` **certified**: `boolean`

Defined in: packages/utils/dist/types/query.params.d.ts:6

Perform update calls (certified) or query calls (not certified).

#### Inherited from

`QueryParams.certified`
