---
title: OptionSnapshotParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/ic-management/src/types/snapshot.params.ts:16](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/types/snapshot.params.ts#L16)

## Extended by

- [`UploadCanisterSnapshotMetadataParams`](UploadCanisterSnapshotMetadataParams.md)

## Properties

### canisterId

> **canisterId**: `Principal`

Defined in: [packages/ic-management/src/types/snapshot.params.ts:17](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/types/snapshot.params.ts#L17)

***

### snapshotId?

> `optional` **snapshotId**: `string` \| [`snapshot_id`](../type-aliases/snapshot_id.md)

Defined in: [packages/ic-management/src/types/snapshot.params.ts:18](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/types/snapshot.params.ts#L18)
