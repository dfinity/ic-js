---
title: definite_canister_settings
editUrl: false
next: true
prev: true
---

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:182](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/candid/ic-management.d.ts#L182)

## Properties

### compute\_allocation

> **compute\_allocation**: `bigint`

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:191](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/candid/ic-management.d.ts#L191)

***

### controllers

> **controllers**: `Principal`[]

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:186](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/candid/ic-management.d.ts#L186)

***

### environment\_variables

> **environment\_variables**: [`environment_variable`](environment_variable.md)[]

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:185](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/candid/ic-management.d.ts#L185)

***

### freezing\_threshold

> **freezing\_threshold**: `bigint`

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:183](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/candid/ic-management.d.ts#L183)

***

### log\_visibility

> **log\_visibility**: [`log_visibility`](../type-aliases/log_visibility.md)

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:188](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/candid/ic-management.d.ts#L188)

***

### memory\_allocation

> **memory\_allocation**: `bigint`

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:190](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/candid/ic-management.d.ts#L190)

***

### reserved\_cycles\_limit

> **reserved\_cycles\_limit**: `bigint`

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:187](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/candid/ic-management.d.ts#L187)

***

### wasm\_memory\_limit

> **wasm\_memory\_limit**: `bigint`

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:189](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/candid/ic-management.d.ts#L189)

***

### wasm\_memory\_threshold

> **wasm\_memory\_threshold**: `bigint`

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:184](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/candid/ic-management.d.ts#L184)
