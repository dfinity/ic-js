---
title: chunk_hash
editUrl: false
next: true
prev: true
---

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:169](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/candid/ic-management.d.ts#L169)

## Properties

### hash

> **hash**: `Uint8Array`

Defined in: [packages/ic-management/src/candid/ic-management.d.ts:170](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/candid/ic-management.d.ts#L170)
