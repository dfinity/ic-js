---
title: CreateCanisterParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/ic-management/src/types/ic-management.params.ts:66](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/types/ic-management.params.ts#L66)

## Properties

### senderCanisterVersion?

> `optional` **senderCanisterVersion**: `bigint`

Defined in: [packages/ic-management/src/types/ic-management.params.ts:68](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/types/ic-management.params.ts#L68)

***

### settings?

> `optional` **settings**: [`CanisterSettings`](CanisterSettings.md)

Defined in: [packages/ic-management/src/types/ic-management.params.ts:67](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/types/ic-management.params.ts#L67)
