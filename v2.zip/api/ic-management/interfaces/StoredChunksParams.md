---
title: StoredChunksParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/ic-management/src/types/ic-management.params.ts:93](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/types/ic-management.params.ts#L93)

## Properties

### canisterId

> **canisterId**: `Principal`

Defined in: [packages/ic-management/src/types/ic-management.params.ts:94](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/types/ic-management.params.ts#L94)
