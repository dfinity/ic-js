---
title: LogVisibility
editUrl: false
next: true
prev: true
---

Defined in: [packages/ic-management/src/types/ic-management.params.ts:12](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/types/ic-management.params.ts#L12)

## Enumeration Members

### Controllers

> **Controllers**: `0`

Defined in: [packages/ic-management/src/types/ic-management.params.ts:13](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/types/ic-management.params.ts#L13)

***

### Public

> **Public**: `1`

Defined in: [packages/ic-management/src/types/ic-management.params.ts:14](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/types/ic-management.params.ts#L14)
