---
title: LogVisibility
editUrl: false
next: true
prev: true
---

Defined in: [packages/ic-management/src/types/ic-management.params.ts:12](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/types/ic-management.params.ts#L12)

## Enumeration Members

### Controllers

> **Controllers**: `0`

Defined in: [packages/ic-management/src/types/ic-management.params.ts:13](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/types/ic-management.params.ts#L13)

***

### Public

> **Public**: `1`

Defined in: [packages/ic-management/src/types/ic-management.params.ts:14](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/ic-management/src/types/ic-management.params.ts#L14)
