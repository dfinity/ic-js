---
title: fromReadCanisterSnapshotMetadataResponse
editUrl: false
next: true
prev: true
---

> **fromReadCanisterSnapshotMetadataResponse**(`__namedParameters`): [`ReadCanisterSnapshotMetadataResponse`](../interfaces/ReadCanisterSnapshotMetadataResponse.md)

Defined in: [packages/ic-management/src/types/snapshot.responses.ts:27](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/types/snapshot.responses.ts#L27)

## Parameters

### \_\_namedParameters

[`read_canister_snapshot_metadata_response`](../interfaces/read_canister_snapshot_metadata_response.md)

## Returns

[`ReadCanisterSnapshotMetadataResponse`](../interfaces/ReadCanisterSnapshotMetadataResponse.md)
