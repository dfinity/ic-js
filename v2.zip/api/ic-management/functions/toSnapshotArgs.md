---
title: toSnapshotArgs
editUrl: false
next: true
prev: true
---

> **toSnapshotArgs**(`__namedParameters`): `object`

Defined in: [packages/ic-management/src/types/snapshot.params.ts:23](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/types/snapshot.params.ts#L23)

## Parameters

### \_\_namedParameters

[`SnapshotParams`](../type-aliases/SnapshotParams.md)

## Returns

`object`

### canister\_id

> **canister\_id**: `Principal`

### snapshot\_id

> **snapshot\_id**: [`snapshot_id`](../type-aliases/snapshot_id.md)
