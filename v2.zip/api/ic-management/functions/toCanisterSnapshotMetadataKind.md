---
title: toCanisterSnapshotMetadataKind
editUrl: false
next: true
prev: true
---

> **toCanisterSnapshotMetadataKind**(`kind`): \{ `wasm_module`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `wasm_memory`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `stable_memory`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `wasm_chunk`: \{ `hash`: `Uint8Array`; \}; \}

Defined in: [packages/ic-management/src/types/snapshot.params.ts:51](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/types/snapshot.params.ts#L51)

## Parameters

### kind

[`CanisterSnapshotMetadataKind`](../type-aliases/CanisterSnapshotMetadataKind.md)

## Returns

\{ `wasm_module`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `wasm_memory`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `stable_memory`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `wasm_chunk`: \{ `hash`: `Uint8Array`; \}; \}
