---
title: toUploadCanisterSnapshotDataKind
editUrl: false
next: true
prev: true
---

> **toUploadCanisterSnapshotDataKind**(`kind`): \{ `wasm_module`: \{ `offset`: `bigint`; \}; \} \| \{ `wasm_memory`: \{ `offset`: `bigint`; \}; \} \| \{ `stable_memory`: \{ `offset`: `bigint`; \}; \} \| \{ `wasm_chunk`: `null`; \}

Defined in: [packages/ic-management/src/types/snapshot.params.ts:143](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/types/snapshot.params.ts#L143)

## Parameters

### kind

[`UploadCanisterSnapshotDataKind`](../type-aliases/UploadCanisterSnapshotDataKind.md)

## Returns

\{ `wasm_module`: \{ `offset`: `bigint`; \}; \} \| \{ `wasm_memory`: \{ `offset`: `bigint`; \}; \} \| \{ `stable_memory`: \{ `offset`: `bigint`; \}; \} \| \{ `wasm_chunk`: `null`; \}
