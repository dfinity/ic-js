---
title: toUploadCanisterSnapshotMetadata
editUrl: false
next: true
prev: true
---

> **toUploadCanisterSnapshotMetadata**(`__namedParameters`): `Omit`\<`upload_canister_snapshot_metadata_args`, `"canister_id"` \| `"replace_snapshot"`\>

Defined in: [packages/ic-management/src/types/snapshot.params.ts:89](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/ic-management/src/types/snapshot.params.ts#L89)

## Parameters

### \_\_namedParameters

[`UploadCanisterSnapshotMetadataParam`](../type-aliases/UploadCanisterSnapshotMetadataParam.md)

## Returns

`Omit`\<`upload_canister_snapshot_metadata_args`, `"canister_id"` \| `"replace_snapshot"`\>
