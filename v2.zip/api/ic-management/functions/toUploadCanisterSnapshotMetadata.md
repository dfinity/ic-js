---
title: toUploadCanisterSnapshotMetadata
editUrl: false
next: true
prev: true
---

> **toUploadCanisterSnapshotMetadata**(`__namedParameters`): `Omit`\<`upload_canister_snapshot_metadata_args`, `"canister_id"` \| `"replace_snapshot"`\>

Defined in: [packages/ic-management/src/types/snapshot.params.ts:89](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/ic-management/src/types/snapshot.params.ts#L89)

## Parameters

### \_\_namedParameters

[`UploadCanisterSnapshotMetadataParam`](../type-aliases/UploadCanisterSnapshotMetadataParam.md)

## Returns

`Omit`\<`upload_canister_snapshot_metadata_args`, `"canister_id"` \| `"replace_snapshot"`\>
