---
title: MinterInfo
editUrl: false
next: true
prev: true
---

Defined in: [packages/cketh/src/candid/minter.d.ts:394](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/candid/minter.d.ts#L394)

## Properties

### cketh\_ledger\_id

> **cketh\_ledger\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/cketh/src/candid/minter.d.ts:436](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/candid/minter.d.ts#L436)

Canister ID of the ckETH ledger.

***

### deposit\_with\_subaccount\_helper\_contract\_address

> **deposit\_with\_subaccount\_helper\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/cketh/src/candid/minter.d.ts:398](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/candid/minter.d.ts#L398)

Address of the ETH or ERC20 deposit with subaccount helper smart contract.

***

### erc20\_balances

> **erc20\_balances**: \[\] \| \[`object`[]\]

Defined in: [packages/cketh/src/candid/minter.d.ts:454](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/candid/minter.d.ts#L454)

Amount of ETH in Wei controlled by the minter.
This might be less that the actual amount available on the `minter_address()`.

***

### erc20\_helper\_contract\_address

> **erc20\_helper\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/cketh/src/candid/minter.d.ts:420](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/candid/minter.d.ts#L420)

Address of the ERC20 helper smart contract

***

### eth\_balance

> **eth\_balance**: \[\] \| \[`bigint`\]

Defined in: [packages/cketh/src/candid/minter.d.ts:403](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/candid/minter.d.ts#L403)

Amount of ETH in Wei controlled by the minter.
This might be less that the actual amount available on the `minter_address()`.

***

### eth\_helper\_contract\_address

> **eth\_helper\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/cketh/src/candid/minter.d.ts:407](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/candid/minter.d.ts#L407)

Address of the ETH helper smart contract.

***

### ethereum\_block\_height

> **ethereum\_block\_height**: \[\] \| \[`BlockTag`\]

Defined in: [packages/cketh/src/candid/minter.d.ts:468](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/candid/minter.d.ts#L468)

Determine ethereum block height observed by minter.

***

### evm\_rpc\_id

> **evm\_rpc\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/cketh/src/candid/minter.d.ts:416](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/candid/minter.d.ts#L416)

Canister ID of the EVM RPC canister that handles the communication
with the Ethereum blockchain.

***

### last\_deposit\_with\_subaccount\_scraped\_block\_number

> **last\_deposit\_with\_subaccount\_scraped\_block\_number**: \[\] \| \[`bigint`\]

Defined in: [packages/cketh/src/candid/minter.d.ts:464](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/candid/minter.d.ts#L464)

Last scraped block number for logs of the deposit with subaccount helper contract.

***

### last\_erc20\_scraped\_block\_number

> **last\_erc20\_scraped\_block\_number**: \[\] \| \[`bigint`\]

Defined in: [packages/cketh/src/candid/minter.d.ts:424](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/candid/minter.d.ts#L424)

Last scraped block number for logs of the ERC20 helper contract.

***

### last\_eth\_scraped\_block\_number

> **last\_eth\_scraped\_block\_number**: \[\] \| \[`bigint`\]

Defined in: [packages/cketh/src/candid/minter.d.ts:445](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/candid/minter.d.ts#L445)

Last scraped block number for logs of the ETH helper contract.

***

### last\_gas\_fee\_estimate

> **last\_gas\_fee\_estimate**: \[\] \| \[`GasFeeEstimate`\]

Defined in: [packages/cketh/src/candid/minter.d.ts:432](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/candid/minter.d.ts#L432)

Last gas fee estimate.

***

### last\_observed\_block\_number

> **last\_observed\_block\_number**: \[\] \| \[`bigint`\]

Defined in: [packages/cketh/src/candid/minter.d.ts:411](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/candid/minter.d.ts#L411)

Last Ethereum block number observed by the minter.

***

### minimum\_withdrawal\_amount

> **minimum\_withdrawal\_amount**: \[\] \| \[`bigint`\]

Defined in: [packages/cketh/src/candid/minter.d.ts:449](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/candid/minter.d.ts#L449)

Minimum amount in Wei that can be withdrawn when converting ckETH -> ETH.

***

### minter\_address

> **minter\_address**: \[\] \| \[`string`\]

Defined in: [packages/cketh/src/candid/minter.d.ts:460](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/candid/minter.d.ts#L460)

Ethereum address controlled by the minter via threshold ECDSA.

***

### smart\_contract\_address

> **smart\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/cketh/src/candid/minter.d.ts:441](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/candid/minter.d.ts#L441)

(Deprecated) Address of the ETH helper smart contract.
Use `eth_helper_contract_address`.

***

### supported\_ckerc20\_tokens

> **supported\_ckerc20\_tokens**: \[\] \| \[`CkErc20Token`[]\]

Defined in: [packages/cketh/src/candid/minter.d.ts:428](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/candid/minter.d.ts#L428)

Information of supported ERC20 tokens.
