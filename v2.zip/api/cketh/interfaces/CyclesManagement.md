---
title: CyclesManagement
editUrl: false
next: true
prev: true
---

Defined in: [packages/cketh/src/candid/orchestrator.d.ts:31](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/cketh/src/candid/orchestrator.d.ts#L31)

## Properties

### cycles\_for\_archive\_creation

> **cycles\_for\_archive\_creation**: `bigint`

Defined in: [packages/cketh/src/candid/orchestrator.d.ts:43](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/cketh/src/candid/orchestrator.d.ts#L43)

Number of cycles when creating a new ICRC1 archive canister.

***

### cycles\_for\_index\_creation

> **cycles\_for\_index\_creation**: `bigint`

Defined in: [packages/cketh/src/candid/orchestrator.d.ts:47](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/cketh/src/candid/orchestrator.d.ts#L47)

Number of cycles when creating a new ICRC1 index canister.

***

### cycles\_for\_ledger\_creation

> **cycles\_for\_ledger\_creation**: `bigint`

Defined in: [packages/cketh/src/candid/orchestrator.d.ts:39](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/cketh/src/candid/orchestrator.d.ts#L39)

Number of cycles when creating a new ICRC1 ledger canister.

***

### cycles\_top\_up\_increment

> **cycles\_top\_up\_increment**: `bigint`

Defined in: [packages/cketh/src/candid/orchestrator.d.ts:35](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/cketh/src/candid/orchestrator.d.ts#L35)

Number of cycles to add to a canister managed by the orchestrator whose cycles balance is running low.
