---
title: EthTransaction
editUrl: false
next: true
prev: true
---

Defined in: [packages/cketh/src/candid/minter.d.ts:127](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/candid/minter.d.ts#L127)

## Properties

### transaction\_hash

> **transaction\_hash**: `string`

Defined in: [packages/cketh/src/candid/minter.d.ts:128](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/candid/minter.d.ts#L128)
