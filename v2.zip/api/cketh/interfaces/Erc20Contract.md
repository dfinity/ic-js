---
title: Erc20Contract
editUrl: false
next: true
prev: true
---

Defined in: [packages/cketh/src/candid/orchestrator.d.ts:58](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/candid/orchestrator.d.ts#L58)

## Properties

### address

> **address**: `string`

Defined in: [packages/cketh/src/candid/orchestrator.d.ts:60](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/candid/orchestrator.d.ts#L60)

***

### chain\_id

> **chain\_id**: `bigint`

Defined in: [packages/cketh/src/candid/orchestrator.d.ts:59](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/candid/orchestrator.d.ts#L59)
