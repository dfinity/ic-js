---
title: Erc20Contract
editUrl: false
next: true
prev: true
---

Defined in: [packages/cketh/src/candid/orchestrator.d.ts:58](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/cketh/src/candid/orchestrator.d.ts#L58)

## Properties

### address

> **address**: `string`

Defined in: [packages/cketh/src/candid/orchestrator.d.ts:60](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/cketh/src/candid/orchestrator.d.ts#L60)

***

### chain\_id

> **chain\_id**: `bigint`

Defined in: [packages/cketh/src/candid/orchestrator.d.ts:59](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/cketh/src/candid/orchestrator.d.ts#L59)
