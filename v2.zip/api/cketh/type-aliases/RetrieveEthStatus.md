---
title: RetrieveEthStatus
editUrl: false
next: true
prev: true
---

> **RetrieveEthStatus** = \{ `NotFound`: `null`; \} \| \{ `TxFinalized`: [`TxFinalizedStatus`](TxFinalizedStatus.md); \} \| \{ `TxSent`: [`EthTransaction`](../interfaces/EthTransaction.md); \} \| \{ `TxCreated`: `null`; \} \| \{ `Pending`: `null`; \}

Defined in: [packages/cketh/src/candid/minter.d.ts:502](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/cketh/src/candid/minter.d.ts#L502)

Retrieve the status of a withdrawal request.

## Type Declaration

\{ `NotFound`: `null`; \}

### NotFound

> **NotFound**: `null`

Withdrawal request is not found.

\{ `TxFinalized`: [`TxFinalizedStatus`](TxFinalizedStatus.md); \}

### TxFinalized

> **TxFinalized**: [`TxFinalizedStatus`](TxFinalizedStatus.md)

Ethereum transaction is finalized.

\{ `TxSent`: [`EthTransaction`](../interfaces/EthTransaction.md); \}

### TxSent

> **TxSent**: [`EthTransaction`](../interfaces/EthTransaction.md)

Ethereum transaction was signed and is sent to the network.

\{ `TxCreated`: `null`; \}

### TxCreated

> **TxCreated**: `null`

Transaction fees were estimated and an Ethereum transaction was created.
Transaction is not signed yet.

\{ `Pending`: `null`; \}

### Pending

> **Pending**: `null`

Withdrawal request is waiting to be processed.
