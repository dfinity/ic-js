---
title: Eip1559TransactionPriceParams
editUrl: false
next: true
prev: true
---

> **Eip1559TransactionPriceParams** = `object` & `QueryParams`

Defined in: [packages/cketh/src/types/minter.params.ts:5](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/types/minter.params.ts#L5)

## Type Declaration

### ckErc20LedgerId?

> `optional` **ckErc20LedgerId**: `Principal`
