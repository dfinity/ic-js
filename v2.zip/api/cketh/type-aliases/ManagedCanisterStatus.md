---
title: ManagedCanisterStatus
editUrl: false
next: true
prev: true
---

> **ManagedCanisterStatus** = \{ `Created`: \{ `canister_id`: `Principal`; \}; \} \| \{ `Installed`: \{ `canister_id`: `Principal`; `installed_wasm_hash`: `string`; \}; \}

Defined in: [packages/cketh/src/candid/orchestrator.d.ts:138](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/cketh/src/candid/orchestrator.d.ts#L138)

## Type Declaration

\{ `Created`: \{ `canister_id`: `Principal`; \}; \}

### Created

> **Created**: `object`

Canister created with the given principal but wasm module is not yet installed.

#### Created.canister\_id

> **canister\_id**: `Principal`

\{ `Installed`: \{ `canister_id`: `Principal`; `installed_wasm_hash`: `string`; \}; \}

### Installed

> **Installed**: `object`

Canister created and wasm module installed.
The wasm_hash reflects the installed wasm module by the orchestrator
but *may differ* from the one being currently deployed (if another controller did an upgrade)

#### Installed.canister\_id

> **canister\_id**: `Principal`

#### Installed.installed\_wasm\_hash

> **installed\_wasm\_hash**: `string`
