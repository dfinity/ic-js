---
title: createWithdrawErc20Error
editUrl: false
next: true
prev: true
---

> **createWithdrawErc20Error**(`Err`): [`MinterGenericError`](../classes/MinterGenericError.md)

Defined in: [packages/cketh/src/errors/minter.errors.ts:75](https://github.com/dfinity/icp-js-canisters/blob/35f85b2f644ed8fc967ce361a4b0f91cd90cc198/packages/cketh/src/errors/minter.errors.ts#L75)

## Parameters

### Err

`WithdrawErc20Error`

## Returns

[`MinterGenericError`](../classes/MinterGenericError.md)
