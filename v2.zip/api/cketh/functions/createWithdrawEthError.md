---
title: createWithdrawEthError
editUrl: false
next: true
prev: true
---

> **createWithdrawEthError**(`Err`): [`MinterGenericError`](../classes/MinterGenericError.md)

Defined in: [packages/cketh/src/errors/minter.errors.ts:37](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/cketh/src/errors/minter.errors.ts#L37)

## Parameters

### Err

`WithdrawalError`

## Returns

[`MinterGenericError`](../classes/MinterGenericError.md)
