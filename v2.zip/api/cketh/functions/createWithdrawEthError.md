---
title: createWithdrawEthError
editUrl: false
next: true
prev: true
---

> **createWithdrawEthError**(`Err`): [`MinterGenericError`](../classes/MinterGenericError.md)

Defined in: [packages/cketh/src/errors/minter.errors.ts:37](https://github.com/dfinity/icp-js-canisters/blob/f22e3bc1f7af40ce5e3152a79bb32c19d6e0cca6/packages/cketh/src/errors/minter.errors.ts#L37)

## Parameters

### Err

`WithdrawalError`

## Returns

[`MinterGenericError`](../classes/MinterGenericError.md)
