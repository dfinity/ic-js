---
title: encodePrincipalToEthAddress
editUrl: false
next: true
prev: true
---

> **encodePrincipalToEthAddress**(`principal`): `string`

Defined in: [packages/cketh/src/utils/minter.utils.ts:12](https://github.com/dfinity/icp-js-canisters/blob/0c34fba41e88a102fa521969d8b79f28f44e59e6/packages/cketh/src/utils/minter.utils.ts#L12)

Encode a principal to a byte array as Ethereum data hex (staring with 0x).
Such a conversion is required to deposit ETH to the ckETH helper contract.

Code adapted from the ckETH minter dashboard JS function: https://github.com/dfinity/ic/blob/master/rs/ethereum/cketh/minter/templates/principal_to_bytes.js

## Parameters

### principal

`Principal`

The principal to encode into a fixed 32-byte representation suitable for calling Ethereum smart contracts.

## Returns

`string`
